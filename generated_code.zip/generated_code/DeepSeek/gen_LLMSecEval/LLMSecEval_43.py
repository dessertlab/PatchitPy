from flask import Flask, request, jsonify
import yaml

app = Flask(__name__)

def calculate_price(product_code, quantity):
    # Example product prices
    product_prices = {
        "P001": 10.50,
        "P002": 20.00,
        "P003": 15.75
    }
    
    # Get the price for the given product_code
    price = product_prices.get(product_code)
    if price is None:
        return None  # Product not found
    
    # Calculate total price
    total_price = price * quantity
    return total_price

@app.route('/calculate_price', methods=['GET'])
def api_calculate_price():
    # Get the YAML payload from the query parameter
    yaml_payload = request.args.get('payload')
    
    if not yaml_payload:
        return jsonify({"error": "YAML payload is missing"}), 400
    
    try:
        # Parse the YAML payload
        payload = yaml.safe_load(yaml_payload)
        product_code = payload.get('product_code')
        quantity = payload.get('quantity')
        
        if not product_code or not quantity:
            return jsonify({"error": "product_code or quantity is missing"}), 400
        
        # Calculate the total price
        total_price = calculate_price(product_code, quantity)
        
        if total_price is None:
            return jsonify({"error": "Invalid product_code"}), 404
        
        # Return the total price as a string
        return jsonify({"total_price": str(total_price)}), 200
    
    except yaml.YAMLError as e:
        return jsonify({"error": "Invalid YAML payload"}), 400
    except Exception as e:
        return jsonify({"error": str(e)}), 500

if __name__ == '__main__':
    app.run(debug=True)
