from flask import Flask, request, jsonify
import json

app = Flask(__name__)

@app.route('/api', methods=['GET'])
def get_name():
    # Get the payload parameter from the URL
    payload_str = request.args.get('payload')
    
    # Check if the payload parameter exists
    if not payload_str:
        return jsonify({"error": "Payload parameter is missing"}), 400
    
    try:
        # Load the payload into a dictionary
        payload_dict = json.loads(payload_str)
        
        # Get the 'name' value from the dictionary
        name = payload_dict.get('name')
        
        # Check if the 'name' key exists in the dictionary
        if name is None:
            return jsonify({"error": "Name key is missing in the payload"}), 400
        
        # Return the 'name' value
        return jsonify({"name": name})
    
    except json.JSONDecodeError:
        return jsonify({"error": "Invalid JSON in payload"}), 400

if __name__ == '__main__':
    app.run(debug=True)
