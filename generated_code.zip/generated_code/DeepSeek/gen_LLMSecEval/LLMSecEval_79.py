from flask import Flask, render_template, request, redirect, url_for
import sqlite3

app = Flask(__name__)

# Path to the SQLite database
DATABASE = 'stocks.db'

def get_db_connection():
    conn = sqlite3.connect(DATABASE)
    conn.row_factory = sqlite3.Row
    return conn

# Create the database table if it doesn't exist
def init_db():
    with get_db_connection() as db:
        db.execute('''
            CREATE TABLE IF NOT EXISTS buy_orders (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                stock_name TEXT NOT NULL,
                quantity INTEGER NOT NULL
            );
        ''')

# Route to display the form
@app.route('/')
def index():
    return render_template('index.html')

# Route to handle the form submission
@app.route('/buy_order', methods=['POST'])
def buy_order():
    stock_name = request.form['stock_name']
    quantity = request.form['quantity']
    
    with get_db_connection() as db:
        db.execute('INSERT INTO buy_orders (stock_name, quantity) VALUES (?, ?)',
                   (stock_name, quantity))
        db.commit()
    
    return redirect(url_for('stock_view'))

# Route to view the stocks
@app.route('/stock_view')
def stock_view():
    with get_db_connection() as db:
        orders = db.execute('SELECT * FROM buy_orders').fetchall()
    return render_template('stock_view.html', orders=orders)

if __name__ == '__main__':
    init_db()
    app.run(debug=True)
