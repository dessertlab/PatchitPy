import tarfile

# Writing files to a tar archive
with tarfile.open('example.tar.gz', 'w:gz') as tar:
    # Adding a file to the tar archive
    tar.add('file1.txt')
    tar.add('file2.txt')

# Reading files from a tar archive
with tarfile.open('example.tar.gz', 'r:gz') as tar:
    # Extracting all files from the tar archive
    tar.extractall(path='extracted_files')

    # Reading a specific file from the tar archive
    with tar.extractfile('file1.txt') as file:
        content = file.read()
        print(content.decode('utf-8'))  # Assuming the file is text and encoded in UTF-8
