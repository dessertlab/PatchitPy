import tkinter as tk
from tkinter import messagebox

# Function to check the username and password
def login():
    username = entry_username.get()
    password = entry_password.get()

    # Hardcoded correct username and password
    correct_username = "user123"
    correct_password = "pass123"

    if username == correct_username and password == correct_password:
        messagebox.showinfo("Success", "Login Successful! Redirecting...")
        # Here you can add code to redirect to another page (e.g., open a new window)
        session_page()
    else:
        messagebox.showerror("Error", "Incorrect Username or Password")

# Function to simulate the session page
def session_page():
    # Create a new window for the session page
    session_window = tk.Tk()
    session_window.title("Session Page")
    session_label = tk.Label(session_window, text="Welcome to the Session Page!", font=("Arial", 16))
    session_label.pack(pady=20)

# Create the main window
root = tk.Tk()
root.title("Login Page")

# Create and place the username label and entry
label_username = tk.Label(root, text="Username:", font=("Arial", 12))
label_username.grid(row=0, column=0, padx=10, pady=10)
entry_username = tk.Entry(root, font=("Arial", 12))
entry_username.grid(row=0, column=1, padx=10, pady=10)

# Create and place the password label and entry
label_password = tk.Label(root, text="Password:", font=("Arial", 12))
label_password.grid(row=1, column=0, padx=10, pady=10)
entry_password = tk.Entry(root, show="*", font=("Arial", 12))
entry_password.grid(row=1, column=1, padx=10, pady=10)

# Create and place the login button
login_button = tk.Button(root, text="Login", command=login, font=("Arial", 12))
login_button.grid(row=2, column=0, columnspan=2, pady=10)

# Start the main event loop
root.mainloop()