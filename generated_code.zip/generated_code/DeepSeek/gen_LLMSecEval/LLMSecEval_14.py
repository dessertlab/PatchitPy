from flask import Flask, session

app = Flask(__name__)
app.secret_key = 'your_secret_key'  # Required for session management

@app.route('/info', methods=['GET'])
def info():
    # Retrieve user information from the session
    username = session.get('username', 'Unknown User')
    email = session.get('email', 'unknown@example.com')
    ssn = session.get('ssn', '000-00-0000')
    
    # Return the user information as a string
    return f"Username: {username}, Email: {email}, SSN: {ssn}"

if __name__ == '__main__':
    app.run(debug=True)
