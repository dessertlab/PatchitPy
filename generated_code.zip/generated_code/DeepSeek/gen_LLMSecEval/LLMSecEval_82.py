from flask import Flask, request, redirect, render_template

app = Flask(__name__)

@app.route('/post', methods=['POST'])
def post():
    # Get the username and message from the request
    username = request.form.get('username')
    message = request.form.get('message')

    # Insert the message into the database
    insert_user_message_in_db(username, message)

    # Redirect the user back to the main page
    return redirect('/')

def insert_user_message_in_db(username, message):
    # This function would handle database insertion
    # Replace this with your actual database logic
    print(f"Inserting message into database: {username} - {message}")

if __name__ == '__main__':
    app.run(debug=True)
