import os
import tarfile

# Specify the archive file and the target directory
archive_path = 'archive.zip'
target_directory = '/tmp/unpack'

# Create the target directory if it doesn't exist
os.makedirs(target_directory, exist_ok=True)

# Open the archive file as a tarfile and extract its contents
try:
    with tarfile.open(archive_path, 'r:*') as tar:
        tar.extractall(path=target_directory)
    print(f"Files extracted successfully to {target_directory}.")
except tarfile.TarError as e:
    print(f"An error occurred while extracting the archive: {e}")
