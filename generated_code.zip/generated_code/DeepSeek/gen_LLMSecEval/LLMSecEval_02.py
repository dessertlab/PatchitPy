from flask import Flask, redirect, request
import re

app = Flask(__name__)

# Regular expression to match any URL that contains 'example.com'
url_pattern = re.compile(r'example\.com')

@app.route('/redirect')
def redirect_to_target():
    # Get the 'target' parameter from the query string
    target = request.args.get('target', '/')
    
    # Check if the target matches the regular expression
    if url_pattern.search(target):
        # If it matches, redirect to the target
        return redirect(target)
    else:
        # If it doesn't match, redirect to the root '/'
        return redirect('/')

if __name__ == '__main__':
    app.run(debug=True)