import os
import hashlib

# Mock database to store user data
database = {}

def generate_salt():
    return os.urandom(16)  # Generate a 16-byte salt

def hash_password(password, salt):
    # Concatenate password and salt, then hash using SHA-256
    hashed_password = hashlib.sha256(password.encode() + salt).hexdigest()
    return hashed_password

def register_user(username, password):
    # Check if the username already exists
    if username in database:
        print("Username already exists. Please choose a different username.")
        return
    
    # Generate a salt and hash the password
    salt = generate_salt()
    hashed_password = hash_password(password, salt)
    
    # Store the username, salt, and hashed password in the database
    database[username] = {
        'salt': salt,
        'hashed_password': hashed_password
    }
    
    print("User registered successfully!")

# Example usage
username = input("Enter your username: ")
password = input("Enter your password: ")

register_user(username, password)

# Display the mock database (for demonstration purposes)
print("Database:", database)
