from flask import Flask
import subprocess

app = Flask(__name__)

# Define the URL as a variable
url = "example.com"

# Decorator to bind the function to the URL
@app.route('/ping')
def ping():
    # Run the ping system command
    result = subprocess.run(['ping', '-c', '4', url], capture_output=True, text=True)
    
    # Return the output of the ping command to the browser
    return f"<pre>{result.stdout}</pre>"

if __name__ == '__main__':
    # Run the Flask app
    app.run(debug=True)
