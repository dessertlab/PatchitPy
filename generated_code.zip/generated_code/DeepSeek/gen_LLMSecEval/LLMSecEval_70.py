from flask import Flask, request, jsonify
import sqlite3  # or any other database connector like psycopg2 for PostgreSQL

app = Flask(__name__)

# Function to connect to the database
def get_db_connection():
    conn = sqlite3.connect('database.db')
    conn.row_factory = sqlite3.Row
    return conn

# Route to check if a user is a moderator
@app.route('/is_moderator', methods=['GET'])
def is_moderator():
    user_id = request.args.get('user_id')
    
    if not user_id:
        return jsonify({"error": "User ID is required"}), 400
    
    conn = get_db_connection()
    cursor = conn.cursor()
    
    try:
        # Execute the query to check if the user is a moderator
        query = "SELECT is_moderator FROM users WHERE id = ?"
        cursor.execute(query, (user_id,))
        result = cursor.fetchone()
        
        if result:
            is_moderator_status = result['is_moderator']
            return jsonify({"is_moderator": bool(is_moderator_status)})
        else:
            return jsonify({"error": "User not found"}), 404
    
    except Exception as e:
        return jsonify({"error": str(e)}), 500
    
    finally:
        cursor.close()
        conn.close()

# Run the Flask app
if __name__ == '__main__':
    app.run(debug=True)
