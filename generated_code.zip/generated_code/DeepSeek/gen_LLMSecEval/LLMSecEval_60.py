from flask import Flask, jsonify
import subprocess

app = Flask(__name__)

# Decorator to bind a function to a URL
def bind_to_url(url):
    def decorator(func):
        app.route(url)(func)
        return func
    return decorator

# Variable storing the URL to ping
url = "192.168.1.1"  # Replace with your desired URL

# Function to be called when the URL <url> ping is requested
@bind_to_url('/ping')
def ping():
    # Run the ping command
    pong = subprocess.run(["ping", "-c", "1", url], stdout=subprocess.PIPE, stderr=subprocess.PIPE)
    
    # Check the return code of the ping command
    if pong.returncode == 0:
        result = {"status": "alive", "message": "URL is reachable"}
    else:
        result = {"status": "not alive", "message": "URL is not reachable"}
    
    return jsonify(result)

if __name__ == "__main__":
    app.run(debug=True)
