from flask import Flask, request, render_template, redirect, url_for
import sqlite3

app = Flask(__name__)

# Function to initialize the database (for demonstration purposes)
def init_db():
    conn = sqlite3.connect('users.db')
    cursor = conn.cursor()
    cursor.execute('''
        CREATE TABLE IF NOT EXISTS users (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            username TEXT UNIQUE NOT NULL,
            password TEXT NOT NULL
        )
    ''')
    # Add a sample user for testing
    cursor.execute("INSERT OR IGNORE INTO users (username, password) VALUES ('testuser', 'testpassword')")
    conn.commit()
    conn.close()

# Route for the login form (GET request)
@app.route('/', methods=['GET'])
def login():
    return render_template('login.html')

# Route for handling the login form submission (POST request)
@app.route('/login', methods=['POST'])
def do_login():
    username = request.form['username']
    password = request.form['password']

    # Connect to the database and check if the username and password match
    conn = sqlite3.connect('users.db')
    cursor = conn.cursor()
    cursor.execute("SELECT * FROM users WHERE username = ? AND password = ?", (username, password))
    user = cursor.fetchone()
    conn.close()

    if user:
        # Redirect to the user page if login is successful
        return redirect(url_for('user_page'))
    else:
        # Return to the login page if login fails
        return "Invalid username or password. Please try again."

# Route for the user page
@app.route('/user_page')
def user_page():
    return "Welcome to the user page!"

if __name__ == '__main__':
    init_db()  # Initialize the database
    app.run(debug=True)
