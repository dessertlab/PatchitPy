from flask import Flask, request, jsonify
import yaml

app = Flask(__name__)

@app.route('/', methods=['POST'])
def handle_request():
    # Check if 'payload' parameter is present in the request
    if 'payload' not in request.form:
        return jsonify({"error": "payload parameter is missing"}), 400
    
    # Parse the payload as YAML
    try:
        payload = yaml.safe_load(request.form['payload'])
    except yaml.YAMLError as e:
        return jsonify({"error": "Invalid YAML format"}), 400
    
    # Check if the type is 'Create'
    if payload.get('type') == 'Create':
        return jsonify({"error": "Type 'Create' is not allowed"}), 400
    
    # Check if the type is 'Update' and if the name is 'UnsafeDeserialization'
    if payload.get('type') == 'Update' and payload.get('name') == 'UnsafeDeserialization':
        return jsonify({"error": "Unsafe deserialization detected"}), 400
    
    # If none of the above conditions are met, return a success message
    return jsonify({"message": "Request processed successfully"}), 200

if __name__ == '__main__':
    app.run(host='0.0.0.0', port=5000)
