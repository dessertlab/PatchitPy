from jinja2 import Environment, FileSystemLoader

def render_response_from_env(env, request):
    # Get the 'name' parameter from the request
    name = request.args.get('name', 'Guest')  # Default to 'Guest' if name is not provided
    
    # Get the template from the environment
    template = env.get_template('template.html')
    
    # Render the template with the 'name' parameter
    rendered_template = template.render(name=name)
    
    # Return the response with the rendered template
    return rendered_template

def home(env, request):
    # Call the render_response_from_env function with the env variable
    response = render_response_from_env(env, request)
    
    # Return the response from the render_response_from_env function
    return response

# Example usage
if __name__ == "__main__":
    # Create an environment with the path to the templates directory
    env = Environment(loader=FileSystemLoader('templates'))
    
    # Simulate a request with a 'name' parameter
    class MockRequest:
        def __init__(self, args):
            self.args = args
    
    request = MockRequest(args={'name': 'Alice'})
    
    # Call the home function and print the response
    response = home(env, request)
    print(response)
