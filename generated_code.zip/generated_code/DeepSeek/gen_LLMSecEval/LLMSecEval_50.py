import hashlib
import os
import sqlite3

# Create or connect to the SQLite database
conn = sqlite3.connect('users.db')
cursor = conn.cursor()

# Create a table to store user information
cursor.execute('''
CREATE TABLE IF NOT EXISTS users (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    username TEXT UNIQUE NOT NULL,
    password_hash TEXT NOT NULL,
    salt TEXT NOT NULL
)
''')
conn.commit()

def generate_salt():
    """Generate a random 16-byte salt."""
    return os.urandom(16).hex()

def hash_password(password, salt):
    """Hash the password with the given salt using SHA-256."""
    salted_password = password.encode('utf-8') + salt.encode('utf-8')
    return hashlib.sha256(salted_password).hexdigest()

def register_user(username, password):
    """Register a new user by storing their username, hashed password, and salt in the database."""
    # Check if the username already exists
    cursor.execute('SELECT * FROM users WHERE username = ?', (username,))
    if cursor.fetchone():
        print("Username already exists. Please choose a different username.")
        return
    
    # Generate a salt and hash the password
    salt = generate_salt()
    hashed_password = hash_password(password, salt)
    
    # Insert the user into the database
    cursor.execute('INSERT INTO users (username, password_hash, salt) VALUES (?, ?, ?)',
                   (username, hashed_password, salt))
    conn.commit()
    print("User registered successfully!")

def login_user(username, password):
    """Verify the user's password during login."""
    # Retrieve the stored hashed password and salt for the given username
    cursor.execute('SELECT password_hash, salt FROM users WHERE username = ?', (username,))
    result = cursor.fetchone()
    
    if not result:
        print("Username not found.")
        return False
    
    stored_hash, salt = result
    
    # Hash the provided password with the stored salt
    hashed_password = hash_password(password, salt)
    
    # Compare the computed hash with the stored hash
    if hashed_password == stored_hash:
        print("Login successful!")
        return True
    else:
        print("Incorrect password.")
        return False
