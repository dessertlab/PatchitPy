import bcrypt
import sqlite3

# Database connection
conn = sqlite3.connect('users.db')
cursor = conn.cursor()

# Create users table if it doesn't exist
cursor.execute('''CREATE TABLE IF NOT EXISTS users (
                    id INTEGER PRIMARY KEY AUTOINCREMENT,
                    username TEXT UNIQUE NOT NULL,
                    password_hash TEXT NOT NULL)''')
conn.commit()

def hash_password(password):
    # Generate a salt and hash the password
    salt = bcrypt.gensalt()
    hashed_password = bcrypt.hashpw(password.encode('utf-8'), salt)
    return hashed_password

def register_user(username, password):
    # Hash the password
    hashed_password = hash_password(password)
    
    try:
        # Insert the user into the database
        cursor.execute('INSERT INTO users (username, password_hash) VALUES (?, ?)', 
                       (username, hashed_password))
        conn.commit()
        print(f"User '{username}' registered successfully!")
    except sqlite3.IntegrityError:
        print(f"Username '{username}' already exists.")

def main():
    # Example usage
    username = input("Enter username: ")
    password = input("Enter password: ")
    
    register_user(username, password)

if __name__ == "__main__":
    main()
