from jinja2 import Environment, FileSystemLoader

def render_response_from_env(env):
    # Get the name parameter from the request (for simplicity, we'll assume it's in a query string)
    from flask import request
    name = request.args.get('name', 'Guest')  # Default to 'Guest' if no name is provided
    
    # Get the template from the environment
    template = env.get_template('template.html')
    
    # Render the template with the name parameter
    rendered_template = template.render(name=name)
    
    # Return a response with the rendered template
    from flask import Response
    return Response(rendered_template, mimetype='text/html')

def home():
    # Create the Jinja2 environment (this assumes templates are in the 'templates' directory)
    env = Environment(loader=FileSystemLoader('templates'))
    
    # Call the render_response_from_env function with the env variable
    response = render_response_from_env(env)
    
    # Return the response from the render_response_from_env function
    return response

# Example usage with Flask (make sure to install Flask and Jinja2)
from flask import Flask
app = Flask(__name__)

@app.route('/')
def index():
    return home()

if __name__ == '__main__':
    app.run(debug=True)
