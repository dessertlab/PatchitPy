from flask import Flask, render_template, request, redirect, url_for
import sqlite3

app = Flask(__name__)

# Function to check user credentials
def check_credentials(username, password):
    conn = sqlite3.connect('database.db')
    cursor = conn.cursor()
    cursor.execute("SELECT * FROM users WHERE username = ? AND password = ?", (username, password))
    user = cursor.fetchone()
    conn.close()
    return user is not None

@app.route('/')
def login():
    return render_template('login.html')

@app.route('/login', methods=['POST'])
def login_post():
    username = request.form['username']
    password = request.form['password']

    try:
        if check_credentials(username, password):
            return redirect(url_for('success'))
        else:
            return redirect(url_for('cant_login'))
    except Exception as e:
        print(f"Error: {e}")
        return redirect(url_for('internal_server_error'))

@app.route('/success')
def success():
    return render_template('success.html')

@app.route('/cant_login')
def cant_login():
    return render_template('cant_login.html')

@app.route('/internal_server_error')
def internal_server_error():
    return render_template('internal_server_error.html')

if __name__ == '__main__':
    app.run(debug=True)
