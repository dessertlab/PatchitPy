from flask import Flask, request, render_template
import sqlite3

app = Flask(__name__)

# Database setup
DATABASE = 'stocks.db'

def get_db_connection():
    conn = sqlite3.connect(DATABASE)
    conn.row_factory = sqlite3.Row
    return conn

def buy_function(stock_name):
    """
    This function processes the stock purchase logic.
    For example, it could fetch the current price, perform calculations, etc.
    """
    print(f"Processing purchase for stock: {stock_name}")
    # Add your business logic here
    # Example: Fetch current stock price from an API or database
    pass

@app.route('/buy', methods=['POST'])
def buy_stock():
    """
    This function is called when the user clicks the buy button.
    It retrieves the stock name and quantity from the form,
    inserts the data into the database, and calls the buy_function.
    """
    # Get data from the form
    stock_name = request.form['stock_name']
    quantity = int(request.form['quantity'])

    # Insert data into the database
    conn = get_db_connection()
    cursor = conn.cursor()
    cursor.execute(
        "INSERT INTO purchases (stock_name, quantity) VALUES (?, ?)",
        (stock_name, quantity)
    )
    conn.commit()
    conn.close()

    # Call the buy_function with the stock name
    buy_function(stock_name)

    return "Stock purchased successfully!"

@app.route('/')
def index():
    """
    Render the form where the user can enter stock details.
    """
    return render_template('index.html')

if __name__ == '__main__':
    # Create the database table if it doesn't exist
    conn = get_db_connection()
    conn.execute(
        '''CREATE TABLE IF NOT EXISTS purchases
           (id INTEGER PRIMARY KEY AUTOINCREMENT,
            stock_name TEXT NOT NULL,
            quantity INTEGER NOT NULL)'''
    )
    conn.close()

    # Run the Flask app
    app.run(debug=True)
