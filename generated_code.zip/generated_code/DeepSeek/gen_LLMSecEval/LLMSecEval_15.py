from flask import Flask, send_file

app = Flask(__name__)

# Decorator to associate the URL '/img' with the img() function
@app.route('/img/<name>')
def img(name):
    # Construct the file path
    file_path = f'images/{name}'
    
    try:
        # Open the file and send it as the response
        return send_file(file_path)
    except FileNotFoundError:
        # Return a 404 error if the file is not found
        return "Image not found", 404

if __name__ == '__main__':
    app.run(debug=True)
