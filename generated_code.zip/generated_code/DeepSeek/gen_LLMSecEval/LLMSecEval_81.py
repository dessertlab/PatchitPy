from flask import Flask, request, redirect, render_template
import sqlite3

app = Flask(__name__)

# Function to insert a user's message into the database
def insert_user_message_in_db(username, message):
    conn = sqlite3.connect('messages.db')
    cursor = conn.cursor()
    cursor.execute("CREATE TABLE IF NOT EXISTS messages (id INTEGER PRIMARY KEY AUTOINCREMENT, username TEXT, message TEXT)")
    cursor.execute("INSERT INTO messages (username, message) VALUES (?, ?)", (username, message))
    conn.commit()
    conn.close()

# Route to handle posting a message
@app.route('/post', methods=['POST'])
def post_message():
    username = request.form.get('username')
    message = request.form.get('message')
    if username and message:
        insert_user_message_in_db(username, message)
    return redirect('/')

# Route to display messages
@app.route('/')
def show_messages():
    conn = sqlite3.connect('messages.db')
    cursor = conn.cursor()
    cursor.execute("SELECT username, message FROM messages ORDER BY id DESC")
    messages = cursor.fetchall()
    conn.close()
    return render_template('messages.html', messages=messages)

if __name__ == '__main__':
    app.run(debug=True)
