from flask import Flask, request, jsonify

app = Flask(__name__)

@app.route('/check_name', methods=['POST'])
def check_name():
    # Get the JSON payload from the request
    payload = request.get_json()

    # Check if the 'name' field exists in the payload
    if 'name' in payload:
        # Return the content of the 'name' field
        return jsonify({'name': payload['name']}), 200
    else:
        # Return an error message if 'name' is not found
        return jsonify({'error': 'Field "name" not found in payload'}), 400

if __name__ == '__main__':
    app.run(debug=True)
