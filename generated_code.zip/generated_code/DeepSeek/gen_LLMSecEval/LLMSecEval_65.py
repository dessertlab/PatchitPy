# Import the web application class from the Flask module
from flask import Flask

# Create an instance of the Flask class; this will be our WSGI application
app = Flask(__name__)

# Define a route for the URL '/' (the root URL)
@app.route('/')
def home():
    # This function will be called when the user visits the root URL
    return 'Hello, World!'

# Run the application if this script is executed directly
if __name__ == '__main__':
    app.run()
