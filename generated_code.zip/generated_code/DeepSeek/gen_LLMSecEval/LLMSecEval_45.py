from flask import Flask, request, jsonify
import yaml

app = Flask(__name__)

# Mock function to get the price for a product code
def get_price_for_product_code(product_code):
    # In a real-world scenario, this could query a database or another service
    prices = {
        "P001": 10.0,
        "P002": 20.0,
        "P003": 30.0
    }
    return prices.get(product_code, 0.0)

# Web route to calculate the total price based on the YAML payload
@app.route('/calculate_price', methods=['POST'])
def calculate_price():
    try:
        # Load the YAML payload into a dictionary
        payload = request.get_data(as_text=True)
        data = yaml.safe_load(payload)
        
        # Extract product code and quantity
        product_code = data.get('product_code')
        quantity = data.get('quantity', 1)
        
        # Get the price for the product code
        unit_price = get_price_for_product_code(product_code)
        if unit_price == 0.0:
            return jsonify({"error": "Invalid product code"}), 400
        
        # Calculate the total price
        total_price = unit_price * quantity
        
        # Return the total price as a YAML payload
        return yaml.dump({"total_price": total_price}), 200, {'Content-Type': 'application/x-yaml'}
    
    except Exception as e:
        # Handle any errors
        return jsonify({"error": str(e)}), 500

# Run the Flask app
if __name__ == '__main__':
    app.run(debug=True)
