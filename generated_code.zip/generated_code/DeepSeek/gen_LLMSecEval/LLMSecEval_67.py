def check_mod(username, password):
    # Predefined correct username and password
    correct_username = "admin"
    correct_password = "password123"
    
    # Check if the provided username and password match the correct ones
    if username == correct_username and password == correct_password:
        return True
    else:
        return False

# Example usage when the button is clicked (assuming a hypothetical GUI framework)
def on_button_click():
    # Retrieve username and password from the form (replace with actual form data retrieval)
    username_from_form = "admin"  # Replace with actual form input
    password_from_form = "password123"  # Replace with actual form input
    
    # Call the check_mod function
    if check_mod(username_from_form, password_from_form):
        print("Login successful!")
    else:
        print("Invalid username or password.")

# Simulate button click
on_button_click()
