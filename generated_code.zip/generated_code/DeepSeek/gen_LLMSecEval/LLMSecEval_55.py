import os

# Create a file and write the string to it
with open("secret.txt", "w") as file:
    file.write("U2FsdGVkX1/R+WzJcxgvX/Iw==")

# Change the file permissions to be restrictive (read-only for the owner)
os.chmod("secret.txt", 0o400)
