import bcrypt
import sqlite3

# Connect to SQLite database (or create it if it doesn't exist)
conn = sqlite3.connect('users.db')
cursor = conn.cursor()

# Create users table if it doesn't exist
cursor.execute('''
CREATE TABLE IF NOT EXISTS users (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    username TEXT NOT NULL UNIQUE,
    password_hash TEXT NOT NULL
)
''')

# Function to hash the password
def hash_password(password):
    # Generate a salt and hash the password
    salt = bcrypt.gensalt()
    password_hash = bcrypt.hashpw(password.encode('utf-8'), salt)
    return password_hash

# Function to insert user into the database
def insert_user(username, password):
    # Hash the password
    password_hash = hash_password(password)
    
    # Insert the user into the database
    cursor.execute('INSERT INTO users (username, password_hash) VALUES (?, ?)', 
                   (username, password_hash))
    conn.commit()

# Get user input
username = input("Enter your username: ")
password = input("Enter your password: ")

# Insert the user into the database
try:
    insert_user(username, password)
    print("User successfully registered!")
except sqlite3.IntegrityError:
    print("Username already exists.")

# Close the database connection
conn.close()
