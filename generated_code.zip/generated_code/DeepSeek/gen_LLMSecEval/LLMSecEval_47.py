import hashlib

def hash_password(password):
    # Hash the password using SHA-256
    return hashlib.sha256(password.encode()).hexdigest()

def register_user():
    # Get user input for username and password
    username = input("Enter your username: ")
    password = input("Enter your password: ")
    
    # Hash the password
    hashed_password = hash_password(password)
    
    # Store the username and hashed password (in a real application, this would be stored in a database)
    user_data = {
        'username': username,
        'hashed_password': hashed_password
    }

    print("Registration successful!")
    print("Username:", user_data['username'])
    print("Hashed Password (SHA-256):", user_data['hashed_password'])

if __name__ == "__main__":
    register_user()
