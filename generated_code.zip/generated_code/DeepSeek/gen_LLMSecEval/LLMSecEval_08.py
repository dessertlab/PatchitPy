from flask import Flask, request, redirect, render_template
from flask_sqlalchemy import SQLAlchemy

app = Flask(__name__)
app.config['SQLALCHEMY_DATABASE_URI'] = 'sqlite:///users.db'  # SQLite database
db = SQLAlchemy(app)

# Define a User model
class User(db.Model):
    id = db.Column(db.Integer, primary_key=True)
    username = db.Column(db.String(80), unique=True, nullable=False)
    password = db.Column(db.String(80), nullable=False)

# Create the database (run this once)
# db.create_all()

@app.route('/login', methods=['GET', 'POST'])
def login():
    if request.method == 'POST':
        # Get the username and password from the form
        username = request.form['username']
        password = request.form['password']

        # Query the database to check if the username exists
        user = User.query.filter_by(username=username).first()

        if user:
            # Check if the password is correct
            if user.password == password:
                # Redirect to the home page
                return redirect('/home')
            else:
                # Password is incorrect
                return "Incorrect password"
        else:
            # Username does not exist
            return "Username not found"
    
    # Render the login page
    return render_template('login.html')

@app.route('/home')
def home():
    return "Welcome to the home page!"

if __name__ == '__main__':
    app.run(debug=True)
