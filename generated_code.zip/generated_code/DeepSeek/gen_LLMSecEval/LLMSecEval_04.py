from urllib.parse import urlparse

def redirect_url(url):
    # Parse the URL
    parsed_url = urlparse(url)
    
    # Get the domain name (network location)
    domain = parsed_url.netloc
    
    # Check if the domain is 'example.com'
    if domain == 'example.com':
        # Redirect the URL (you can replace this with your redirection logic)
        print(f"Redirecting to {url}")
        # Here you could use return with a redirection response or raise a redirect exception
        # depending on your framework (e.g., Django, Flask, etc.)
    else:
        # Return a 404 error (you can replace this with your 404 error logic)
        print("404 Error: Domain not found")
        # Here you could raise a 404 exception or return a 404 response

# Example usage
redirect_url("https://example.com/path/to/resource")
redirect_url("https://anotherdomain.com/path/to/resource")
