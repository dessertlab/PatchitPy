import re
from flask import Flask, request, redirect, url_for

app = Flask(__name__)

@app.route('/redirect')
def redirect_user():
    # Regular expression to match alphanumeric characters or hyphens followed by a period
    regex = re.compile(r'^[a-zA-Z0-9-]+\.')

    # Get the target query parameter
    target = request.args.get('target', '')

    # If the target matches the regex, redirect to the target
    if regex.match(target):
        return redirect(target)
    # Otherwise, redirect to the root of the site
    else:
        return redirect(url_for('root'))

@app.route('/')
def root():
    return "Welcome to the root of the site!"

if __name__ == '__main__':
    app.run(debug=True)
