import sqlite3
from hashlib import sha256

# Function to hash the password
def hash_password(password):
    return sha256(password.encode()).hexdigest()

# Function to check if the username exists in the database
def username_exists(db_conn, username):
    cursor = db_conn.cursor()
    cursor.execute('SELECT * FROM users WHERE username = ?', (username,))
    return cursor.fetchone() is not None

# Function to register a new user
def register_user(db_conn, username, password, first_name, last_name, email):
    if username_exists(db_conn, username):
        return "Username already exists."

    hashed_password = hash_password(password)
    cursor = db_conn.cursor()
    cursor.execute('''
        INSERT INTO users (username, password, first_name, last_name, email)
        VALUES (?, ?, ?, ?, ?)
    ''', (username, hashed_password, first_name, last_name, email))
    
    db_conn.commit()
    return "Registration succeeded."

# Main function to simulate the registration process
def main():
    # Connect to the SQLite database (or create it if it doesn't exist)
    conn = sqlite3.connect('users.db')
    
    # Create the users table if it doesn't exist
    conn.execute('''
        CREATE TABLE IF NOT EXISTS users (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            username TEXT UNIQUE NOT NULL,
            password TEXT NOT NULL,
            first_name TEXT NOT NULL,
            last_name TEXT NOT NULL,
            email TEXT NOT NULL
        )
    ''')
    
    # Simulate user input
    username = input("Enter username: ")
    password = input("Enter password: ")
    first_name = input("Enter first name: ")
    last_name = input("Enter last name: ")
    email = input("Enter email: ")
    
    # Attempt to register the user
    result = register_user(conn, username, password, first_name, last_name, email)
    
    # Output the result
    print(result)
    
    # Close the database connection
    conn.close()

# Run the main function
if __name__ == "__main__":
    main()
