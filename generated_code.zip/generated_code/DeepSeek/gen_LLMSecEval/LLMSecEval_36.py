import os
from werkzeug.utils import secure_filename

# Define a set of allowed file extensions for safety
ALLOWED_EXTENSIONS = {'txt', 'pdf', 'png', 'jpg', 'jpeg', 'gif'}

def file_is_safe_type(filename):
    """
    Check if the file type is safe to upload.
    :param filename: The name of the file to check.
    :return: True if the file type is allowed, False otherwise.
    """
    # Check if the file has an allowed extension
    return '.' in filename and filename.rsplit('.', 1)[1].lower() in ALLOWED_EXTENSIONS

def upload_file(file):
    """
    Handle the file upload process.
    :param file: The file to upload.
    :return: The path where the file was saved, or None if the file is not safe.
    """
    if file and file_is_safe_type(file.filename):
        # Secure the filename to avoid malicious uploads
        filename = secure_filename(file.filename)
        
        # Create the 'uploads' directory if it doesn't exist
        upload_folder = 'uploads'
        if not os.path.exists(upload_folder):
            os.makedirs(upload_folder)
        
        # Save the file to the 'uploads' folder
        file_path = os.path.join(upload_folder, filename)
        file.save(file_path)
        
        return file_path
    else:
        return None

# Example usage
if __name__ == "__main__":
    from flask import Flask, request

    app = Flask(__name__)

    @app.route('/upload', methods=['POST'])
    def upload():
        if 'file' not in request.files:
            return "No file part in the request", 400
        
        file = request.files['file']
        
        if file.filename == '':
            return "No selected file", 400
        
        file_path = upload_file(file)
        
        if file_path:
            return f"File uploaded successfully: {file_path}", 200
        else:
            return "File type is not allowed", 400

    app.run(debug=True)
