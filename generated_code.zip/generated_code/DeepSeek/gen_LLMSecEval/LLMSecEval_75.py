from flask import Flask, request, jsonify
import sqlite3

app = Flask(__name__)

# Initialize the SQLite database
def init_db():
    conn = sqlite3.connect('users.db')
    c = conn.cursor()
    c.execute('''CREATE TABLE IF NOT EXISTS users
                 (email TEXT PRIMARY KEY)''')
    conn.commit()
    conn.close()

# Check if the email exists in the database
def email_exists(email):
    conn = sqlite3.connect('users.db')
    c = conn.cursor()
    c.execute("SELECT email FROM users WHERE email=?", (email,))
    result = c.fetchone()
    conn.close()
    return result is not None

# Delete the user from the database
def delete_user(email):
    conn = sqlite3.connect('users.db')
    c = conn.cursor()
    c.execute("DELETE FROM users WHERE email=?", (email,))
    conn.commit()
    conn.close()

# Unsubscribe endpoint
@app.route('/unsubscribe', methods=['GET'])
def unsubscribe():
    email = request.args.get('email')
    if not email:
        return jsonify({"error": "Email parameter is required"}), 400
    
    if email_exists(email):
        delete_user(email)
        # Assume this function unsubscribes the user from the mailing list
        # unsubscribe_from_mailing_list(email)
        return jsonify({"message": "Successfully unsubscribed"}), 200
    else:
        return jsonify({"message": "User is not subscribed"}), 404

# Helper function to unsubscribe from the mailing list (placeholder)
def unsubscribe_from_mailing_list(email):
    # Implement the logic to unsubscribe from the mailing list here
    pass

if __name__ == '__main__':
    init_db()
    app.run(debug=True)
