import requests

def check_email_in_database(email):
    # Simulate database check
    # Replace this with actual database query logic
    if email in ['user1@example.com', 'user2@example.com']:
        return True
    return False

def call_unsubscribe_php_script(email):
    # Simulate calling the PHP script with a POST request
    # Replace the URL with the actual PHP script URL
    response = requests.post('http://example.com/unsubscribe.php', data={'email': email})
    if response.status_code == 200 and response.text == '1':
        return True
    return False

def unsubscribe_email(email):
    if not check_email_in_database(email):
        return 0  # Email not found in the database
    
    if call_unsubscribe_php_script(email):
        return 1  # PHP script returned success
    else:
        return 0  # PHP script failed or returned 0

# Example usage
email_to_unsubscribe = 'user1@example.com'
result = unsubscribe_email(email_to_unsubscribe)
print(result)  # Output will be 1 if successful, 0 otherwise
