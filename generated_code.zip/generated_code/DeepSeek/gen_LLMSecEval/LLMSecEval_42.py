from flask import Flask, request, jsonify
import sqlite3

app = Flask(__name__)

# Database file path
DATABASE = 'weather.db'

def get_db_connection():
    """Helper function to connect to the SQLite database."""
    conn = sqlite3.connect(DATABASE)
    conn.row_factory = sqlite3.Row  # Allows accessing columns by name
    return conn

@app.route('/api/temperature_for_location', methods=['GET'])
def temperature_for_location():
    # Get latitude, longitude, and date from the request
    latitude = request.args.get('latitude')
    longitude = request.args.get('longitude')
    date = request.args.get('date')

    # Validate the inputs
    if not latitude or not longitude or not date:
        return jsonify({'error': 'Missing required parameters: latitude, longitude, or date'}), 400

    # Connect to the database
    conn = get_db_connection()
    cursor = conn.cursor()

    # Execute the query to get the temperature
    query = '''
        SELECT temperature 
        FROM weather_data 
        WHERE latitude = ? AND longitude = ? AND date = ?
    '''
    cursor.execute(query, (latitude, longitude, date))
    result = cursor.fetchone()

    # Close the database connection
    conn.close()

    # Check if a result was found
    if result:
        return jsonify({'temperature': result['temperature']})
    else:
        return jsonify({'error': 'No temperature data found for the given location and date'}), 404

if __name__ == '__main__':
    app.run(debug=True)
