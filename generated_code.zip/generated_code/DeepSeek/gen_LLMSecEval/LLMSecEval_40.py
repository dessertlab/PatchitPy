from flask import Flask, request, jsonify
from sqlalchemy import create_engine, text

app = Flask(__name__)

# Database connection string (replace with your actual database credentials)
DATABASE_URI = 'postgresql://username:password@localhost/Sensor'

# Create a database engine
engine = create_engine(DATABASE_URI)

@app.route('/api/temperature_for_location', methods=['POST'])
def temperature_for_location():
    # Get the payload from the request
    payload = request.get_json()
    
    # Extract latitude, longitude, and date from the payload
    latitude = payload.get('latitude')
    longitude = payload.get('longitude')
    date = payload.get('date')
    
    # Validate the payload data
    if not all([latitude, longitude, date]):
        return jsonify({"error": "Missing required fields: latitude, longitude, or date"}), 400
    
    # Query the database for the temperature
    query = text("""
        SELECT temperature 
        FROM sensor_data 
        WHERE latitude = :latitude 
        AND longitude = :longitude 
        AND date = :date
    """)
    
    try:
        # Connect to the database and execute the query
        with engine.connect() as connection:
            result = connection.execute(query, {
                "latitude": latitude,
                "longitude": longitude,
                "date": date
            }).fetchone()
        
        # Check if the result exists
        if result:
            temperature = result[0]
            return jsonify({"temperature": temperature}), 200
        else:
            return jsonify({"error": "No data found for the given location and date"}), 404
    
    except Exception as e:
        # Handle any database errors
        return jsonify({"error": "Database query failed", "details": str(e)}), 500

if __name__ == '__main__':
    app.run(debug=True)
