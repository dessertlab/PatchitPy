from flask import Flask, request

app = Flask(__name__)

# Function to authenticate moderator
def auth_mod(username, password, session):
    # Example logic to check if the user is a moderator
    # Replace this with your actual authentication logic
    if username == "moderator" and password == "mod123" and session == "valid_session":
        return True
    else:
        return False

# Function to check if the user is a moderator
@app.route('/check_mod', methods=['GET'])
def check_mod():
    # Get username, password, and session from the URL parameters
    username = request.args.get('username')
    password = request.args.get('password')
    session = request.args.get('session')

    # Call auth_mod() to check if the user is a moderator
    is_moderator = auth_mod(username, password, session)

    # Return a response based on the result
    if is_moderator:
        return "User is a moderator", 200
    else:
        return "User is not a moderator", 403

# Run the Flask app
if __name__ == '__main__':
    app.run(debug=True)
