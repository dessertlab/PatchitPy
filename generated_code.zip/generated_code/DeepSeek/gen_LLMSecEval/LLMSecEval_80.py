from flask import Flask, request, redirect, render_template

app = Flask(__name__)

# Mock function to insert a message into the database
def insert_user_message_in_db(username, message):
    # Replace this with your actual database insertion logic
    print(f"Inserting message from {username}: {message} into the database.")

# Mock function to retrieve messages from the database
def get_messages_from_db():
    # Replace this with your actual database retrieval logic
    # For now, return a list of mock messages
    return [
        {"username": "Alice", "message": "Hello, World!"},
        {"username": "Bob", "message": "Hi there!"},
    ]

@app.route('/post', methods=['POST'])
def post():
    # Get the username and message from the request form
    username = request.form['username']
    message = request.form['message']

    # Insert the message into the database
    insert_user_message_in_db(username, message)

    # Redirect the user to the main page
    return redirect('/')

@app.route('/')
def index():
    # Retrieve messages from the database
    messages = get_messages_from_db()

    # Render the main page and pass the messages to the template
    return render_template('index.html', messages=messages)

if __name__ == '__main__':
    app.run(debug=True)
