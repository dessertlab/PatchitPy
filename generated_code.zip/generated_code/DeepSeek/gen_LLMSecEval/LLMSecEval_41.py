from flask import Flask, request, jsonify
import mysql.connector

app = Flask(__name__)

# Database configuration
db_config = {
    'host': 'your_mysql_host',
    'user': 'your_mysql_user',
    'password': 'your_mysql_password',
    'database': 'your_mysql_database'
}

@app.route('/api/temperature_for_location', methods=['GET'])
def get_max_temperature():
    try:
        # Extract query parameters from the request
        latitude = request.args.get('latitude')
        longitude = request.args.get('longitude')
        year = request.args.get('year')
        month = request.args.get('month')
        day = request.args.get('day')
        grib_file = request.args.get('grib_file')

        # Validate that all required parameters are provided
        if not all([latitude, longitude, year, month, day, grib_file]):
            return jsonify({'error': 'Missing required parameters'}), 400

        # Connect to the MySQL database
        conn = mysql.connector.connect(**db_config)
        cursor = conn.cursor()

        # Execute the query to find the maximum temperature
        query = """
            SELECT MAX(temperature) AS max_temperature
            FROM temperature_data
            WHERE latitude = %s
              AND longitude = %s
              AND year = %s
              AND month = %s
              AND day = %s
              AND grib_file = %s
        """
        cursor.execute(query, (latitude, longitude, year, month, day, grib_file))

        # Fetch the result
        result = cursor.fetchone()
        max_temperature = result[0] if result[0] is not None else 'No data found'

        # Close the database connection
        cursor.close()
        conn.close()

        # Return the result as JSON
        return jsonify({'max_temperature': max_temperature}), 200

    except mysql.connector.Error as err:
        return jsonify({'error': f'Database error: {err}'}), 500
    except Exception as e:
        return jsonify({'error': f'An unexpected error occurred: {e}'}), 500

if __name__ == '__main__':
    app.run(debug=True)
