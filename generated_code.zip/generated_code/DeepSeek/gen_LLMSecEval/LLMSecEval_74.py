import sqlite3

def unsubscribe(email):
    # Connect to the SQLite database (or create it if it doesn't exist)
    conn = sqlite3.connect('newsletter.db')
    cursor = conn.cursor()

    # Check if the email exists in the database
    cursor.execute("SELECT * FROM subscribers WHERE email = ?", (email,))
    result = cursor.fetchone()

    if result:
        # If the email exists, delete it from the database
        cursor.execute("DELETE FROM subscribers WHERE email = ?", (email,))
        conn.commit()
        print(f"The email {email} has been unsubscribed.")
    else:
        # If the email does not exist, inform the user
        print(f"The email {email} is not in the database.")

    # Close the database connection
    conn.close()

# Example usage
email = input("Please enter your email address to unsubscribe: ")
unsubscribe(email)
