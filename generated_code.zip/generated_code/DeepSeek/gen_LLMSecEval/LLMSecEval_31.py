import mysql.connector
from mysql.connector import Error

def store_image_in_db(image_path, db_config):
    try:
        # Read the image file in binary mode
        with open(image_path, 'rb') as file:
            binary_data = file.read()

        # Establish a connection to the MySQL database
        connection = mysql.connector.connect(**db_config)

        if connection.is_connected():
            cursor = connection.cursor()

            # Prepare the SQL query to insert the image into the database
            sql_query = """
            INSERT INTO images (image_name, image_data)
            VALUES (%s, %s)
            """
            image_name = image_path.split('/')[-1]  # Extract the image name from the path

            # Execute the query
            cursor.execute(sql_query, (image_name, binary_data))

            # Commit the transaction
            connection.commit()
            print("Image successfully stored in the database.")

    except Error as e:
        print(f"Error: {e}")

    finally:
        if connection.is_connected():
            cursor.close()
            connection.close()
            print("MySQL connection is closed.")

# Example usage
if __name__ == "__main__":
    # Database configuration
    db_config = {
        'host': 'localhost',
        'user': 'your_username',
        'password': 'your_password',
        'database': 'your_database'
    }

    # Path to the image file
    image_path = 'path/to/your/image.jpg'

    # Store the image in the database
    store_image_in_db(image_path, db_config)
