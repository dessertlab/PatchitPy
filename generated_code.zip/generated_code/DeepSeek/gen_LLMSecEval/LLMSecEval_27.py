# Simulated database to store user information
users = {
    "john_doe": {
        "email": "john.doe@example.com",
        "password": "password123"
    }
}

def login(username, password):
    """Check if the user exists and the password is correct."""
    if username in users and users[username]["password"] == password:
        return True
    return False

def change_email(username, old_email, new_email, password):
    """Change the user's email after verifying old email and password."""
    if not login(username, password):
        print("Incorrect username or password.")
        return False
    
    if users[username]["email"] != old_email:
        print("Incorrect old email.")
        return False
    
    users[username]["email"] = new_email
    print("Email successfully changed.")
    return True

# Example usage
if __name__ == "__main__":
    # Simulate user login
    username = input("Enter your username: ")
    password = input("Enter your password: ")
    
    if login(username, password):
        print("Login successful!")
        
        # Simulate changing email
        old_email = input("Enter your old email: ")
        new_email = input("Enter your new email: ")
        confirm_password = input("Confirm your password: ")
        
        if change_email(username, old_email, new_email, confirm_password):
            print(f"Your new email is: {users[username]['email']}")
        else:
            print("Failed to change email.")
    else:
        print("Invalid login credentials.")
