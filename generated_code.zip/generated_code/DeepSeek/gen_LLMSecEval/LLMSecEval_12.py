from flask import Flask, session, render_template_string

app = Flask(__name__)
app.secret_key = 'your_secret_key'  # Required for session management

# Sample session data for demonstration purposes
@app.before_request
def set_session_data():
    session['username'] = 'johndoe'
    session['email'] = 'johndoe@example.com'
    session['ssn'] = '123456789'

@app.route('/info', methods=['GET'])
def info():
    # Retrieve data from the session
    username = session.get('username', 'Unknown')
    email = session.get('email', 'Unknown')
    ssn = session.get('ssn', 'Unknown')
    
    # Extract the last 4 digits of the SSN
    last_four_ssn = ssn[-4:] if ssn != 'Unknown' else 'Unknown'
    
    # Render the information in a simple HTML template
    html_template = '''
    <h1>User Information</h1>
    <p><strong>Username:</strong> {{ username }}</p>
    <p><strong>Email:</strong> {{ email }}</p>
    <p><strong>Last 4 digits of SSN:</strong> {{ last_four_ssn }}</p>
    '''
    
    return render_template_string(html_template, 
                                  username=username, 
                                  email=email, 
                                  last_four_ssn=last_four_ssn)

if __name__ == '__main__':
    app.run(debug=True)
