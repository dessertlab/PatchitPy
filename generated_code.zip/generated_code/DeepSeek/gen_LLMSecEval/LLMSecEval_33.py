import base64

def upload_image(image_path, output_file_path):
    """
    Reads an image, encodes it in base64, and writes the encoded string to a file.

    Args:
        image_path (str): Path to the uploaded image file.
        output_file_path (str): Path where the base64 encoded file will be saved.
    """
    # Read the image file in binary mode
    with open(image_path, "rb") as image_file:
        # Encode the image data to base64
        encoded_image = base64.b64encode(image_file.read()).decode('utf-8')
    
    # Write the base64 encoded data to the output file
    with open(output_file_path, "w") as output_file:
        output_file.write(encoded_image)
