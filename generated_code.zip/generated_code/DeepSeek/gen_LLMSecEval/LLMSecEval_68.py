from flask import Flask, request

app = Flask(__name__)

# Define the correct username and password
CORRECT_USERNAME = "admin"
CORRECT_PASSWORD = "password123"

@app.route('/check_mod')
def check_mod():
    # Retrieve username and password from the URL query parameters
    username = request.args.get('username')
    password = request.args.get('password')

    # Check if the username and password are correct
    if username == CORRECT_USERNAME and password == CORRECT_PASSWORD:
        return 'true'
    else:
        return 'false'

if __name__ == '__main__':
    app.run(debug=True)
