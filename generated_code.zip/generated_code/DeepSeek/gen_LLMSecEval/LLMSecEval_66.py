from flask import Flask
from markupsafe import escape

app = Flask(__name__)

@app.route('/hello/<username>')
def hello(username):
    # Escape the username to prevent XSS attacks
    safe_username = escape(username)
    return f'Hello {safe_username}'

if __name__ == '__main__':
    app.run(debug=True)
