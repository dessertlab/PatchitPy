from flask import Flask, request, send_from_directory
import os
import mysql.connector

app = Flask(__name__)

# Configuration for the upload folder and allowed file extensions
app.config['UPLOAD_FOLDER'] = 'uploads'
app.config['ALLOWED_EXTENSIONS'] = {'pdf'}

# Database configuration
db_config = {
    'host': 'localhost',
    'user': 'root',
    'password': 'password',
    'database': 'file_storage'
}

# Function to check if the file extension is allowed
def allowed_file(filename):
    return '.' in filename and filename.rsplit('.', 1)[1].lower() in app.config['ALLOWED_EXTENSIONS']

# Function to upload PDF and save the filepath in MySQL
@app.route('/upload_pdf', methods=['POST'])
def upload_pdf():
    if 'file' not in request.files:
        return "No file part in the request", 400

    file = request.files['file']

    if file.filename == '':
        return "No selected file", 400

    if file and allowed_file(file.filename):
        # Ensure the uploads folder exists
        if not os.path.exists(app.config['UPLOAD_FOLDER']):
            os.makedirs(app.config['UPLOAD_FOLDER'])

        # Save the file to the uploads folder
        filepath = os.path.join(app.config['UPLOAD_FOLDER'], file.filename)
        file.save(filepath)

        # Save the filepath in the MySQL database
        connection = mysql.connector.connect(**db_config)
        cursor = connection.cursor()

        query = "INSERT INTO files (filepath) VALUES (%s)"
        cursor.execute(query, (filepath,))
        connection.commit()

        cursor.close()
        connection.close()

        return f"File uploaded and saved successfully. Filepath: {filepath}", 200
    else:
        return "Invalid file type. Only PDF files are allowed.", 400

# Function to download the PDF file by its ID
@app.route('/download_pdf/<int:file_id>', methods=['GET'])
def download_pdf(file_id):
    connection = mysql.connector.connect(**db_config)
    cursor = connection.cursor()

    query = "SELECT filepath FROM files WHERE id = %s"
    cursor.execute(query, (file_id,))
    result = cursor.fetchone()

    cursor.close()
    connection.close()

    if result:
        filepath = result[0]
        return send_from_directory(os.path.dirname(filepath), os.path.basename(filepath), as_attachment=True)
    else:
        return "File not found", 404

if __name__ == '__main__':
    app.run(debug=True)
