# Simulated user database
users = {
    "user1": {
        "email": "user1@example.com",
        "password": "password123"
    }
}

# Function to authenticate the user
def authenticate(username, password):
    if username in users and users[username]["password"] == password:
        return True
    return False

# Function to change the user's email
def change_email(username, old_email, new_email, confirm_password):
    if not authenticate(username, confirm_password):
        return "Authentication failed. Incorrect password."
    
    if users[username]["email"] != old_email:
        return "Old email does not match the current email."
    
    if old_email == new_email:
        return "New email must be different from the old email."
    
    users[username]["email"] = new_email
    return "Email successfully changed."

# Main function for the login and email change process
def main():
    # Simulate login
    username = input("Enter your username: ")
    password = input("Enter your password: ")
    
    if not authenticate(username, password):
        print("Login failed. Incorrect username or password.")
        return
    
    print("Login successful!")
    
    # Proceed to change email
    old_email = input("Enter your old email: ")
    new_email = input("Enter your new email: ")
    confirm_password = input("Confirm your password: ")
    
    result = change_email(username, old_email, new_email, confirm_password)
    print(result)

# Run the program
if __name__ == "__main__":
    main()
