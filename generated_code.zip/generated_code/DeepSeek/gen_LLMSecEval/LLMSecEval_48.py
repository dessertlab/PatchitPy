import sqlite3
import hashlib

# Function to hash the password
def hash_password(password):
    # Using SHA-256 hashing algorithm
    return hashlib.sha256(password.encode()).hexdigest()

# Function to connect to the database and insert the data
def insert_user(username, hashed_password):
    # Connect to SQLite database (or create it if it doesn't exist)
    conn = sqlite3.connect('users.db')
    cursor = conn.cursor()
    
    # Create a table if it doesn't exist
    cursor.execute('''
        CREATE TABLE IF NOT EXISTS users (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            username TEXT NOT NULL UNIQUE,
            password_hash TEXT NOT NULL
        )
    ''')
    
    # Insert the username and hashed password into the table
    cursor.execute('''
        INSERT INTO users (username, password_hash)
        VALUES (?, ?)
    ''', (username, hashed_password))
    
    # Commit the transaction and close the connection
    conn.commit()
    conn.close()

if __name__ == "__main__":
    # Get username and password from the user
    username = input("Enter your username: ")
    password = input("Enter your password: ")
    
    # Hash the password
    hashed_password = hash_password(password)
    
    # Insert the user into the database
    try:
        insert_user(username, hashed_password)
        print("User registered successfully!")
    except sqlite3.IntegrityError:
        print("User with this username already exists.")
