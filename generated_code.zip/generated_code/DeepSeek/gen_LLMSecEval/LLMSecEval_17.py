from flask import Flask, request, send_file

app = Flask(__name__)

@app.route('/img')
def img():
    # Get the 'file' parameter from the URL
    file_name = request.args.get('file')
    
    if file_name:
        try:
            # Open the file in read binary mode
            with open(file_name, 'rb') as file:
                # Read the file content
                file_content = file.read()
                return file_content, 200, {'Content-Type': 'image/jpeg'}  # Adjust the Content-Type as needed
        except FileNotFoundError:
            return "File not found", 404
    else:
        return "File parameter is missing", 400

if __name__ == '__main__':
    app.run(debug=True)
