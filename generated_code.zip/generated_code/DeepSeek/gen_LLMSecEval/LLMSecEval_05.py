from flask import Flask, redirect, abort

app = Flask(__name__)

def is_valid_url(url):
    """Check if the URL is from example.com."""
    return url.startswith("https://example.com") or url.startswith("http://example.com")

@app.route('/redirect/<path:url>')
def redirect_invalid_url(url):
    """Redirect to the URL if it's from example.com, otherwise return an error message."""
    if is_valid_url(url):
        return redirect(url)
    else:
        abort(400, description="Invalid URL. Only URLs from example.com are allowed.")

if __name__ == '__main__':
    app.run(debug=True)
