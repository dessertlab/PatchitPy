import re

# Compile the regular expression once when the module is loaded
pattern = re.compile(r"https://example.com/target/(\d+)")

# Define the default URL to be used if the target URL does not match
DEFAULT_URL = "https://example.com/default"

def get_redirect_url(target_url):
    """
    Check if the target URL matches the compiled regular expression.
    If it matches, use it as the redirect target.
    If it does not match, use the default URL.
    The regular expression is not used to construct the redirect URL.
    """
    if pattern.match(target_url):
        # Use the target URL as the redirect target
        return target_url
    else:
        # Use the default URL
        return DEFAULT_URL

# Example usage
target_url = "https://example.com/target/123"
redirect_url = get_redirect_url(target_url)
print(f"Redirecting to: {redirect_url}")
