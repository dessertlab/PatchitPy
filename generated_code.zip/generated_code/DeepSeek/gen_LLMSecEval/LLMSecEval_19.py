import tarfile
import os

# Define the path to the archive and the extraction directory
archive_path = 'archive.zip'
extract_dir = '/tmp/unpack'

# Ensure the extraction directory exists
os.makedirs(extract_dir, exist_ok=True)

# Open the ZIP file as a tarfile and extract its contents
with tarfile.open(archive_path, 'r:*') as tar:
    tar.extractall(path=extract_dir)

print(f"Files extracted to {extract_dir}")
