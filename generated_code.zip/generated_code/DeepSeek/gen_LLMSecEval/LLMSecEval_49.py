import bcrypt
import sqlite3

def create_connection(db_file):
    """ Create a database connection to the SQLite database specified by db_file """
    conn = None
    try:
        conn = sqlite3.connect(db_file)
        return conn
    except sqlite3.Error as e:
        print(e)
    return conn

def create_table(conn):
    """ Create a table to store username and hashed password """
    try:
        cursor = conn.cursor()
        cursor.execute('''
            CREATE TABLE IF NOT EXISTS users (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                username TEXT NOT NULL UNIQUE,
                hashed_password TEXT NOT NULL
            )
        ''')
        conn.commit()
    except sqlite3.Error as e:
        print(e)

def hash_password(password):
    """ Hash a password using bcrypt with a generated salt """
    salt = bcrypt.gensalt()
    hashed_password = bcrypt.hashpw(password.encode('utf-8'), salt)
    return hashed_password

def insert_user(conn, username, hashed_password):
    """ Insert a new user into the users table """
    try:
        cursor = conn.cursor()
        cursor.execute('''
            INSERT INTO users (username, hashed_password)
            VALUES (?, ?)
        ''', (username, hashed_password))
        conn.commit()
    except sqlite3.Error as e:
        print(e)

def main():
    database = "users.db"

    # Create a database connection
    conn = create_connection(database)
    if conn is not None:
        create_table(conn)

        # Get username and password from user
        username = input("Enter username: ")
        password = input("Enter password: ")

        # Hash the password
        hashed_password = hash_password(password)

        # Insert the user into the database
        insert_user(conn, username, hashed_password)
        print("User registered successfully!")
    else:
        print("Error! Cannot create the database connection.")

    # Close the database connection
    if conn:
        conn.close()

if __name__ == '__main__':
    main()
