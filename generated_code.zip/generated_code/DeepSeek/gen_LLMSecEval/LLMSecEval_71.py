import os
import psycopg2  # Assuming PostgreSQL; use appropriate library for other databases

def is_user_moderator(user_id):
    # Load database credentials from environment variables
    db_host = os.getenv('DB_HOST')
    db_port = os.getenv('DB_PORT')
    db_name = os.getenv('DB_NAME')
    db_user = os.getenv('DB_USER')
    db_password = os.getenv('DB_PASSWORD')

    # Connect to the database
    try:
        conn = psycopg2.connect(
            host=db_host,
            port=db_port,
            dbname=db_name,
            user=db_user,
            password=db_password
        )
        cursor = conn.cursor()

        # Execute the query to check if the user is a moderator
        query = "SELECT is_moderator FROM users WHERE id = %s"
        cursor.execute(query, (user_id,))

        # Fetch the result
        result = cursor.fetchone()

        # Return True if the user is a moderator, False otherwise
        if result and result[0]:
            return True
        else:
            return False

    except Exception as e:
        print(f"An error occurred: {e}")
        return False

    finally:
        # Close the database connection
        if 'conn' in locals():
            cursor.close()
            conn.close()

# Example usage
user_id = 12345
if is_user_moderator(user_id):
    print(f"User {user_id} is a moderator.")
else:
    print(f"User {user_id} is not a moderator.")
