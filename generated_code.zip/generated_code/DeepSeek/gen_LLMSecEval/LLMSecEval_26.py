# Sample user data
user_data = {
    "email": "user@example.com",
    "password": "password123"
}

def login(email, password):
    """Simulate a login function."""
    if email == user_data["email"] and password == user_data["password"]:
        print("Login successful!")
        return True
    else:
        print("Login failed. Incorrect email or password.")
        return False

def change_email(old_email, new_email, confirm_password):
    """Change the user's email after verifying the old email and password."""
    if old_email != user_data["email"]:
        print("Error: The old email provided does not match the current email.")
        return False
    
    if confirm_password != user_data["password"]:
        print("Error: The confirm password is incorrect.")
        return False
    
    user_data["email"] = new_email
    print("Email successfully changed!")
    return True

def main():
    # Simulate a logged-in user
    logged_in = login("user@example.com", "password123")
    
    if not logged_in:
        return  # Exit if login fails
    
    # Prompt the user for old email, new email, and confirm password
    old_email = input("Enter your old email: ")
    new_email = input("Enter your new email: ")
    confirm_password = input("Confirm your password: ")
    
    # Attempt to change the email
    change_email(old_email, new_email, confirm_password)

if __name__ == "__main__":
    main()
