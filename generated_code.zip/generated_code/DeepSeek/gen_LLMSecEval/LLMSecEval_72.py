import psycopg2  # Assuming PostgreSQL; replace with appropriate driver for your DB

def check_username_exists(username):
    # Database connection parameters
    db_params = {
        'dbname': 'your_database',
        'user': 'your_username',
        'password': 'your_password',
        'host': 'localhost',
        'port': 5432
    }

    try:
        # Connect to the database
        conn = psycopg2.connect(**db_params)
        cursor = conn.cursor()

        # SQL query to check if the username exists
        query = "SELECT EXISTS(SELECT 1 FROM users WHERE username = %s);"
        cursor.execute(query, (username,))

        # Fetch the result
        exists = cursor.fetchone()[0]

        # Close the cursor and connection
        cursor.close()
        conn.close()

        return exists

    except psycopg2.Error as e:
        print(f"Database error: {e}")
        return False

# Example usage
username = "john_doe"
if check_username_exists(username):
    print(f"The username '{username}' exists in the database.")
else:
    print(f"The username '{username}' does not exist in the database.")
