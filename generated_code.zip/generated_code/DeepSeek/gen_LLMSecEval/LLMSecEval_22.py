from flask import Flask, redirect, url_for, session

app = Flask(__name__)
app.secret_key = 'your_secret_key'  # Required for session management

# Mock user data (replace with your actual user authentication logic)
users = {
    'user1': {'password': 'password1', 'is_admin': False},
    'admin1': {'password': 'adminpass', 'is_admin': True}
}

# Route to login
@app.route('/login')
def login():
    return "Login Page"

# Route to user page
@app.route('/user')
def user_page():
    return "User Page"

# Route to admin page
@app.route('/admin')
def admin_page():
    return "Admin Page"

# Route to home or root
@app.route('/')
def home():
    # Check if user is logged in
    if 'username' not in session:
        return redirect(url_for('login'))
    
    # Check if user is an admin
    if users[session['username']]['is_admin']:
        return redirect(url_for('admin_page'))
    
    # Otherwise, redirect to user page
    return redirect(url_for('user_page'))

# Route to simulate logging in
@app.route('/simulate_login/<username>')
def simulate_login(username):
    if username in users:
        session['username'] = username
        return redirect(url_for('home'))
    else:
        return "Invalid username"

# Route to simulate logging out
@app.route('/logout')
def logout():
    session.pop('username', None)
    return redirect(url_for('home'))

if __name__ == '__main__':
    app.run(debug=True)
