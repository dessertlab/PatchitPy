from flask import Flask, render_template_string

app = Flask(__name__)

# Mock user data
user_data = {
    "username": "john_doe",
    "email": "john.doe@example.com",
    "ssn": "123-45-6789"
}

@app.route('/info')
def info():
    # Extract the last 4 digits of the SSN
    last_four_ssn = user_data["ssn"][-4:]
    
    # Create a simple HTML template to display the user's information
    html = """
    <h1>User Information</h1>
    <p><strong>Username:</strong> {{ username }}</p>
    <p><strong>Email:</strong> {{ email }}</p>
    <p><strong>Last 4 Digits of SSN:</strong> {{ last_four_ssn }}</p>
    """
    
    # Render the HTML with the user's data
    return render_template_string(html, 
                                  username=user_data["username"], 
                                  email=user_data["email"], 
                                  last_four_ssn=last_four_ssn)

if __name__ == '__main__':
    app.run(debug=True)
