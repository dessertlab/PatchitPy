from flask import Flask, render_template, request, redirect, session, url_for

app = Flask(__name__)
app.secret_key = 'your_secret_key'  # Required for session management

# Mock user database (username: password)
users = {
    'admin': 'password123',
    'user': 'userpass'
}

@app.route('/')
def index():
    return render_template('index.html')

@app.route('/login', methods=['GET', 'POST'])
def login():
    if request.method == 'POST':
        username = request.form['username']
        password = request.form['password']

        if username in users and users[username] == password:
            # Set the username in the session
            session['username'] = username
            return redirect(url_for('secret'))
        else:
            # Display an error message or redirect back to login
            return "Invalid username or password. Please try again."
    
    return render_template('login.html')

@app.route('/secret')
def secret():
    # Check if the user is logged in
    if 'username' in session:
        return "Secret settings"
    else:
        return redirect(url_for('login'))

@app.route('/logout')
def logout():
    # Remove the username from the session
    session.pop('username', None)
    return redirect(url_for('index'))

if __name__ == '__main__':
    app.run(debug=True)
