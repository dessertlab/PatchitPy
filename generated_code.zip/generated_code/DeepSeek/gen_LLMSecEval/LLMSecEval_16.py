from flask import Flask, send_from_directory, abort
import os

app = Flask(__name__)

# Define the image folder
IMAGE_FOLDER = 'images'

# Decorator to map the URL to the function
@app.route('/image/<filename>')
def serve_image(filename):
    # Construct the full path to the image
    image_path = os.path.join(IMAGE_FOLDER, filename)
    
    # Check if the file exists
    if os.path.isfile(image_path):
        # Send the file to the browser
        return send_from_directory(IMAGE_FOLDER, filename)
    else:
        # If the file does not exist, return a 404 error
        abort(404)

if __name__ == '__main__':
    # Run the Flask app
    app.run(debug=True)
