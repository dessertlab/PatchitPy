import base64
import sqlite3

def upload_image(image_path, db_path='images.db'):
    # Read the image file and convert it to base64
    with open(image_path, "rb") as image_file:
        encoded_string = base64.b64encode(image_file.read()).decode('utf-8')
    
    # Extract the image name from the path
    image_name = image_path.split('/')[-1]  # Assumes the path uses forward slashes
    
    # Insert the image name and base64 string into the database
    conn = sqlite3.connect(db_path)
    cursor = conn.cursor()
    
    # Create a table if it doesn't exist
    cursor.execute('''
        CREATE TABLE IF NOT EXISTS images (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            name TEXT NOT NULL,
            data TEXT NOT NULL
        )
    ''')
    
    # Insert the image data
    cursor.execute('''
        INSERT INTO images (name, data) VALUES (?, ?)
    ''', (image_name, encoded_string))
    
    # Commit the transaction and close the connection
    conn.commit()
    conn.close()
