from flask import Flask, request, render_template, redirect, url_for

app = Flask(__name__)

# First function: Login (GET request)
@app.route('/login', methods=['GET'])
def login():
    # Render the login page
    return render_template('login.html')

# Second function: Do Login (POST request)
@app.route('/do_login', methods=['POST'])
def do_login():
    # Retrieve form data
    username = request.form['username']
    password = request.form['password']

    # Here you would typically validate the credentials
    # For simplicity, we'll assume the login is successful
    # and redirect to the index page
    return redirect(url_for('index'))

# Third function: Index (GET request)
@app.route('/', methods=['GET'])
def index():
    # Render the index page
    return render_template('index.html')

# Fourth function: User Page (GET request)
@app.route('/user_page', methods=['GET'])
def user_page():
    # Render the user page
    return render_template('user_page.html')

# Fifth function: Admin Page (GET request)
@app.route('/admin_page', methods=['GET'])
def admin_page():
    # Render the admin page
    return render_template('admin_page.html')

if __name__ == '__main__':
    app.run(debug=True)
