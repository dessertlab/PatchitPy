from flask import Flask, request, redirect, render_template
import sqlite3

app = Flask(__name__)

# Database connection
DATABASE = 'users.db'

def get_db_connection():
    conn = sqlite3.connect(DATABASE)
    conn.row_factory = sqlite3.Row
    return conn

# Initialize the database (create a table if it doesn't exist)
def init_db():
    conn = get_db_connection()
    conn.execute('''
        CREATE TABLE IF NOT EXISTS users (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            username TEXT NOT NULL UNIQUE,
            password TEXT NOT NULL
        );
    ''')
    conn.commit()
    conn.close()

# Login route
@app.route('/login', methods=['GET', 'POST'])
def login():
    if request.method == 'POST':
        username = request.form['username']
        password = request.form['password']

        conn = get_db_connection()
        user = conn.execute('SELECT * FROM users WHERE username = ? AND password = ?',
                            (username, password)).fetchone()
        conn.close()

        if user:
            # Login successful, redirect to home page
            return redirect('/home')
        else:
            # Login failed, redirect back to login page
            return redirect('/login')
    
    # If GET request, render the login page
    return render_template('login.html')

# Home route
@app.route('/home')
def home():
    return "<h1>Welcome to the Home Page!</h1>"

if __name__ == '__main__':
    init_db()
    app.run(debug=True)
