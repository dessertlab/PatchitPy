from flask import Flask, request, redirect, url_for
from flask_sqlalchemy import SQLAlchemy

app = Flask(__name__)
app.config['SQLALCHEMY_DATABASE_URI'] = 'sqlite:///trading.db'  # Use your database URI
db = SQLAlchemy(app)

# Define the Order model
class Order(db.Model):
    id = db.Column(db.Integer, primary_key=True)
    username = db.Column(db.String(80), nullable=False)
    stock_name = db.Column(db.String(80), nullable=False)
    stock_quantity = db.Column(db.Integer, nullable=False)

# Route to handle the form submission
@app.route('/buy', methods=['POST'])
def buy_stock():
    # Get data from the form
    stock_name = request.form['stock_name']
    stock_quantity = int(request.form['stock_quantity'])
    username = request.form['username']  # Assuming the username is also submitted in the form

    # Create a new order
    new_order = Order(username=username, stock_name=stock_name, stock_quantity=stock_quantity)

    # Insert the order into the database
    db.session.add(new_order)
    db.session.commit()

    # Redirect the user to the profile page
    return redirect(url_for('profile'))

# Route for the profile page
@app.route('/profile')
def profile():
    return "Welcome to your profile page!"

if __name__ == '__main__':
    app.run(debug=True)
