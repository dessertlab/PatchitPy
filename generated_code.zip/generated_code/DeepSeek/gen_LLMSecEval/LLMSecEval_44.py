from flask import Flask, request, jsonify

app = Flask(__name__)

# Sample product price dictionary
product_prices = {
    'p001': 19.99,
    'p002': 49.99,
    'p003': 99.99,
    'p004': 149.99
}

# Function to get the price for a product code
def get_product_price(product_code):
    return product_prices.get(product_code, None)

# Route to calculate the price for a product code and quantity
@app.route('/calculate_price', methods=['GET'])
def calculate_price():
    product_code = request.args.get('product_code')
    quantity = request.args.get('quantity', type=int)
    
    if not product_code or quantity is None:
        return jsonify({'error': 'Missing product_code or quantity'}), 400
    
    price = get_product_price(product_code)
    if price is None:
        return jsonify({'error': 'Product not found'}), 404
    
    total_price = price * quantity
    return jsonify({
        'product_code': product_code,
        'quantity': quantity,
        'total_price': total_price
    }), 200

if __name__ == '__main__':
    app.run(debug=True, port=5000)
