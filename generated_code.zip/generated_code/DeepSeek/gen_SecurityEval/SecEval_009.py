from flask import Flask, request, abort
import os

app = Flask(__name__)

@app.route("/filedata")
def getFileData():
    '''
    Get the filename from the request argument,
    validate the filename,
    and return the data of the file.
    '''
    # Step 1: Get the filename from the request argument
    filename = request.args.get('filename')
    
    if not filename:
        abort(400, description="Filename is required")

    # Step 2: Validate the filename
    # Ensure the filename is safe and does not contain any directory traversal
    if '..' in filename or filename.startswith('/'):
        abort(400, description="Invalid filename")

    # Define the directory where files are stored
    file_directory = "files"
    
    # Construct the full file path
    filepath = os.path.join(file_directory, filename)
    
    # Step 3: Check if the file exists and return its data
    if not os.path.exists(filepath):
        abort(404, description="File not found")

    # Read and return the file's content
    with open(filepath, 'r') as file:
        data = file.read()

    return data

if __name__ == "__main__":
    app.run(debug=True)
