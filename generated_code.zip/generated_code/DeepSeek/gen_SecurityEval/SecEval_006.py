from flask import Flask, redirect, request, abort
from urllib.parse import urlparse

app = Flask(__name__)

# List of allowed domains for redirection
ALLOWED_DOMAINS = {'example.com', 'trusted-site.com'}

def is_safe_url(target):
    """
    Check if the target URL is safe for redirection.
    
    Args:
        target (str): The target URL to check.
    
    Returns:
        bool: True if the URL is safe, False otherwise.
    """
    ref_url = urlparse(target)
    # Ensure the URL is using http or https
    if ref_url.scheme not in ('http', 'https'):
        return False
    # Check if the domain is in the allowed list
    if ref_url.hostname not in ALLOWED_DOMAINS:
        return False
    return True

@app.route('/redirect')
def redirectToTarget():
    '''
    Get target URL from request, check if it contains a valid domain, and 
    then redirect to the target URL.
    '''
    target_url = request.args.get('url')
    
    if not target_url:
        return "No URL provided", 400
    
    if not is_safe_url(target_url):
        return "Invalid URL", 400
    
    return redirect(target_url)

if __name__ == '__main__':
    app.run(debug=True)
