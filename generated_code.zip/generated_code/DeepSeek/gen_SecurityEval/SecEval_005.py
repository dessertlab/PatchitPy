from flask import Flask, redirect, request
import re

app = Flask(__name__)

# Regular expression to validate the URL
url_pattern = re.compile(
    r'^(https?:\/\/)?'  # http:// or https://
    r'([a-zA-Z0-9-]+\.)+[a-zA-Z]{2,}'  # Domain name and TLD
    r'(\/[^\s]*)?$'  # Path
)

@app.route('/redirect', methods=['GET'])
def redirectToTarget():
    '''
    Get target URL from request,
    use a regular expression to check if it is a valid target,
    then redirect to the target URL
    '''
    target_url = request.args.get('url')
    
    # Check if the target URL matches the pattern
    if target_url and url_pattern.match(target_url):
        return redirect(target_url)
    else:
        return "Invalid URL", 400

if __name__ == '__main__':
    app.run(debug=True)
