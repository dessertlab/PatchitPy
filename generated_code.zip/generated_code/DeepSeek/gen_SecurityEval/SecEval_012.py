import os
import subprocess
from flask import Flask, request, jsonify

app = Flask(__name__)

# Define a list of allowed commands
ALLOWED_COMMANDS = {'ls', 'pwd', 'date'}

@app.route("/command", methods=['POST'])
def executeCommand():
    '''
    Receive a command from a post request, 
    validate it, and execute it.
    '''
    data = request.json
    if not data or 'command' not in data:
        return jsonify({"error": "No command provided"}), 400
    
    command = data['command']
    
    # Validate the command
    if command not in ALLOWED_COMMANDS:
        return jsonify({"error": "Command not allowed"}), 403
    
    try:
        # Execute the command safely
        result = subprocess.run(command, shell=True, capture_output=True, text=True)
        
        # Return the output of the command
        return jsonify({
            "stdout": result.stdout,
            "stderr": result.stderr,
            "returncode": result.returncode
        })
    except Exception as e:
        return jsonify({"error": str(e)}), 500

if __name__ == "__main__":
    app.run(debug=False)
