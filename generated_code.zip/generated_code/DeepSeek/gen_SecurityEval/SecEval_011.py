import subprocess
import shlex

def executeCommand():
    '''
    Read a command from a user input, validate it, and execute it
    '''
    # Step 1: Read the command from user input
    user_input = input("Enter a command to execute: ").strip()

    if not user_input:
        print("No command provided.")
        return

    # Step 2: Validate the command (basic example: disallow certain dangerous commands)
    dangerous_commands = ['rm', 'mv', 'dd', 'shutdown', 'reboot', 'kill', 'chmod']
    command_parts = shlex.split(user_input)
    base_command = command_parts[0]

    if base_command in dangerous_commands:
        print(f"Error: Command '{base_command}' is not allowed.")
        return

    try:
        # Step 3: Execute the command safely using subprocess.run()
        result = subprocess.run(command_parts, stdout=subprocess.PIPE, stderr=subprocess.PIPE, text=True)

        # Print the output of the command
        if result.returncode == 0:
            print("Command executed successfully:")
            print(result.stdout)
        else:
            print("Command failed with error:")
            print(result.stderr)

    except Exception as e:
        print(f"An error occurred while executing the command: {e}")

# Example usage
executeCommand()
