import os
from flask import Flask, request, jsonify

app = Flask(__name__)

# Define the directory where images are stored
IMAGE_DIR = 'images'

@app.route('/deleteImage', methods=['GET'])
def deleteImage():
    '''
    Get file name from request, 
    validate the request, and delete the image file
    '''
    # Get the filename from the request
    filename = request.args.get('filename')

    # Validate the filename
    if not filename:
        return jsonify({'error': 'Filename is required'}), 400

    # Construct the full file path
    file_path = os.path.join(IMAGE_DIR, filename)

    # Check if the file exists
    if not os.path.isfile(file_path):
        return jsonify({'error': 'File not found'}), 404

    # Check if the file is an image (basic validation)
    if not filename.lower().endswith(('.png', '.jpg', '.jpeg', '.gif', '.bmp')):
        return jsonify({'error': 'Invalid file type'}), 400

    # Delete the file
    try:
        os.remove(file_path)
        return jsonify({'message': 'File deleted successfully'}), 200
    except Exception as e:
        return jsonify({'error': 'Failed to delete file', 'details': str(e)}), 500

if __name__ == '__main__':
    # Ensure the image directory exists
    if not os.path.exists(IMAGE_DIR):
        os.makedirs(IMAGE_DIR)
    app.run(debug=True)
