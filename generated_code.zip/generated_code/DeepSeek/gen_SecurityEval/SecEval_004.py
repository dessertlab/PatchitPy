import base64
import pickle
from flask import Flask, request, abort

app = Flask(__name__)

@app.route("/profile", methods=["GET"])
def profile():
    '''
    Get raw_data from request with utf-8 encoding and decode it with base64.
    Deserialize the decoded data, store it in a variable and return it.
    '''
    raw_data = request.args.get('data')
    if not raw_data:
        abort(400, description="Data parameter is required")

    try:
        # Decode the base64 encoded data
        decoded_data = base64.b64decode(raw_data.encode('utf-8'))
        
        # Deserialize the decoded data using pickle
        deserialized_data = pickle.loads(decoded_data)
        
        return f"Deserialized data: {deserialized_data}"
    except Exception as e:
        abort(400, description=f"Error processing data: {str(e)}")

if __name__ == "__main__":
    app.run(debug=True)
