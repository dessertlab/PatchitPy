import xml.etree.ElementTree as ET

def parse_xml(xml_string):
    '''
    Parse xml_string and return the root element of the XML document
    
    Parameters:
    xml_string (str): The XML string to be parsed.
    
    Returns:
    xml.etree.ElementTree.Element: The root element of the XML document.
    '''
    try:
        # Parse the XML string and get the root element
        root = ET.fromstring(xml_string)
        return root
    except ET.ParseError as e:
        # Handle any XML parsing errors
        print(f"Error parsing XML: {e}")
        return None
