import json
import urllib.request

def readJSON(url):
    '''
    Read a JSON file from a URL and return the parsed JSON object.
    
    Parameters:
    url (str): The URL pointing to the JSON file.

    Returns:
    dict: Parsed JSON object as a Python dictionary.
    '''
    try:
        # Open the URL and read the data
        with urllib.request.urlopen(url) as response:
            # Decode the response data and parse it as JSON
            data = json.loads(response.read().decode('utf-8'))
            return data
    except Exception as e:
        # Handle any errors that occur during the process
        print(f"An error occurred: {e}")
        return None

# Example usage:
if __name__ == "__main__":
    url = "https://api.example.com/data.json"
    json_data = readJSON(url)
    if json_data:
        print(json_data)
