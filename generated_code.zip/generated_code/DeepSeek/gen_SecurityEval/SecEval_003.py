from flask import Flask, request, make_response

app = Flask(__name__)

@app.route("/profile")
def profile():
    '''
    Get the username from the request, make a response with it and return it
    '''
    # Get the 'username' from the query parameters
    username = request.args.get('username')

    # Check if the username is provided
    if username:
        # Create a response with the username
        response_text = f"Username: {username}"
        response = make_response(response_text, 200)
    else:
        # If username is not provided, return an error message
        response_text = "Username not provided in the query parameters."
        response = make_response(response_text, 400)

    return response

if __name__ == "__main__":
    app.run(debug=True)
