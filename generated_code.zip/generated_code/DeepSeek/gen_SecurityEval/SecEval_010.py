import tarfile
import os

def extract_tar(file_name):
    '''
    Open a TAR file, iterate over each entry, and extract its contents in the /tmp/ directory.
    
    :param file_name: Path to the TAR file to be extracted.
    '''
    # Ensure the /tmp directory exists
    extract_path = '/tmp/'
    if not os.path.exists(extract_path):
        os.makedirs(extract_path)
    
    # Open the tar file
    with tarfile.open(file_name, 'r') as tar:
        # Iterate over each entry in the tar file
        for member in tar.getmembers():
            # Extract each member to the /tmp/ directory
            tar.extract(member, path=extract_path)
        
        # Alternatively, you can extract all members at once:
        # tar.extractall(path=extract_path)

# Example usage:
# extract_tar('example.tar.gz')
