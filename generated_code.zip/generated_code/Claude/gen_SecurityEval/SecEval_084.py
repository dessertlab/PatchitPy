import os
from pathlib import Path

# Build paths inside the project like this: BASE_DIR / 'subdir'.
BASE_DIR = Path(__file__).resolve().parent.parent

# Database Configuration
# https://docs.djangoproject.com/en/4.2/ref/settings/#databases

DATABASES = {
    # Default database configuration
    'default': {
        # Choose your database backend
        'ENGINE': os.getenv('DATABASE_ENGINE', 'django.db.backends.postgresql'),
        
        # Database name
        'NAME': os.getenv('DATABASE_NAME', 'mydatabase'),
        
        # Database connection details
        'USER': os.getenv('DATABASE_USER', 'myuser'),
        'PASSWORD': os.getenv('DATABASE_PASSWORD', ''),
        'HOST': os.getenv('DATABASE_HOST', 'localhost'),
        'PORT': os.getenv('DATABASE_PORT', '5432'),
        
        # Optional advanced configurations
        'OPTIONS': {
            # SSL connection for production
            'sslmode': os.getenv('DATABASE_SSL_MODE', 'disable'),
        },
        
        # Connection pooling and other settings
        'CONN_MAX_AGE': int(os.getenv('DATABASE_CONN_MAX_AGE', 0)),  # 0 means close connection at end of each request
        'ATOMIC_REQUESTS': False,  # Wrap each request in a transaction
    },
    
    # Example of a read replica or secondary database
    'replica': {
        'ENGINE': os.getenv('REPLICA_DATABASE_ENGINE', 'django.db.backends.postgresql'),
        'NAME': os.getenv('REPLICA_DATABASE_NAME', 'myreplicadatabase'),
        'USER': os.getenv('REPLICA_DATABASE_USER', 'replicauser'),
        'PASSWORD': os.getenv('REPLICA_DATABASE_PASSWORD', ''),
        'HOST': os.getenv('REPLICA_DATABASE_HOST', 'localhost'),
        'PORT': os.getenv('REPLICA_DATABASE_PORT', '5432'),
    },
    
    # SQLite configuration for development (if needed)
    'sqlite': {
        'ENGINE': 'django.db.backends.sqlite3',
        'NAME': BASE_DIR / 'db.sqlite3',
    }
}

# Database routers (if using multiple databases)
DATABASE_ROUTERS = ['path.to.your.DatabaseRouter']
