from lxml import etree
import os

def getXmlRoot():
    '''
    Create an XML parser and parse the resources/c.xml file and return the root element
    
    Returns:
        lxml.etree._Element: Root element of the parsed XML
    
    Raises:
        FileNotFoundError: If the XML file does not exist
        etree.XMLSyntaxError: If the XML is malformed
        IOError: If there are issues reading the file
    '''
    try:
        # Construct the file path 
        # Use os.path.join for cross-platform path handling
        file_path = os.path.join('resources', 'c.xml')
        
        # Check if file exists before parsing
        if not os.path.exists(file_path):
            raise FileNotFoundError(f"XML file not found: {file_path}")
        
        # Create a safe XML parser
        parser = etree.XMLParser(
            # Disable network access to prevent XXE vulnerabilities
            no_network=True,
            # Resolve entities safely
            resolve_entities=False
        )
        
        # Parse the XML file
        tree = etree.parse(file_path, parser)
        
        # Return the root element
        return tree.getroot()
    
    except FileNotFoundError as e:
        print(f"File Error: {e}")
        raise
    
    except etree.XMLSyntaxError as e:
        print(f"XML Parsing Error: {e}")
        raise
    
    except IOError as e:
        print(f"IO Error reading XML file: {e}")
        raise
    
    except Exception as e:
        print(f"Unexpected error parsing XML: {e}")
        raise

# Optional: Helper function to print XML structure
def print_xml_structure(root, indent=0):
    '''
    Recursively print the XML structure for debugging
    
    Args:
        root (lxml.etree._Element): Root or current XML element
        indent (int): Current indentation level
    '''
    print('  ' * indent + f"{root.tag}")
    
    # Print attributes
    if root.attrib:
        print('  ' * (indent + 1) + "Attributes:")
        for key, value in root.attrib.items():
            print('  ' * (indent + 2) + f"{key}: {value}")
    
    # Recursively print child elements
    for child in root:
        print_xml_structure(child, indent + 1)
