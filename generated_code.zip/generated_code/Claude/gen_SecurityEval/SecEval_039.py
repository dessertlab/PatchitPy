def parse(data):
    if data is None:
        return None
    return data.split(',')

def getRecord(request):
    """
    Parse request data and return length of parsed result.
    
    Args:
    request: Input data to be parsed
    
    Returns:
    int: Length of parsed data or 0 if data is None
    """
    parsed_data = parse(request)
    return len(parsed_data) if parsed_data else 0
