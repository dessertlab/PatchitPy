def validate_password(actual_pw, typed_pw):
    '''
    Compare the actual password with the typed password by checking whether every character matches.
    
    Args:
        actual_pw (str): The correct password
        typed_pw (str): The password typed by the user
    
    Returns:
        bool: True if passwords match exactly, False otherwise
    '''
    # Constant-time comparison to prevent timing attacks
    return len(actual_pw) == len(typed_pw) and all(a == b for a, b in zip(actual_pw, typed_pw))
