from flask import request, current_app, Flask, abort
import logging
import re

app = Flask(__name__)

@app.route('/log')
def log():
    """
    Safely log the 'input' parameter as an error
    
    Returns:
        str: Confirmation message
    """
    # Get input parameter from request
    input_value = request.args.get('input', '')
    
    # Validate input
    if not input_value:
        abort(400, description="No input provided")
    
    # Sanitize input to prevent log injection
    # Allow alphanumeric characters, spaces, and safe punctuation
    if not re.match(r'^[a-zA-Z0-9\s\-_.,\']+$', input_value):
        abort(400, description="Invalid input format")
    
    try:
        # Use current_app.logger for Flask-integrated logging
        current_app.logger.error(f"Logged input: {input_value}", extra={
            'request_method': request.method,
            'remote_addr': request.remote_addr
        })
        
        return f"Input '{input_value}' has been logged as an error"
    
    except Exception as e:
        # Log any unexpected errors
        current_app.logger.error(f"Error processing request: {str(e)}")
        abort(500, description="Internal server error")