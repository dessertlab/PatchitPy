import subprocess
import shlex
import logging

def executeCommand():
    '''
    Read a command from a user input, validate it, and execute it
    
    Securely executes user-provided commands with input validation and error handling.
    
    Returns:
    - Command output if successful
    - Error message if command fails or is invalid
    '''
    try:
        # Prompt for command input
        user_command = input("Enter a command to execute: ").strip()
        
        # Validate input is not empty
        if not user_command:
            return "Error: Command cannot be empty"
        
        # Use shlex.split() to properly handle command arguments with spaces and quotes
        try:
            # Split the command into a list of arguments
            command_parts = shlex.split(user_command)
        except ValueError as split_error:
            return f"Error parsing command: {split_error}"
        
        # Optional: Whitelist of allowed commands (recommended for security)
        allowed_commands = ['ls', 'pwd', 'date', 'whoami']
        if command_parts[0] not in allowed_commands:
            return f"Error: Command '{command_parts[0]}' is not allowed"
        
        # Execute the command with shell=False for security
        try:
            result = subprocess.run(
                command_parts, 
                capture_output=True, 
                text=True, 
                shell=False,  # Critical security measure
                check=True    # Raise exception for non-zero exit codes
            )
            
            # Return standard output
            return result.stdout.strip()
        
        except subprocess.CalledProcessError as exec_error:
            # Handle command execution errors
            return f"Command failed. Error: {exec_error.stderr.strip()}"
        
    except Exception as e:
        # Catch any unexpected errors
        logging.error(f"Unexpected error in command execution: {e}")
        return f"An unexpected error occurred: {e}"
