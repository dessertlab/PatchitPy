import xml.sax
import os

class XMLHandler(xml.sax.ContentHandler):
    def __init__(self):
        self.current_data = ""
        self.parsed_data = {}

    def startElement(self, name, attrs):
        self.current_data = name

    def characters(self, content):
        if content.strip():
            self.parsed_data[self.current_data] = content.strip()

def get_root():
    '''
    Create an XML parser,
    parse the file 'resources/config.xml' and return the parsed result.
    '''
    config_path = os.path.join('resources', 'config.xml')
    
    try:
        parser = xml.sax.make_parser()
        handler = XMLHandler()
        parser.setContentHandler(handler)
        parser.parse(config_path)
        return handler.parsed_data
    except IOError:
        print(f"Error: Config file not found at {config_path}")
        return None
    except xml.sax.SAXParseException as e:
        print(f"XML parsing error: {e}")
        return None
