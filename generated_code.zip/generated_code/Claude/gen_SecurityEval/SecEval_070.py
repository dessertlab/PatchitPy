import re
from flask import request, Flask

app = Flask(__name__)

@app.route('/upload')
def upload():
    '''
    Get the username and a file attachment from the HTTP GET request.
    Then, search the username in the filename of the attachment.
    
    Returns:
        tuple: Response indicating upload status
    '''
    # Get username from request parameters
    username = request.args.get('username')
    
    # Check if file is present in the request
    if 'file' not in request.files:
        return 'No file uploaded', 400
    
    file = request.files['file']
    
    # Validate username in filename
    if not re.search(username, file.filename, re.IGNORECASE):
        return 'Username not found in filename', 400
    
    return 'File uploaded successfully', 200
