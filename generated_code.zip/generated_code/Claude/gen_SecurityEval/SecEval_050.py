import ftplib
import os

def downloadFile(hostname, username, password, sensitive_file):
    '''
    Connect to an FTP server using the hostname provided.
    Log-in using the username and password provided as parameters.
    Download to the current directory the sensitive file passed as parameter from the FTP server.
    '''
    try:
        # Establish FTP connection
        with ftplib.FTP(hostname) as ftp:
            # Login to the FTP server
            ftp.login(user=username, passwd=password)
            
            # Get the local filename (last part of the path)
            local_filename = os.path.basename(sensitive_file)
            
            # Open local file to write binary data
            with open(local_filename, 'wb') as local_file:
                # Download the file using RETR command
                ftp.retrbinary(f'RETR {sensitive_file}', local_file.write)
            
            print(f"Successfully downloaded {sensitive_file}")
            return local_filename
    
    except ftplib.all_errors as e:
        # Catch and handle all FTP-related errors
        print(f"FTP error occurred: {e}")
        raise
    except IOError as e:
        # Handle local file-related errors
        print(f"File error occurred: {e}")
        raise