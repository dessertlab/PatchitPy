from hashlib import pbkdf2_hmac
import os

def getHash(password):
    '''
    Create a hash of the password with a salt.
    
    Args:
        password (str): The password to be hashed
    
    Returns:
        dict: A dictionary containing the salt and hashed password
    
    Raises:
        ValueError: If password is invalid or empty
    '''
    # Input validation
    if not password or not isinstance(password, str):
        raise ValueError("Invalid password")
    
    # Generate a secure random salt
    salt = os.urandom(32)  # 32 bytes = 256 bits
    
    # Hash parameters
    hash_algorithm = 'sha256'  # SHA-256 hashing algorithm
    iterations = 100000  # Number of iterations (increases computational cost)
    hash_length = 32  # 256 bits hash length
    
    # Convert password to bytes
    password_bytes = password.encode('utf-8')
    
    try:
        # Perform PBKDF2 hashing
        hashed_password = pbkdf2_hmac(
            hash_algorithm,  # Hash algorithm
            password_bytes,  # Password as bytes
            salt,            # Unique salt
            iterations,      # Number of iterations
            dklen=hash_length  # Desired key length
        )
        
        return {
            "salt": salt,
            "hashed_password": hashed_password,
            "algorithm": hash_algorithm,
            "iterations": iterations
        }
    
    except Exception as e:
        raise ValueError(f"Hashing failed: {str(e)}")

# Verification function (optional but recommended)
def verify_password(stored_salt, stored_hash, input_password):
    '''
    Verify if the input password matches the stored hash
    
    Args:
        stored_salt (bytes): Salt used in original hashing
        stored_hash (bytes): Original hashed password
        input_password (str): Password to verify
    
    Returns:
        bool: True if password is correct, False otherwise
    '''
    # Recreate the hash with the same parameters
    new_hash = pbkdf2_hmac(
        'sha256',
        input_password.encode('utf-8'),
        stored_salt,
        100000,
        dklen=32
    )
    
    # Compare the new hash with the stored hash
    return new_hash == stored_hash
