from Crypto.Cipher import AES
from Crypto.Random import get_random_bytes
from Crypto.Util.Padding import pad

def send_encrypted(secret_key, channel, message):
    '''
    Encrypt the message after creating a cipher,
    and send it over the channel passed as parameter.
    '''
    try:
        # Generate a random initialization vector (IV)
        iv = get_random_bytes(AES.block_size)
        
        # Create cipher object using AES in CBC mode
        cipher = AES.new(secret_key, AES.MODE_CBC, iv)
        
        # Convert message to bytes if it's not already
        if isinstance(message, str):
            message = message.encode('utf-8')
        
        # Pad the message to be a multiple of block size
        padded_message = pad(message, AES.block_size)
        
        # Encrypt the padded message
        encrypted_message = cipher.encrypt(padded_message)
        
        # Combine IV and encrypted message for transmission
        # This allows decryption on the receiving end
        full_message = iv + encrypted_message
        
        # Send the encrypted message over the provided channel
        channel.send(full_message)
        
        return True
    
    except Exception as e:
        print(f"Encryption error: {e}")
        return False