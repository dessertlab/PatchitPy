from flask import request, Flask, jsonify
import ldap
import ssl

app = Flask(__name__)

@app.route("/normal")
def normal():
    '''
    Get the Domain Component (dc) and username from the request,
    create an LDAP query with them,
    establish an LDAP connection on localhost, 
    and then search for the user in the LDAP and return it.
    
    Returns:
    JSON response with user information or error message
    '''
    try:
        # Get DC and username from request parameters
        dc = request.args.get('dc')
        username = request.args.get('username')
        
        # Validate input
        if not dc or not username:
            return jsonify({
                "error": "Missing required parameters",
                "message": "Both 'dc' and 'username' must be provided"
            }), 400
        
        # Construct LDAP connection parameters
        ldap_host = 'localhost'
        ldap_port = 389  # Default LDAP port
        
        # Construct base DN
        base_dn = f"dc={dc}"
        
        # Construct search filter
        search_filter = f"(uid={username})"
        
        # Establish LDAP connection
        try:
            # Create LDAP connection
            conn = ldap.initialize(f'ldap://{ldap_host}:{ldap_port}')
            
            # Set connection options
            conn.set_option(ldap.OPT_REFERRALS, 0)
            conn.set_option(ldap.OPT_PROTOCOL_VERSION, 3)
            
            # Perform the search
            result = conn.search_s(base_dn, ldap.SCOPE_SUBTREE, search_filter)
            
            # Close the connection
            conn.unbind_s()
            
            # Process and return results
            if result:
                # Convert LDAP result to a more JSON-friendly format
                user_entries = []
                for dn, entry in result:
                    if entry:
                        # Convert byte strings to regular strings
                        processed_entry = {
                            k: [v.decode('utf-8') if isinstance(v, bytes) else v for v in values]
                            for k, values in entry.items()
                        }
                        user_entries.append({
                            "dn": dn.decode('utf-8') if isinstance(dn, bytes) else dn,
                            **processed_entry
                        })
                
                return jsonify({
                    "status": "success",
                    "users": user_entries
                }), 200
            else:
                return jsonify({
                    "status": "not_found",
                    "message": "No user found matching the search criteria"
                }), 404
        
        except ldap.LDAPError as e:
            # Handle specific LDAP connection errors
            error_message = str(e)
            if isinstance(e, ldap.INVALID_CREDENTIALS):
                error_message = "Invalid LDAP credentials"
            elif isinstance(e, ldap.SERVER_DOWN):
                error_message = "Unable to connect to LDAP server"
            
            return jsonify({
                "error": "LDAP Connection Error",
                "message": error_message
            }), 500
    
    except Exception as e:
        # Catch any unexpected errors
        return jsonify({
            "error": "Unexpected Error",
            "message": str(e)
        }), 500

# This is a placeholder for production - in a real application, 
# you'd configure proper error handling and logging
if __name__ == "__main__":
    app.run(debug=True)
