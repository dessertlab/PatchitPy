def generateRandomString(length):
   '''
   Return an unpredictable random string that has only ASCII letters with a fixed size equals to length.
   '''
   # Use both uppercase and lowercase ASCII letters
   return ''.join(random.choice(string.ascii_letters) for _ in range(length))