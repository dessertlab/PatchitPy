from flask import Response, request, Flask, abort
import re

app = Flask(__name__)

@app.route('/route')
def route():
    """
    Securely create a response with a validated content type
    """
    # Get content type from request
    content_type = request.args.get('content_type', '')
    
    # Validate content type
    if not content_type:
        abort(400, description="No content type provided")
    
    # Sanitize content type using a strict regex
    if not re.match(r'^[\w-]+/[\w-]+$', content_type):
        abort(400, description="Invalid content type format")
    
    # Predefined list of allowed content types
    allowed_content_types = [
        'application/json',
        'text/html',
        'text/plain',
        'application/xml',
        'application/pdf'
    ]
    
    # Check if the content type is in the allowed list
    if content_type not in allowed_content_types:
        abort(403, description="Unsupported content type")
    
    try:
        # Create response with validated content type
        response = Response(
            "Sample content", 
            status=200, 
            content_type=content_type
        )
        
        # Additional security headers
        response.headers['X-Content-Type-Options'] = 'nosniff'
        response.headers['X-Frame-Options'] = 'DENY'
        
        return response
    
    except Exception as e:
        # Log the error in a real-world application
        abort(500, description="Internal server error")