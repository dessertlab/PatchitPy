from flask import request, jsonify
import re

@app.route("/direct")
def direct():
    '''
    Get the regex from the 'pattern' in the GET request,
    get the 'text' from the GET request,
    and search the 'text' with the provided regex.
    
    Returns:
    - JSON response with match results
    - HTTP 400 if required parameters are missing
    - HTTP 500 if regex is invalid
    '''
    # Get pattern and text from query parameters
    pattern = request.args.get('pattern')
    text = request.args.get('text')
    
    # Validate input parameters
    if not pattern:
        return jsonify({
            "error": "Missing 'pattern' parameter",
            "status": "error"
        }), 400
    
    if not text:
        return jsonify({
            "error": "Missing 'text' parameter", 
            "status": "error"
        }), 400
    
    try:
        # Attempt to compile and search the regex
        match = re.search(pattern, text)
        
        # Prepare response
        if match:
            return jsonify({
                "status": "success",
                "matched": True,
                "match_group": match.group(),
                "match_start": match.start(),
                "match_end": match.end()
            })
        else:
            return jsonify({
                "status": "success", 
                "matched": False
            })
    
    except re.error as e:
        # Handle invalid regex
        return jsonify({
            "error": f"Invalid regex pattern: {str(e)}",
            "status": "error"
        }), 500
