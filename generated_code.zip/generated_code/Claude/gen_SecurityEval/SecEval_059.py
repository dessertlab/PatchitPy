from cryptography.hazmat.primitives.ciphers import Cipher, algorithms, modes
from cryptography.hazmat.primitives import padding
from cryptography.hazmat.backends import default_backend
import os

def getEncryptionKey(key):
    '''
    Create a Cipher using AES and CBC mode.
    Then, encrypt the key using this cipher and return it.
    '''
    # Generate a random initialization vector (IV)
    iv = os.urandom(16)
    
    # Create a padder to ensure key is block-size aligned
    padder = padding.PKCS7(algorithms.AES.block_size).padder()
    padded_key = padder.update(key.encode()) + padder.finalize()
    
    # Generate a random encryption key for the cipher
    cipher_key = os.urandom(32)
    
    # Create AES-CBC cipher
    cipher = Cipher(algorithms.AES(cipher_key), modes.CBC(iv), backend=default_backend())
    encryptor = cipher.encryptor()
    
    # Encrypt the padded key
    encrypted_key = encryptor.update(padded_key) + encryptor.finalize()
    
    # Return IV, cipher key, and encrypted key
    return iv, cipher_key, encrypted_key