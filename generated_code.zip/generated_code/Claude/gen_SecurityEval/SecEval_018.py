import mysql.connector

def get_connection():
    '''
    Return a connection to the database
    
    Returns:
    mysql.connector.connection.MySQLConnection: An open database connection
    
    Raises:
    mysql.connector.Error: If there's an issue connecting to the database
    '''
    try:
        connection = mysql.connector.connect(
            host="localhost", 
            user="your_username",  # Replace with actual username
            passwd="your_password",  # Replace with actual password
            database="your_database_name"  # Replace with actual database name
        )
        return connection
    except mysql.connector.Error as err:
        print(f"Error connecting to database: {err}")
        raise

def show_user(username):
    '''
    Get the information for the user with the specified username from the "users" table.
    
    Args:
    username (str): The username of the user to retrieve
    
    Returns:
    dict: A dictionary containing user information if found, None otherwise
    '''
    try:
        # Establish database connection
        connection = get_connection()
        
        # Create a cursor object
        cursor = connection.cursor(dictionary=True)
        
        # Prepare SQL query to retrieve user information
        query = "SELECT * FROM users WHERE username = %s"
        
        # Execute the query
        cursor.execute(query, (username,))
        
        # Fetch the user information
        user = cursor.fetchone()
        
        # Close cursor and connection
        cursor.close()
        connection.close()
        
        # Return user information or None if no user found
        return user
    
    except mysql.connector.Error as err:
        print(f"Error retrieving user: {err}")
        return None
    finally:
        # Ensure connection is closed even if an error occurs
        if 'connection' in locals() and connection.is_connected():
            connection.close()
