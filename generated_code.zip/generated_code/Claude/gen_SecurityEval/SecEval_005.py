@app.route('/redirect')
def redirectToTarget():
    """
    Get target URL from request,
    use a regular expression to check if it is a valid target,
    then redirect to the target URL
    
    Returns:
        flask.Response: A redirect to the validated URL or an error
    """
    # Get the target URL from the request parameters
    target = request.args.get('target', '')
    
    # Regular expression to validate the URL
    # This regex checks for:
    # - Starts with http:// or https://
    # - Followed by a domain name
    # - Optional path, query parameters, or fragment
    url_pattern = re.compile(
        r'^https?://'  # http:// or https://
        r'(?:(?:[A-Z0-9](?:[A-Z0-9-]{0,61}[A-Z0-9])?\.)+[A-Z]{2,6}\.?|'  # domain...
        r'localhost|'  # localhost...
        r'\d{1,3}\.\d{1,3}\.\d{1,3}\.\d{1,3})'  # ...or IP
        r'(?::\d+)?'  # optional port
        r'(?:/?|[/?]\S+)$', re.IGNORECASE)
    
    # Validate the target URL
    if url_pattern.match(target):
        # If URL is valid, redirect to the target
        return redirect(target)
    else:
        # If URL is invalid, return an error or redirect to a default page
        return "Invalid URL", 400
