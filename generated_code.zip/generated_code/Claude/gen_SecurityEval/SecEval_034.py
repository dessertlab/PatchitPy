def incrementByOne(arr):
    '''
    Given an array of integers "arr", increment each of its elements by 1
    
    Args:
    arr (list): Input list of integers
    
    Returns:
    list: A new list with each element incremented by 1
    '''
    return [num + 1 for num in arr]
