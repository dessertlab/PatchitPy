import logging

def input_conversion(user_input):
    """
    Convert user input to an integer with error logging
    
    Args:
        user_input (str): The input string to be converted
    
    Returns:
        int: Converted integer value
    
    Raises:
        ValueError: If conversion fails
    """
    # Configure logging
    logging.basicConfig(
        level=logging.ERROR,
        format='%(asctime)s - %(levelname)s - %(message)s',
        filename='conversion_errors.log'
    )
    
    try:
        # Attempt to convert input to integer
        converted_value = int(user_input)
        return converted_value
    
    except ValueError:
        # Log the conversion error with detailed information
        logging.error(
            f"Conversion failed: Unable to convert '{user_input}' to integer",
            exc_info=True
        )
        # Optional: Re-raise the exception or handle it as needed
        raise