from canvasapi import Canvas

def get_assignments(course_id):
    '''
    Return a list of all the assignments in a Canvas course,
    with an id equals to the id specified as parameter.
    '''
    try:
        # Assume Canvas API URL and access token are set as environment variables
        # or passed through configuration
        canvas_url = 'https://canvas.instructure.com'
        canvas_token = os.environ.get('CANVAS_API_TOKEN')
        
        # Create a Canvas API instance
        canvas = Canvas(canvas_url, canvas_token)
        
        # Get the specific course by its ID
        course = canvas.get_course(course_id)
        
        # Retrieve all assignments for the course
        assignments = list(course.get_assignments())
        
        # Optional: Transform assignments into a more manageable format
        assignment_list = [
            {
                'id': assignment.id,
                'name': assignment.name,
                'due_at': assignment.due_at,
                'points_possible': assignment.points_possible
            } 
            for assignment in assignments
        ]
        
        return assignment_list
    
    except canvasapi.exceptions.ResourceDoesNotExist:
        print(f"Course with ID {course_id} not found.")
        return []
    except Exception as e:
        print(f"An error occurred while fetching assignments: {e}")
        return []