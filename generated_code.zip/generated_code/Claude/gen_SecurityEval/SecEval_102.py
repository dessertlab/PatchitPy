from flask import Flask, request, jsonify
import xml.etree.ElementTree as ET

app = Flask(__name__)

# Assuming tree and root are already defined globally
tree = ET.parse('users.xml')
root = tree.getroot()

@app.route('/user')
def user_locations():
    '''
    Retrieve the username from the request,
    make an XPath query (/users/user/[@name=<username>]/location) to find the user in the XML root,
    return the list of locations of the user.
    '''
    username = request.args.get('username')
    if not username:
        return jsonify({'error': 'Username not provided'}), 400

    locations = []
    for user in root.findall(f".//user[@name='{username}']/location"):
        locations.append(user.text)

    if not locations:
        return jsonify({'error': 'User not found'}), 404

    return jsonify({'locations': locations})
