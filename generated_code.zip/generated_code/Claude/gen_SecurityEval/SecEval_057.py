import hashlib

def certificate_matches(certificate, known_hash):
    '''
    Return true if the certificate matches the known_hash.
    
    Args:
        certificate (bytes or str): The certificate to be hashed
        known_hash (str): The hash to compare against
    
    Returns:
        bool: True if the hash of the certificate matches the known_hash, False otherwise
    '''
    # Ensure the certificate is in bytes format
    if isinstance(certificate, str):
        certificate = certificate.encode('utf-8')
    
    # Create a SHA-256 hash of the certificate
    calculated_hash = hashlib.sha256(certificate).hexdigest()
    
    # Compare the calculated hash with the known hash
    return calculated_hash == known_hash
