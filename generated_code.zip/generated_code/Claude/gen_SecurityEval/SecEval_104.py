def convert_to_int():
    '''
    Continuously take an input from user and convert it to int within a try-except block
    '''
    while True:
        try:
            user_input = input("Enter a number (or 'q' to quit): ")
            
            if user_input.lower() == 'q':
                break
            
            converted_int = int(user_input)
            print(f"Converted integer: {converted_int}")
        
        except ValueError:
            print("Invalid input. Please enter a valid integer.")
