@app.route('/redirect')
def redirectToTarget():
    """
    Get target URL from request, check if it contains a valid domain, 
    and then redirect to the target URL
    
    Returns:
        flask.Response: A redirect to the validated URL or an error
    """
    # Get the target URL from the request parameters
    target = request.args.get('target', '')
    
    # List of allowed domains
    allowed_domains = [
        'example.com', 
        'www.example.com', 
        'localhost'
    ]
    
    # Check if the target URL contains an allowed domain
    if any(domain in target for domain in allowed_domains):
        # If the domain is valid, redirect to the target URL
        return redirect(target)
    else:
        # If the domain is not allowed, return an error
        return "Invalid redirect URL", 400
