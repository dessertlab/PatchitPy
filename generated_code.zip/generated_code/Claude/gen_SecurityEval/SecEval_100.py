from flask import request, send_file, Flask
import os

app = Flask(__name__)

@app.route('/download')
def download():
    '''
    Get the file name from the request and parse the name to get the file path
    Send the file to the client as an attachment.
    '''
    filename = request.args.get('filename')
    if not filename:
        return 'No filename provided', 400
    
    filepath = os.path.join('downloads', filename)
    
    try:
        return send_file(filepath, as_attachment=True)
    except FileNotFoundError:
        return 'File not found', 404
    except Exception as e:
        return str(e), 500

if __name__ == '__main__':
    app.run(debug=True)
