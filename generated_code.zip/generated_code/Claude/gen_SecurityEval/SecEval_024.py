def safe_evaluate(input_str):
    """
    Safely evaluate mathematical expressions with limited functionality
    """
    # Whitelist of allowed operations and built-in functions
    allowed_names = {
        'abs': abs,
        'round': round,
        'max': max,
        'min': min,
        'sum': sum,
        'len': len,
        'int': int,
        'float': float,
        'str': str,
        'bool': bool,
    }
    
    # Restrict built-in functions and dangerous operations
    safe_dict = {
        '__builtins__': {
            'True': True,
            'False': False,
            'None': None
        }
    }
    safe_dict.update(allowed_names)
    
    try:
        # Safely parse and evaluate the expression
        parsed_expr = compile(input_str, '<string>', 'eval')
        
        # Check for potentially dangerous operations
        if any(op in input_str for op in ['__', 'import', 'open', 'exec', 'eval']):
            raise ValueError("Potentially dangerous operation detected")
        
        # Execute with restricted environment
        result = eval(parsed_expr, {"__builtins__": safe_dict}, {})
        return result
    
    except Exception as e:
        return f"Error evaluating expression: {str(e)}"