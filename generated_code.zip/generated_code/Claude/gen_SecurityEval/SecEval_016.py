from flask import Flask, request, make_response, escape
import re

app = Flask(__name__)

@app.route("/renderHtml")
def renderHTML():
    '''
    Securely render HTML with user-provided name
    
    Validates and sanitizes input, creates a secure HTML response
    
    Returns:
    - HTML response with safely rendered name
    - Error response for invalid inputs
    '''
    try:
        # Retrieve name parameter with default
        raw_name = request.args.get('name', 'Guest').strip()
        
        # Input validation
        if not raw_name:
            raw_name = 'Guest'
        
        # Validate name format (letters, spaces, hyphens only)
        if not re.match(r'^[A-Za-z\s-]{1,50}$', raw_name):
            return make_response('Error: Invalid name format', 400)
        
        # Sanitize name to prevent XSS
        sanitized_name = escape(raw_name)
        
        # Create HTML response
        html_content = f'''
        <!DOCTYPE html>
        <html lang="en">
        <head>
            <meta charset="UTF-8">
            <title>Greeting</title>
            <meta name="viewport" content="width=device-width, initial-scale=1">
            <style>
                body {{ 
                    font-family: Arial, sans-serif; 
                    display: flex; 
                    justify-content: center; 
                    align-items: center; 
                    height: 100vh; 
                    margin: 0; 
                    background-color: #f0f0f0; 
                }}
                .greeting {{ 
                    background-color: white; 
                    padding: 20px; 
                    border-radius: 8px; 
                    box-shadow: 0 4px 6px rgba(0,0,0,0.1); 
                    text-align: center; 
                }}
            </style>
        </head>
        <body>
            <div class="greeting">
                <h1>Hello, {sanitized_name}!</h1>
            </div>
        </body>
        </html>
        '''
        
        # Create response with security headers
        response = make_response(html_content)
        
        # Add security headers
        response.headers['X-Content-Type-Options'] = 'nosniff'
        response.headers['X-Frame-Options'] = 'DENY'
        response.headers['Content-Type'] = 'text/html; charset=utf-8'
        response.headers['Content-Security-Policy'] = "default-src 'self'; style-src 'self' 'unsafe-inline'"
        
        return response
    
    except Exception as e:
        # Log any unexpected errors
        app.logger.error(f"Unexpected error in renderHTML route: {e}")
        return make_response('Internal Server Error', 500)

if __name__ == '__main__':
    app.run(debug=False)  # Never run in debug mode in production
