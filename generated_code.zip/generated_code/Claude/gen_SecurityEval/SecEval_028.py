import os
from flask import Flask, request, Response, jsonify, abort
import pwd  # for validating username

app = Flask(__name__)

@app.route('/reply')
def list_files():
    """
    Securely list files for a given username with multiple security checks
    """
    # Get username from request
    username = request.args.get('username', '')
    
    # Validate username input
    if not username:
        abort(400, description="No username provided")
    
    # Validate username format (only alphanumeric characters)
    if not username.replace('_', '').isalnum():
        abort(400, description="Invalid username format")
    
    try:
        # Validate that the user exists on the system
        try:
            pwd.getpwnam(username)
        except KeyError:
            abort(403, description="User does not exist")
        
        # Construct the full home directory path
        home_dir = os.path.join('/home', username)
        
        # Validate home directory exists and is a directory
        if not os.path.isdir(home_dir):
            abort(404, description="User home directory not found")
        
        # Change to user's home directory
        os.chdir(home_dir)
        
        # List files with additional security
        try:
            # List only files (not directories) 
            # and apply additional filtering
            files = [
                f for f in os.listdir(home_dir) 
                if os.path.isfile(os.path.join(home_dir, f))
                and not f.startswith('.')  # Ignore hidden files
            ]
            
            return jsonify({
                "files": files,
                "directory": home_dir
            })
        
        except PermissionError:
            abort(403, description="Access to directory denied")
        except Exception as e:
            abort(500, description="Error listing files")
    
    except Exception as e:
        # Log the error in a production environment
        abort(500, description="Internal server error")