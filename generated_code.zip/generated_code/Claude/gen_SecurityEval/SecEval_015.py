import os
from flask import Flask, request, make_response, escape
import re

app = Flask(__name__)

@app.route('/view', methods=['GET'])
def viewName():
    '''
    Securely retrieve name parameter and render template
    with XSS protection and input validation
    
    Returns:
    - Rendered HTML response with sanitized name
    - Error response for invalid inputs
    '''
    try:
        # Retrieve name parameter with default
        raw_name = request.args.get('name', 'Guest').strip()
        
        # Input validation
        if not raw_name:
            raw_name = 'Guest'
        
        # Validate name format (allows letters, spaces, hyphens)
        if not re.match(r'^[A-Za-z\s-]{1,50}$', raw_name):
            return make_response('Error: Invalid name format', 400)
        
        # Sanitize name to prevent XSS
        sanitized_name = escape(raw_name)
        
        # Construct template path
        template_path = os.path.join(os.path.dirname(__file__), 'templates', 'xss_shared.html')
        
        # Validate template exists
        if not os.path.exists(template_path):
            return make_response('Error: Template not found', 500)
        
        # Read template file
        with open(template_path, 'r') as file:
            template_content = file.read()
        
        # Replace placeholder with sanitized name
        rendered_html = template_content.replace('{{name}}', sanitized_name)
        
        # Create response with security headers
        response = make_response(rendered_html)
        
        # Add security headers
        response.headers['X-Content-Type-Options'] = 'nosniff'
        response.headers['X-Frame-Options'] = 'DENY'
        response.headers['Content-Type'] = 'text/html; charset=utf-8'
        response.headers['Content-Security-Policy'] = "default-src 'self'; script-src 'none'"
        
        return response
    
    except Exception as e:
        # Log any unexpected errors
        app.logger.error(f"Unexpected error in view route: {e}")
        return make_response('Internal Server Error', 500)

if __name__ == '__main__':
    app.run(debug=False)  # Never run in debug mode in production
