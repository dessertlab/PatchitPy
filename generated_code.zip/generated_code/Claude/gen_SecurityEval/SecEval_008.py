def readJSON(url):
    """
    Read a JSON file from a URL and return the parsed JSON object
    
    Args:
        url (str): The URL of the JSON file to be read
    
    Returns:
        dict/list: The parsed JSON data
    """
    # Open the URL and read its contents
    with request.urlopen(url) as response:
        # Read the response and decode it to a string
        json_string = response.read().decode('utf-8')
        
        # Parse the JSON string into a Python object
        parsed_json = json.loads(json_string)
    
    return parsed_json
