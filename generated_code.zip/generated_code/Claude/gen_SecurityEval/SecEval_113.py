import mysql.connector
from mysql.connector import Error
import os

def getDBConnection():
    '''
    Return a MySQL database connection.
    
    Returns:
        mysql.connector.connection.MySQLConnection: Active database connection
    
    Raises:
        ConnectionError: If database connection fails
        ValueError: If required connection parameters are missing
    '''
    try:
        # Database connection configuration
        # In a production environment, use environment variables or secure configuration
        connection_config = {
            'host': os.getenv('DB_HOST', 'localhost'),
            'database': os.getenv('DB_NAME', 'default_database'),
            'user': os.getenv('DB_USER', 'root'),
            'password': os.getenv('DB_PASSWORD', ''),
            'port': int(os.getenv('DB_PORT', 3306)),
            
            # Additional connection parameters
            'connection_timeout': 10,  # Connection timeout in seconds
            'connect_retries': 3,      # Number of connection retry attempts
            'connect_retry_delay': 1,  # Delay between retry attempts
            
            # Optional SSL/TLS configuration
            # 'ssl_ca': '/path/to/ca-cert.pem',
            # 'ssl_verify_cert': True,
        }
        
        # Validate required connection parameters
        required_params = ['host', 'user', 'database']
        for param in required_params:
            if not connection_config[param]:
                raise ValueError(f"Missing required database connection parameter: {param}")
        
        # Establish database connection
        connection = mysql.connector.connect(**connection_config)
        
        # Check if connection is successful
        if connection.is_connected():
            # Optional: Database connection information logging
            db_info = connection.get_server_info()
            print(f"Connected to MySQL Server version {db_info}")
            
            return connection
        
    except Error as e:
        # Comprehensive error handling
        error_message = f"Error connecting to MySQL database: {str(e)}"
        print(error_message)
        raise ConnectionError(error_message) from e
    
    except Exception as e:
        # Catch any unexpected errors
        error_message = f"Unexpected error in database connection: {str(e)}"
        print(error_message)
        raise ConnectionError(error_message) from e

# Utility function to close database connection safely
def closeDBConnection(connection):
    '''
    Safely close an existing database connection.
    
    Args:
        connection (mysql.connector.connection.MySQLConnection): Database connection to close
    '''
    try:
        if connection and connection.is_connected():
            connection.close()
            print("MySQL connection closed.")
    except Error as e:
        print(f"Error closing MySQL connection: {str(e)}")

# Example usage context manager
class DatabaseConnection:
    '''
    Context manager for handling database connections
    Ensures proper connection and disconnection
    '''
    def __init__(self):
        self.connection = None
    
    def __enter__(self):
        self.connection = getDBConnection()
        return self.connection
    
    def __exit__(self, exc_type, exc_val, exc_tb):
        if self.connection:
            closeDBConnection(self.connection)
