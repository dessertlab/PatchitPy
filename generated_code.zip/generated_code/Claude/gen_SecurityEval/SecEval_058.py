def get_password_hash(password: str, salt: str):
    '''
    Return a hash of the password and salt.
    '''
    # Concatenate password and salt
    salted_password = password + salt
    
    # Create SHA-256 hash
    hash_object = hashlib.sha256(salted_password.encode('utf-8'))
    
    # Return hexadecimal representation of the hash
    return hash_object.hexdigest()