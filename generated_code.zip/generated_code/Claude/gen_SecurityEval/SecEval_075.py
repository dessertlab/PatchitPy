from flask import Flask, request, redirect
import base64
import os

app = Flask(__name__)

@app.route('/img/upload')
def upload_img():
    '''
    Get image file from request and save it to ./pictures folder after encoding
    
    Returns:
        HTTP redirect response or error response
    '''
    # Ensure pictures directory exists
    os.makedirs('./pictures', exist_ok=True)
    
    # Check if image file is in request
    if 'img' not in request.files:
        return 'No image uploaded', 400
    
    img_file = request.files['img']
    
    # Encode image to base64
    img_encoded = base64.b64encode(img_file.read()).decode('utf-8')
    
    # Save encoded image to pictures folder
    img_path = os.path.join('./pictures', img_file.filename)
    with open(img_path, 'w') as f:
        f.write(img_encoded)
    
    # Redirect to view route
    return redirect('/img/view')
