import hashlib
import os

def storePassword(userName, Password):
    '''
    Hash the password and update the database with username and hashed password 
    by invoking the updateUserLogin() method
    
    Args:
        userName (str): The username of the user
        Password (str): The plain text password to be hashed and stored
    
    Returns:
        dict: A dictionary containing hashing details and status
    
    Raises:
        ValueError: If username or password is empty or invalid
    '''
    # Input validation
    if not userName or not isinstance(userName, str):
        raise ValueError("Invalid username")
    
    if not Password or not isinstance(Password, str):
        raise ValueError("Invalid password")
    
    # Generate a salt (random bytes to enhance security)
    salt = os.urandom(32)  # 32 bytes = 256 bits
    
    # Create a hash using SHA-256 with salt
    # Combining salt with password prevents rainbow table attacks
    hash_algorithm = hashlib.sha256()
    
    # Encode username and password, combine with salt
    hash_algorithm.update(salt)
    hash_algorithm.update(userName.encode('utf-8'))
    hash_algorithm.update(Password.encode('utf-8'))
    
    # Get the final hash
    hashed_password = hash_algorithm.digest()
    
    try:
        # Combine salt and hashed password for storage
        # First 32 bytes are salt, remaining are hashed password
        storage_value = salt + hashed_password
        
        # Invoke database update method (placeholder)
        # In a real application, replace with actual database update
        result = updateUserLogin(userName, storage_value)
        
        return {
            "status": "success",
            "username": userName,
            "hash_method": "SHA-256",
            "salt_length": len(salt),
            "total_storage_length": len(storage_value)
        }
    
    except Exception as e:
        return {
            "status": "error",
            "message": str(e)
        }

def updateUserLogin(username, hashed_password):
    '''
    Placeholder method for updating user login in database
    
    In a real application, this would interact with your database
    
    Args:
        username (str): User's username
        hashed_password (bytes): Salted and hashed password
    
    Returns:
        bool: True if update was successful
    '''
    # Simulated database update
    # In a real scenario, this would use database connection 
    # and proper error handling
    print(f"Updating login for {username}")
    print(f"Stored password hash length: {len(hashed_password)} bytes")
    return True
