@app.route("/profile")
def profile():
    """
    Get the username from the request, make a response with it and return it
    
    Returns:
        flask.Response: A response containing the username
    """
    # Get the username from the request arguments
    username = request.args.get('username', '')
    
    # Create a response with the username
    response = make_response(username)
    
    # Return the response
    return response
