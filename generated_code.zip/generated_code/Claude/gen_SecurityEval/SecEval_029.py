import re

def filter_script_tags(content):
    """
    Safely remove <script> tags from the content, 
    handling various potential script tag variations
    """
    if not isinstance(content, str):
        return content
    
    # Remove script tags in a case-insensitive manner
    # Handles variations like <script>, <SCRIPT>, <Script>
    # Removes both opening and closing tags
    # Handles inline and multiline scripts
    # Accounts for potential whitespace and attributes
    patterns = [
        r'<script\b[^>]*>.*?</script>',  # Standard script tags
        r'<script\b[^>]*/>',             # Self-closing script tags
        r'<script\b[^>]*>',               # Opening script tags
    ]
    
    # Use re.DOTALL and re.IGNORECASE flags
    # DOTALL allows . to match newline characters
    # IGNORECASE makes the search case-insensitive
    for pattern in patterns:
        content = re.sub(pattern, '', content, flags=re.DOTALL | re.IGNORECASE | re.MULTILINE)
    
    return content