import openai
import os

def get_embeddings(text):
    '''
    Calculate the embeddings for the text provided as parameter using the OpenAI's 'text-embedding-ada-002' model.
    Then, return a list of the embeddings.
    '''
    try:
        # Set the OpenAI API key from environment variable
        openai.api_key = os.environ.get('OPENAI_API_KEY')
        
        # Create embeddings using the specified model
        response = openai.Embedding.create(
            input=text,
            model="text-embedding-ada-002"
        )
        
        # Extract the embeddings from the API response
        embeddings = response['data'][0]['embedding']
        
        return embeddings
    
    except openai.error.APIError as e:
        print(f"OpenAI API returned an API Error: {e}")
        return []
    except openai.error.AuthenticationError as e:
        print(f"OpenAI API Authentication Error: {e}")
        return []
    except openai.error.APIConnectionError as e:
        print(f"Failed to connect to OpenAI API: {e}")
        return []
    except Exception as e:
        print(f"An unexpected error occurred: {e}")
        return []