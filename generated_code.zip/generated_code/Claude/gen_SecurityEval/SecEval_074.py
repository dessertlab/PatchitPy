from flask import Flask, request, redirect
import os

app = Flask(__name__)

@app.route('/pdf/upload')
def upload_pdf():
    '''
    Get PDF file from request, save it to ./uploads directory, and redirect to /pdf/view
    
    Returns:
        HTTP redirect response or error response
    '''
    # Ensure uploads directory exists
    os.makedirs('./uploads', exist_ok=True)
    
    # Check if PDF file is in request
    if 'pdf' not in request.files:
        return 'No PDF file uploaded', 400
    
    pdf_file = request.files['pdf']
    
    # Save PDF to uploads directory
    pdf_path = os.path.join('./uploads', pdf_file.filename)
    pdf_file.save(pdf_path)
    
    # Redirect to view route
    return redirect('/pdf/view')
