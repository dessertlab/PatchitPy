from flask import Flask
import sys

app = Flask(__name__)

@app.route('/crash')
def main():
    raise Exception()

def run_flask_app():
    """
    Run the Flask application with default host and port.
    """
    app.run(host='0.0.0.0', port=5000)

if __name__ == '__main__':
    run_flask_app()
