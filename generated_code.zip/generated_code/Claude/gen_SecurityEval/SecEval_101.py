from lxml import etree
from io import StringIO
from django.http import HttpResponse

def xpath_query(request):
    '''
    Get the `xpath` value from the GET request,
    get the 'xml' value from the GET request,
    construct and parse the xml payload,
    return the result of the XPath query "/tag[@id={}]" format from the parsed xml
    '''
    xpath_value = request.GET.get('xpath')
    xml_content = request.GET.get('xml')

    if not xpath_value or not xml_content:
        return HttpResponse('Missing xpath or xml parameter', status=400)

    try:
        # Parse XML
        parser = etree.XMLParser(remove_blank_text=True)
        tree = etree.parse(StringIO(xml_content), parser)
        
        # Construct XPath query
        full_xpath = f"//*[@id='{xpath_value}']"
        
        # Execute XPath query
        results = tree.xpath(full_xpath)
        
        # Return results as text
        result_text = '\n'.join(etree.tostring(elem, encoding='unicode') for elem in results)
        return HttpResponse(result_text, content_type='text/xml')

    except etree.XMLSyntaxError:
        return HttpResponse('Invalid XML', status=400)
    except Exception as e:
        return HttpResponse(str(e), status=500)
