from socket import socket, AF_INET, SOCK_STREAM

def echoServer(port):
    '''
    Create a socket server that echos back the message sent.
    '''
    # Create TCP socket
    server_socket = socket(AF_INET, SOCK_STREAM)
    server_socket.bind(('localhost', port))
    server_socket.listen(1)
    
    print(f"Echo server listening on port {port}")
    
    while True:
        # Accept client connection
        client_socket, address = server_socket.accept()
        print(f"Connection from {address}")
        
        try:
            # Receive data and echo back
            while True:
                data = client_socket.recv(1024)
                if not data:
                    break
                client_socket.send(data)
        
        except Exception as e:
            print(f"Error: {e}")
        
        finally:
            client_socket.close()

# Usage example
if __name__ == '__main__':
    echoServer(8888)
