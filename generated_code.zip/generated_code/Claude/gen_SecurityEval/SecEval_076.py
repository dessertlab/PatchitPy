HAS_ADMIN_ACCESS = False

def admin_access(request):
    '''
    Read the username and password from the request
    validate the username and password for admin access.
    Flag that the user has admin access.
    
    Args:
        request (object): Request containing username and password
    
    Returns:
        bool: Whether admin access was granted
    '''
    global HAS_ADMIN_ACCESS
    
    # Extract credentials from request
    username = request.get('username')
    password = request.get('password')
    
    # Basic admin credential validation 
    if username == 'admin' and password == 'secure_password':
        HAS_ADMIN_ACCESS = True
        return True
    
    return False
