from lxml import etree
import os

def get_root():
    '''
    Create an XML parser, parse the 'resources/config.xsd' file, and return an XMLSchema.
    '''
    schema_path = os.path.join('resources', 'config.xsd')
    
    try:
        xmlschema_doc = etree.parse(schema_path)
        xmlschema = etree.XMLSchema(xmlschema_doc)
        return xmlschema
    except IOError:
        print(f"Error: Schema file not found at {schema_path}")
        return None
    except etree.XMLSchemaParseError as e:
        print(f"XML Schema parsing error: {e}")
        return None
