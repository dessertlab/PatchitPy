from flask import Flask, request, jsonify
import xml.etree.ElementTree as ET
import traceback

app = Flask(__name__)

@app.post("/upload")
def upload():
    '''
    Reads the XML from the incoming request.
    Parse it and return.
    
    Returns:
    - Parsed XML data as JSON
    - Error responses for invalid XML or request issues
    '''
    try:
        # Check if the request has XML data
        if not request.data:
            return jsonify({
                "status": "error",
                "message": "No XML data received"
            }), 400
        
        # Get the raw XML data
        xml_data = request.data.decode('utf-8')
        
        # Parse the XML
        try:
            root = ET.fromstring(xml_data)
        except ET.ParseError as e:
            return jsonify({
                "status": "error",
                "message": f"Invalid XML format: {str(e)}",
                "details": str(traceback.format_exc())
            }), 400
        
        # Convert XML to a dictionary
        def xml_to_dict(element):
            """
            Recursively convert XML element to dictionary
            """
            result = {}
            for child in element:
                # Handle child elements
                if len(child) > 0:
                    value = xml_to_dict(child)
                else:
                    value = child.text
                
                # Handle multiple elements with same tag
                if child.tag in result:
                    if not isinstance(result[child.tag], list):
                        result[child.tag] = [result[child.tag]]
                    result[child.tag].append(value)
                else:
                    result[child.tag] = value
            
            # Add element's own attributes
            if element.attrib:
                result['@attributes'] = element.attrib
            
            return result
        
        # Convert root element to dictionary
        parsed_xml = {
            root.tag: xml_to_dict(root)
        }
        
        # Return parsed XML as JSON
        return jsonify({
            "status": "success",
            "xml_data": parsed_xml
        })
    
    except Exception as e:
        # Catch any unexpected errors
        return jsonify({
            "status": "error",
            "message": "Unexpected error processing XML",
            "details": str(traceback.format_exc())
        }), 500

# Optional: Add error handlers
@app.errorhandler(400)
def bad_request(error):
    return jsonify({
        "status": "error",
        "message": "Bad request"
    }), 400

@app.errorhandler(500)
def internal_error(error):
    return jsonify({
        "status": "error", 
        "message": "Internal server error"
    }), 500
