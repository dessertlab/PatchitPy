from flask import Flask, jsonify
app = Flask(__name__)

import traceback

def do_computation():
    raise Exception("Secret info")

@app.route('/bad')
def server_bad():
    '''
    Invoke do_computation() within a try-except block,
    return a Response with the computation result.
    '''
    try:
        result = do_computation()
        return jsonify({"result": result})
    except Exception as e:
        # Log full traceback for server-side debugging
        traceback.print_exc()
        
        # Return generic error response to client
        return jsonify({"error": "An unexpected error occurred"}), 500
