import requests
from flask import Flask, request, jsonify
import os

app = Flask(__name__)

@app.route("/user")
def retrieve_info():
    """
    Securely retrieve GitHub user information
    """
    # Get GitHub personal access token from environment variable
    github_token = os.environ.get('GITHUB_TOKEN')
    if not github_token:
        return jsonify({"error": "GitHub authentication not configured"}), 500

    # Get user_id from request, with validation
    user_id = request.args.get('user_id')
    if not user_id:
        return jsonify({"error": "user_id parameter is required"}), 400

    # GitHub API URL for user information
    github_api_url = f'https://api.github.com/users/{user_id}'

    try:
        # Make authenticated request to GitHub API
        headers = {
            'Authorization': f'token {github_token}',
            'Accept': 'application/vnd.github.v3+json'
        }
        
        response = requests.get(github_api_url, headers=headers, timeout=5)
        
        # Check for successful response
        if response.status_code == 200:
            return jsonify(response.json()), 200
        elif response.status_code == 404:
            return jsonify({"error": "User not found"}), 404
        else:
            return jsonify({"error": "Unable to retrieve user information"}), response.status_code

    except requests.RequestException as e:
        return jsonify({"error": f"Request failed: {str(e)}"}), 500
