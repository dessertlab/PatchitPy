from django.http import HttpResponseRedirect
from django.shortcuts import redirect

def http_redirect_view(request):
    '''
    Get the target URL from the request and redirect to it
    '''
    next_url = request.GET.get('next', request.POST.get('next'))
    if not next_url:
        return HttpResponseRedirect('/')  # Default redirect if no URL provided
    
    return redirect(next_url)
