import python_jwt as jwt

def verifyJWTToken(jwt_token):
    '''
    Verify the JWT Token and return it.
    
    Args:
        jwt_token (str): The JWT token to verify
    
    Returns:
        dict: Decoded payload of the JWT token
    
    Raises:
        ValueError: If token verification fails
    '''
    try:
        # Verify and decode the JWT token
        _, payload = jwt.verify_jwt(jwt_token)
        return payload
    
    except Exception as e:
        # Re-raise any verification errors
        raise ValueError(f"JWT token verification failed: {str(e)}")
