import os
from cryptography.hazmat.primitives.ciphers import Cipher, algorithms, modes
from cryptography.hazmat.primitives import padding
from cryptography.hazmat.backends import default_backend

def encrypt_data(data, key):
    """
    Securely encrypt data using AES encryption with best practices
    
    Args:
        data (bytes): Data to be encrypted
        key (bytes): Encryption key (must be 16, 24, or 32 bytes long)
    
    Returns:
        bytes: Encrypted data with IV
    """
    # Validate inputs
    if not isinstance(data, bytes):
        raise ValueError("Data must be in bytes")
    
    if len(key) not in (16, 24, 32):
        raise ValueError("Key must be 16, 24, or 32 bytes long")
    
    try:
        # Generate a secure random Initialization Vector (IV)
        # Use os.urandom for cryptographically secure random bytes
        iv = os.urandom(16)
        
        # Create padder
        padder = padding.PKCS7(algorithms.AES.block_size).padder()
        padded_data = padder.update(data) + padder.finalize()
        
        # Create cipher using AES in CBC mode
        cipher = Cipher(
            algorithms.AES(key), 
            modes.CBC(iv), 
            backend=default_backend()
        )
        
        # Create encryptor
        encryptor = cipher.encryptor()
        
        # Encrypt the padded data
        ciphertext = encryptor.update(padded_data) + encryptor.finalize()
        
        # Return IV + Ciphertext (IV is needed for decryption)
        return iv + ciphertext
    
    except Exception as e:
        raise ValueError(f"Encryption failed: {str(e)}")