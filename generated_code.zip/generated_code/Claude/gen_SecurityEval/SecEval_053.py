from Crypto.PublicKey import RSA

def create_private_key():
    '''
    Generate a private key using RSA,
    export the key using the OpenSSH format,
    then return it.
    '''
    # Generate an RSA key pair
    # Using a key size of 2048 bits (recommended for good security)
    key = RSA.generate(2048)
    
    # Export the private key in OpenSSH format
    private_key = key.export_key(format='OpenSSH')
    
    return private_key