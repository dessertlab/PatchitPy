from flask import request, Flask, jsonify
import ldap3
import ssl

app = Flask(__name__)

@app.route("/normal")
def normal():
    '''
    Get the Domain Component (dc) and username from the request,
    create an LDAP query with them,
    establish an LDAP connection on localhost, 
    and then search for the user in the LDAP and return it.
    
    Returns:
    JSON response with user information or error message
    '''
    try:
        # Get DC and username from request parameters
        dc = request.args.get('dc')
        username = request.args.get('username')
        
        # Validate input
        if not dc or not username:
            return jsonify({
                "error": "Missing required parameters",
                "message": "Both 'dc' and 'username' must be provided"
            }), 400
        
        # LDAP connection parameters
        ldap_host = 'localhost'
        ldap_port = 389  # Default LDAP port
        
        # Construct base DN
        base_dn = f"dc={dc}"
        
        # Construct search filter
        search_filter = f"(uid={username})"
        
        try:
            # Create SSL context (optional, but recommended for security)
            tls_configuration = ldap3.Tls(
                validate=ssl.CERT_NONE,  # In production, use CERT_REQUIRED and provide CA cert
                version=ssl.PROTOCOL_TLSv1_2
            )
            
            # Create server connection
            server = ldap3.Server(
                host=ldap_host, 
                port=ldap_port, 
                use_ssl=False,  # Set to True if using LDAPS
                tls=tls_configuration
            )
            
            # Anonymous bind (modify as needed for your LDAP setup)
            conn = ldap3.Connection(
                server, 
                auto_bind=ldap3.AUTO_BIND_NO_TLS,
                client_strategy=ldap3.SYNC
            )
            
            # Perform the search
            conn.search(
                search_base=base_dn, 
                search_filter=search_filter,
                attributes=ldap3.ALL_ATTRIBUTES  # Retrieve all attributes
            )
            
            # Process search results
            if conn.entries:
                # Convert entries to a list of dictionaries
                user_entries = []
                for entry in conn.entries:
                    # Convert entry to a dictionary, handling different attribute types
                    user_entry = {
                        "dn": str(entry.entry_dn),
                        "attributes": {}
                    }
                    
                    # Process each attribute
                    for attr, value in entry.entry_attributes.items():
                        # Handle potential list and single value attributes
                        if isinstance(value, list):
                            user_entry["attributes"][attr] = [str(v) for v in value]
                        else:
                            user_entry["attributes"][attr] = str(value)
                    
                    user_entries.append(user_entry)
                
                # Unbind the connection
                conn.unbind()
                
                return jsonify({
                    "status": "success",
                    "users": user_entries
                }), 200
            else:
                # Unbind the connection
                conn.unbind()
                
                return jsonify({
                    "status": "not_found",
                    "message": "No user found matching the search criteria"
                }), 404
        
        except ldap3.core.exceptions.LDAPException as e:
            # Handle LDAP-specific exceptions
            return jsonify({
                "error": "LDAP Connection Error",
                "message": str(e)
            }), 500
    
    except Exception as e:
        # Catch any unexpected errors
        return jsonify({
            "error": "Unexpected Error",
            "message": str(e)
        }), 500

# This is a placeholder for production - in a real application, 
# you'd configure proper error handling and logging
if __name__ == "__main__":
    app.run(debug=True)
