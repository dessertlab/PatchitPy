import mysql.connector

def getConnection():
    """
    Establish and return a MySQL database connection.
    
    Returns:
    mysql.connector.connection.MySQLConnection: Database connection object
    """
    return mysql.connector.connect(
        host="localhost",
        user="root",
        password="your_password",
        database="your_database"
    )
