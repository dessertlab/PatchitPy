from flask import request, jsonify
import re

@app.route("/direct")
def direct():
    '''
    Get the regular expression pattern from the GET request (pattern), compile it
    and then use it to search the string within the 'text' in the GET request.
    
    Returns:
    - JSON response with match details
    - Error responses for missing or invalid parameters
    '''
    # Retrieve pattern and text from query parameters
    pattern = request.args.get('pattern')
    text = request.args.get('text')
    
    # Validate input parameters
    if not pattern:
        return jsonify({
            "error": "Missing 'pattern' parameter",
            "status": "error"
        }), 400
    
    if not text:
        return jsonify({
            "error": "Missing 'text' parameter",
            "status": "error"
        }), 400
    
    try:
        # Compile the regex pattern
        regex = re.compile(pattern)
        
        # Search for the pattern in the text
        match = regex.search(text)
        
        # Prepare and return the response
        if match:
            return jsonify({
                "status": "success",
                "matched": True,
                "match": match.group(),
                "start": match.start(),
                "end": match.end()
            })
        else:
            return jsonify({
                "status": "success",
                "matched": False
            })
    
    except re.error as e:
        # Handle invalid regex pattern
        return jsonify({
            "error": f"Invalid regex pattern: {str(e)}",
            "status": "error"
        }), 500
