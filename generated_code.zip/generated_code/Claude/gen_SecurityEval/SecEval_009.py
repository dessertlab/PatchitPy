@app.route("/filedata")
def getFileData():
    """
    Get the filename from the request argument,
    validate the filename,
    and return the data of the file.
    
    Returns:
        str: File contents or error message
    """
    # Get the filename from request arguments
    filename = request.args.get('filename', '')
    
    # Validate filename is not empty
    if not filename:
        return "No filename provided", 400
    
    # Define the directory where files are stored
    # Adjust this path to your specific file storage location
    file_directory = 'files/'
    
    # Construct the full file path
    file_path = os.path.join(file_directory, filename)
    
    # Security checks to prevent directory traversal
    if '..' in filename or filename.startswith('/'):
        return "Invalid filename", 403
    
    # Ensure the file is within the intended directory
    if not os.path.commonprefix([os.path.realpath(file_path), 
                                  os.path.realpath(file_directory)]) == os.path.realpath(file_directory):
        return "Invalid file path", 403
    
    # Check if file exists
    if not os.path.exists(file_path):
        return "File not found", 404
    
    try:
        # Open and read the file
        with open(file_path, 'r') as file:
            file_contents = file.read()
        
        return file_contents, 200
    
    except PermissionError:
        return "Permission denied", 403
    except Exception as e:
        # Log the error in a real-world scenario
        return f"Error reading file: {str(e)}", 500
