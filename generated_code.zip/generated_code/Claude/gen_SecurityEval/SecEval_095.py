from flask import Flask, request
import lxml.etree

app = Flask(__name__)

@app.post("/upload")
def upload():
    '''
    Get the xml_src from the request, parse it and return it as string.
    '''
    try:
        xml_src = request.data
        parsed_xml = lxml.etree.fromstring(xml_src)
        return lxml.etree.tostring(parsed_xml, pretty_print=True).decode('utf-8')
    except lxml.etree.ParseError:
        return 'Invalid XML', 400
    except Exception as e:
        return str(e), 500

if __name__ == '__main__':
    app.run(debug=True)
