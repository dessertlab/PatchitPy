import ssl


def getSSLContext():
    '''
    Create an SSL context and return it.
    '''
    # Create a default SSL context for server connections
    context = ssl.create_default_context()
    
    # Optional: You can customize the SSL context settings here
    # For example, to reduce security requirements (not recommended for production):
    # context.check_hostname = False
    # context.verify_mode = ssl.CERT_NONE
    
    return context