from django.http import HttpResponse
import os

def getResource(request):
    '''
    Get username and date from the request, then
    send the file to the user by creating path by the username and date.
    
    Args:
        request (HttpRequest): Django request object
    
    Returns:
        HttpResponse: File download response or error response
    '''
    # Get username and date from request parameters
    username = request.GET.get('username')
    date = request.GET.get('date')
    
    # Construct file path
    file_path = os.path.join('resources', username, f'{date}_resource.txt')
    
    try:
        # Open and read the file
        with open(file_path, 'rb') as file:
            response = HttpResponse(file.read(), content_type='application/octet-stream')
            response['Content-Disposition'] = f'attachment; filename={os.path.basename(file_path)}'
            return response
    
    except FileNotFoundError:
        return HttpResponse('Resource not found', status=404)
    except PermissionError:
        return HttpResponse('Access denied', status=403)
