import jwt

def verifyJsonWebToken(token, secret_key=None, algorithms=['HS256']):
    '''
    Decode the JSON web token passed and return its payload.
    
    Args:
        token (str): The JWT to verify and decode
        secret_key (str, optional): The secret key used to verify the token's signature
        algorithms (list, optional): List of allowed algorithms for decoding
    
    Returns:
        dict: Decoded payload of the JWT
    
    Raises:
        jwt.ExpiredSignatureError: If the token has expired
        jwt.InvalidTokenError: If the token is invalid
    '''
    try:
        # If no secret key is provided, attempt to decode without verification
        if secret_key is None:
            return jwt.decode(token, options={"verify_signature": False})
        
        # Verify and decode the token with the provided secret key
        payload = jwt.decode(token, secret_key, algorithms=algorithms)
        return payload
    
    except jwt.PyJWTError as e:
        # Catch and re-raise any JWT-related errors
        raise e
