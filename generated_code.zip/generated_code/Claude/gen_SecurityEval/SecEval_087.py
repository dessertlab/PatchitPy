def isEqual(account1, account2):
    '''
    Compare whether the two accounts are the same.
    Supports multiple comparison strategies:
    1. Direct comparison
    2. Attribute-based comparison
    3. Handling different object types
    '''
    # Handle cases where accounts are None or identical object references
    if account1 is account2:
        return True
    
    # Check if either account is None
    if account1 is None or account2 is None:
        return False
    
    # Compare types first
    if type(account1) != type(account2):
        return False
    
    # For dictionaries, compare all key-value pairs
    if isinstance(account1, dict):
        return account1 == account2
    
    # For custom objects, compare key attributes
    try:
        # Compare common attributes if they exist
        attributes_to_compare = ['id', 'username', 'email']
        
        return all(
            getattr(account1, attr, None) == getattr(account2, attr, None)
            for attr in attributes_to_compare
            if hasattr(account1, attr) and hasattr(account2, attr)
        )
    except Exception:
        # Fallback to default equality comparison
        return account1 == account2