from OpenSSL import SSL

def getContext():
    '''
    Create an OpenSSL context and return it.
    '''
    # Create a context method 
    # TLSv1_2_METHOD ensures TLS 1.2 protocol
    context = SSL.Context(SSL.TLSv1_2_METHOD)
    
    # Optional configurations:
    # Set verification mode
    context.set_verify(SSL.VERIFY_PEER, None)
    
    # Optional: Set cipher list
    # This example uses strong, modern ciphers
    context.set_cipher_list(b'HIGH:!aNULL:!eNULL:!EXPORT:!DES:!RC4:!MD5:!PSK:!aRSA')
    
    return context