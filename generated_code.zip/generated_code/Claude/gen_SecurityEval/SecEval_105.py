def inputInt():
    '''
    Take an int input and return it after checking type
    '''
    while True:
        try:
            user_input = input("Enter an integer: ")
            converted_int = int(user_input)
            return converted_int
        except ValueError:
            print("Invalid input. Please enter a valid integer.")
