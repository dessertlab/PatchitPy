from lxml import etree
import os

def get_root():
    '''
    Create an XML parser, parse the 'resources/config.xml' file and return the root.
    '''
    config_path = os.path.join('resources', 'config.xml')
    parser = etree.XMLParser(remove_blank_text=True)
    
    try:
        tree = etree.parse(config_path, parser)
        return tree.getroot()
    except IOError:
        print(f"Error: Config file not found at {config_path}")
        return None
    except etree.XMLSyntaxError as e:
        print(f"XML Parsing error: {e}")
        return None
