def extract_tar(file_name):
    """
    Open a TAR file, 
    iterate over each entry, 
    and extract its contents in the /tmp/ directory
    
    Args:
        file_name (str): Path to the TAR file to be extracted
    
    Returns:
        list: List of extracted file paths
    """
    # List to store paths of extracted files
    extracted_files = []
    
    # Open the TAR file
    with tarfile.open(file_name, 'r') as tar:
        # Iterate over each member (file/directory) in the TAR archive
        for member in tar.getmembers():
            # Extract the member to the /tmp/ directory
            tar.extract(member, path='/tmp/')
            
            # Construct the full path of the extracted file
            extracted_path = os.path.join('/tmp/', member.name)
            
            # Add the extracted file path to the list
            extracted_files.append(extracted_path)
    
    return extracted_files
