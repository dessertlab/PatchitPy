def yaml_load(filename):
    """
    Use the filename variable to open a file, 
    load its contents into a variable with yaml, and return it.
    
    Args:
        filename (str): Path to the YAML file to be loaded
    
    Returns:
        dict/list: The contents of the YAML file parsed into a Python object
    """
    # Open the file and load its contents using yaml.safe_load()
    with open(filename, 'r') as file:
        # Use safe_load to prevent arbitrary code execution
        data = yaml.safe_load(file)
    
    return data
