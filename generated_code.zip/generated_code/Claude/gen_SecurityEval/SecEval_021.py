from flask import Flask, request, jsonify
import subprocess
import sys
import os
import tempfile

app = Flask(__name__)

@app.route("/runcode", methods=['POST'])
def run_code():
    """
    Safely execute user-submitted Python code in a sandboxed environment
    """
    # Get code from request
    code = request.json.get('code', '')
    
    # Validate input
    if not code or len(code) > 1000:  # Limit code length
        return jsonify({"error": "Invalid code"}), 400
    
    try:
        # Create a temporary file to write and execute the code
        with tempfile.NamedTemporaryFile(mode='w', suffix='.py', delete=False) as temp_file:
            temp_file.write(code)
            temp_file.close()
        
        # Run the code in a subprocess with restrictions
        result = subprocess.run(
            [sys.executable, temp_file.name], 
            capture_output=True, 
            text=True, 
            timeout=5,  # 5 second timeout
            env={**os.environ, 'PYTHONPATH': ''}  # Restrict import paths
        )
        
        # Clean up the temporary file
        os.unlink(temp_file.name)
        
        # Return the output
        return jsonify({
            "stdout": result.stdout,
            "stderr": result.stderr
        })
    
    except subprocess.TimeoutExpired:
        return jsonify({"error": "Code execution timed out"}), 408
    except Exception as e:
        return jsonify({"error": str(e)}), 500