from flask import Flask, request, jsonify
import MySQLdb
import hashlib
import secrets
import os
import re

app = Flask(__name__)

@app.route('/register', methods=['POST'])
def register():
    '''
    Secure user registration endpoint with multiple security layers:
    - Input validation
    - Password strength checking
    - Secure password hashing
    - Database insertion protection
    '''
    try:
        # Get registration data
        data = request.get_json()
        
        # Validate input exists
        if not data:
            return jsonify({"error": "No input data provided"}), 400
        
        username = data.get('username', '').strip()
        password = data.get('password', '')
        
        # Input validation
        if not username or not password:
            return jsonify({"error": "Username and password are required"}), 400
        
        # Username validation
        if not re.match(r'^[a-zA-Z0-9_]{3,20}$', username):
            return jsonify({
                "error": "Invalid username. Must be 3-20 characters, alphanumeric or underscore"
            }), 400
        
        # Password strength validation
        if not is_password_strong(password):
            return jsonify({
                "error": "Weak password. Must be at least 12 characters with mix of uppercase, lowercase, numbers, and symbols"
            }), 400
        
        # Database connection (use environment variables)
        db = MySQLdb.connect(
            host=os.getenv('DB_HOST', 'localhost'),
            user=os.getenv('DB_USER', 'dbuser'),
            passwd=os.getenv('DB_PASSWORD', ''),
            db=os.getenv('DB_NAME', 'userdb')
        )
        cursor = db.cursor()
        
        # Check if username already exists (prevent duplicate registrations)
        cursor.execute("SELECT * FROM users WHERE username = %s", (username,))
        if cursor.fetchone():
            db.close()
            return jsonify({"error": "Username already exists"}), 409
        
        # Generate secure salt and hash
        salt = secrets.token_hex(16)  # 32-character cryptographic salt
        password_hash = hash_password(password, salt)
        
        # Secure database insertion with parameterized query
        try:
            cursor.execute(
                "INSERT INTO users (username, password_hash, salt) VALUES (%s, %s, %s)",
                (username, password_hash, salt)
            )
            db.commit()
        except MySQLdb.Error as e:
            db.rollback()
            return jsonify({"error": "Database insertion failed"}), 500
        finally:
            db.close()
        
        return jsonify({"message": "User registered successfully"}), 201
    
    except Exception as e:
        # Log the error (use proper logging in production)
        print(f"Registration error: {e}")
        return jsonify({"error": "Registration failed"}), 500

def is_password_strong(password):
    '''
    Validate password strength
    '''
    # Check password complexity
    if len(password) < 12:
        return False
    
    # Check for at least one of each:
    # - Uppercase letter
    # - Lowercase letter
    # - Number
    # - Special character
    if not (
        re.search(r'[A-Z]', password) and
        re.search(r'[a-z]', password) and
        re.search(r'\d', password) and
        re.search(r'[!@#$%^&*(),.?":{}|<>]', password)
    ):
        return False
    
    return True

def hash_password(password, salt):
    '''
    Securely hash password using PBKDF2
    '''
    # Use PBKDF2 with SHA-256 for secure password hashing
    password_hash = hashlib.pbkdf2_hmac(
        'sha256',       # Hash algorithm
        password.encode('utf-8'),  # Password to hash
        salt.encode('utf-8'),  # Salt 
        100000,         # 100,000 iterations
        dklen=32        # 256-bit key
    )
    
    # Return base64 encoded hash
    return hashlib.sha256(password_hash).hexdigest()

# Error handler for method not allowed
@app.errorhandler(405)
def method_not_allowed(e):
    return jsonify({"error": "Method not allowed"}), 405

# Optional: Rate limiting middleware would be ideal here
# to prevent brute-force registration attempts
