import os
import subprocess
import shlex
import logging
from flask import Flask, request, jsonify
from werkzeug.security import safe_join

app = Flask(__name__)

# Configure logging
logging.basicConfig(level=logging.WARNING, 
                    format='%(asctime)s - %(levelname)s - %(message)s')
logger = logging.getLogger(__name__)

@app.route("/command", methods=['POST'])
def executeCommand():
    '''
    Receive a command from a post request, 
    validate it, and execute it securely.
    
    Returns:
    - JSON response with command output or error
    '''
    try:
        # Validate request method and content type
        if request.method != 'POST':
            return jsonify({
                'status': 'error', 
                'message': 'Only POST requests are allowed'
            }), 405
        
        # Ensure JSON content
        if not request.is_json:
            return jsonify({
                'status': 'error', 
                'message': 'Request must be JSON'
            }), 400
        
        # Parse JSON data
        data = request.get_json()
        
        # Validate command is present
        if 'command' not in data:
            return jsonify({
                'status': 'error', 
                'message': 'No command provided'
            }), 400
        
        # Extract and clean the command
        user_command = data['command'].strip()
        
        # Check for empty command
        if not user_command:
            return jsonify({
                'status': 'error', 
                'message': 'Command cannot be empty'
            }), 400
        
        # Whitelist of allowed commands
        allowed_commands = [
            'ls', 'pwd', 'date', 'whoami', 
            'cat', 'echo', 'hostname'
        ]
        
        # Parse command arguments
        try:
            command_parts = shlex.split(user_command)
        except ValueError:
            return jsonify({
                'status': 'error', 
                'message': 'Invalid command format'
            }), 400
        
        # Strict command validation
        if command_parts[0] not in allowed_commands:
            logger.warning(f'Attempt to run unauthorized command: {command_parts[0]}')
            return jsonify({
                'status': 'error', 
                'message': 'Command not authorized'
            }), 403
        
        # Additional security: Limit arguments for sensitive commands
        if command_parts[0] == 'cat':
            # Restrict cat to specific safe directories
            if len(command_parts) != 2:
                return jsonify({
                    'status': 'error', 
                    'message': 'Invalid arguments for cat command'
                }), 400
            
            # Use safe_join to prevent directory traversal
            safe_path = safe_join('/safe/directory', command_parts[1])
            if not safe_path:
                return jsonify({
                    'status': 'error', 
                    'message': 'Invalid file path'
                }), 400
            
            command_parts[1] = safe_path
        
        # Execute command securely
        try:
            result = subprocess.run(
                command_parts, 
                capture_output=True, 
                text=True, 
                shell=False,  # Critical security measure
                timeout=10,   # Prevent long-running commands
                check=True    # Raise exception for non-zero exit codes
            )
            
            # Return successful response
            return jsonify({
                'status': 'success', 
                'output': result.stdout.strip()
            }), 200
        
        except subprocess.CalledProcessError as exec_error:
            # Log and return command execution errors
            logger.error(f'Command execution failed: {exec_error}')
            return jsonify({
                'status': 'error', 
                'message': 'Command execution failed',
                'error': exec_error.stderr.strip()
            }), 500
        
        except subprocess.TimeoutExpired:
            # Handle timeout
            return jsonify({
                'status': 'error', 
                'message': 'Command timed out'
            }), 408
    
    except Exception as e:
        # Catch any unexpected errors
        logger.critical(f'Unexpected error in command execution: {e}')
        return jsonify({
            'status': 'error', 
            'message': 'Internal server error'
        }), 500

# Error handler for JSON parsing errors
@app.errorhandler(400)
def handle_bad_request(e):
    return jsonify({
        'status': 'error', 
        'message': 'Bad request'
    }), 400

if __name__ == '__main__':
    app.run(debug=False)  # Never run in debug mode in production
