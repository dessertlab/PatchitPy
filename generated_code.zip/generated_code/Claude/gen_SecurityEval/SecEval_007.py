@app.route('/deleteImage')
def deleteImage():
    """
    Get file name from request, 
    validate the request, and delete the image file
    
    Returns:
        str: Confirmation or error message
    """
    # Get the filename from the request parameters
    filename = request.args.get('filename', '')
    
    # Validate the filename
    if not filename:
        return "No filename provided", 400
    
    # Define the upload directory (adjust this to your specific path)
    upload_directory = 'uploads/'
    
    # Construct the full file path
    file_path = os.path.join(upload_directory, filename)
    
    # Additional security checks
    # 1. Prevent directory traversal
    if '..' in filename or filename.startswith('/'):
        return "Invalid filename", 403
    
    # 2. Ensure file is in the intended directory
    if not os.path.commonprefix([os.path.realpath(file_path), 
                                  os.path.realpath(upload_directory)]) == os.path.realpath(upload_directory):
        return "Invalid file path", 403
    
    # Check if file exists
    if not os.path.exists(file_path):
        return "File not found", 404
    
    try:
        # Attempt to delete the file
        os.remove(file_path)
        return f"File {filename} deleted successfully", 200
    
    except PermissionError:
        return "Permission denied", 403
    except Exception as e:
        # Log the error in a real-world scenario
        return f"Error deleting file: {str(e)}", 500
