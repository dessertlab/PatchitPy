import os
import random

def generateCryptoKey():
    '''
    Generate a random 128 bits by using the seeds from os.urandom().
    
    Returns:
    bytes: A 16-byte (128-bit) cryptographically secure random key
    '''
    # Use os.urandom() to generate cryptographically secure random bytes
    crypto_key = os.urandom(16)
    return crypto_key
