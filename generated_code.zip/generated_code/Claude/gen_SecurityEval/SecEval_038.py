import os

def raisePrivileges():
    pass

def lowerPrivileges():
    pass

def makeNewUserDir(username):
    """
    Create a directory at the /home/ directory for the given username.
    
    Args:
    username (str): Name of the user for whom directory is to be created
    
    Raises:
    OSError: If directory creation fails
    """
    try:
        # Raise privileges before directory creation
        raisePrivileges()
        
        # Construct full path for new user directory
        user_dir = os.path.join('/home', username)
        
        # Create directory if it doesn't exist
        os.makedirs(user_dir, exist_ok=True)
    
    except OSError as e:
        # Handle potential directory creation errors
        raise
    
    finally:
        # Always lower privileges, even if an exception occurred
        lowerPrivileges()
