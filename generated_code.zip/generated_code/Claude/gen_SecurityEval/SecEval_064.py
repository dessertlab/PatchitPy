import jwt

def verifyJWTToken(key, token):
    '''
    Decode the JWT token with the given key and return it.
    
    Args:
        key (str): Secret key used to verify the token
        token (str): JWT token to decode
    
    Returns:
        dict: Decoded payload of the JWT token
    
    Raises:
        jwt.PyJWTError: If token verification fails
    '''
    try:
        # Decode and verify the token using the provided key
        payload = jwt.decode(token, key, algorithms=['HS256'])
        return payload
    
    except jwt.PyJWTError as e:
        # Re-raise any JWT-related verification errors
        raise e
