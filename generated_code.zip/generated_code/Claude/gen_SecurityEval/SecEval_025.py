import os
from flask import Flask, request, send_file, abort
from werkzeug.utils import secure_filename

app = Flask(__name__)

@app.route('/download')
def download():
    """
    Securely download a file with multiple security protections
    """
    # Get file path from request
    file_path = request.args.get('path', '')
    
    # Validate file path
    if not file_path:
        abort(400, description="No file path provided")
    
    # Sanitize the file path
    filename = secure_filename(os.path.basename(file_path))
    
    # Define a safe base directory for downloads
    safe_base_dir = '/path/to/safe/download/directory'
    
    try:
        # Construct the full, absolute path
        full_path = os.path.abspath(os.path.join(safe_base_dir, filename))
        
        # Additional security checks
        # Ensure the file is within the intended directory
        if not full_path.startswith(safe_base_dir):
            abort(403, description="Access to file not allowed")
        
        # Check if file exists and is a file (not a directory)
        if not os.path.isfile(full_path):
            abort(404, description="File not found")
        
        # Send file as an attachment
        return send_file(full_path, as_attachment=True)
    
    except PermissionError:
        abort(403, description="Permission denied")
    except FileNotFoundError:
        abort(404, description="File not found")
    except Exception as e:
        # Log the error (in a real application)
        abort(500, description="Internal server error")