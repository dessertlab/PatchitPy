import socket
import ssl

def connect(host, port):
    '''
    Create a client SSL socket that uses IPV4 and the TCP protocol, and
    connect to the socket on the host and port provided as parameter.
    Then, return the socket.
    '''
    try:
        # Create a standard TCP socket using IPv4
        base_socket = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
        
        # Create an SSL context with default secure settings
        context = ssl.create_default_context()
        
        # Wrap the base socket with SSL
        secure_socket = context.wrap_socket(
            base_socket, 
            server_hostname=host
        )
        
        # Connect to the specified host and port
        secure_socket.connect((host, port))
        
        return secure_socket
    
    except socket.error as e:
        print(f"Socket connection error: {e}")
        raise
    except ssl.SSLError as e:
        print(f"SSL connection error: {e}")
        raise
    except Exception as e:
        print(f"Unexpected error during connection: {e}")
        raise