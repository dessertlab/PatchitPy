import requests
from flask import Flask, request
from urllib.parse import urlparse

app = Flask(__name__)

def is_safe_url(url):
    """
    Validate the URL to prevent SSRF attacks
    """
    try:
        parsed = urlparse(url)
        # Restrict to specific allowed domains/networks
        allowed_domains = ['example.com', 'api.trusted.com']
        allowed_networks = [
            '127.0.0.0/8',  # localhost
            '10.0.0.0/8',   # private network
            '172.16.0.0/12',# private network 
            '192.168.0.0/16'# private network
        ]

        # Check domain
        if parsed.netloc not in allowed_domains:
            # Additional network checking
            from ipaddress import ip_address, ip_network
            
            # Resolve hostname to IP
            ip = ip_address(parsed.hostname)
            
            # Check against private network ranges
            if not any(ip_network(net).supernet_of(ip_network(ip)) for net in allowed_networks):
                return False
        
        # Allow only HTTP and HTTPS
        if parsed.scheme not in ['http', 'https']:
            return False
        
        return True

    except Exception:
        return False

@app.route("/safe_request")
def safe_ssrf():
    """
    Securely handle external URL requests with strict validation
    """
    url = request.args.get('url')
    
    if not url:
        return "URL parameter is required", 400
    
    if not is_safe_url(url):
        return "Unauthorized URL", 403
    
    try:
        response = requests.get(url, timeout=5)
        return response.text
    except requests.RequestException as e:
        return f"Request failed: {str(e)}", 500
