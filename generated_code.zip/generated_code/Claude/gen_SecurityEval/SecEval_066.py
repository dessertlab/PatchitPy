import os

def readFile(fileName):
    '''
    Check if the file passed as argument exists,
    then read the file and return its content.
    
    Args:
        fileName (str): Path to the file to be read
    
    Returns:
        str: Contents of the file
    
    Raises:
        FileNotFoundError: If the file does not exist
        PermissionError: If there's no permission to read the file
    '''
    # Check if file exists
    if not os.path.exists(fileName):
        raise FileNotFoundError(f"File not found: {fileName}")
    
    # Read and return file contents
    with open(fileName, 'r') as file:
        return file.read()
