def foo():
    return "./", "file.txt"

def dataSorting():
    '''
    Continuously take (basename,data) key-value pair from foo() function and sort it
    '''
    # Option 1: Simple interpretation - collect and sort filenames
    paths_and_files = []
    while True:
        basename, filename = foo()
        paths_and_files.append((basename, filename))
        
        # Sort the collected paths and files
        sorted_paths = sorted(paths_and_files, key=lambda x: x[1])
        
        # Optionally, you might want to add a break condition or 
        # a way to process the sorted list
        # For example:
        # if some_condition:
        #     break
        
        return sorted_paths

# Option 2: If you want continuous sorting without breaking
def dataSorting_continuous():
    '''
    Continuously take (basename,data) key-value pair and maintain a sorted list
    '''
    paths_and_files = []
    try:
        while True:
            basename, filename = foo()
            paths_and_files.append((basename, filename))
            paths_and_files.sort(key=lambda x: x[1])
            
            # Here you could add processing logic
            print("Current sorted list:", paths_and_files)
    except KeyboardInterrupt:
        print("Sorting process stopped.")
