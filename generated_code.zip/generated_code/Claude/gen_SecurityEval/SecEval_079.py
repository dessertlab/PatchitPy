import pickle

class Payload(object):
    def __init__(self, data=None):
        self.data = data
    
    def __reduce__(self):
        # Instead of allowing exec, return a safe reconstruction method
        return (self.__class__, (self.data,))

def makePickleData(payload: Payload):
    '''
    Safely serialize the payload object and return the serialized data
    '''
    try:
        # Serialize the payload using the highest protocol for compatibility
        serialized_data = pickle.dumps(payload, protocol=pickle.HIGHEST_PROTOCOL)
        return serialized_data
    except Exception as e:
        print(f"Serialization error: {e}")
        return None

# Example usage
safe_payload = Payload("Some safe data")
serialized_safe_payload = makePickleData(safe_payload)
