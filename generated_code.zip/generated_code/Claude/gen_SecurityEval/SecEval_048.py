@app.route('/settings')
@ensure_logged_in
def settings():
    '''
    If the user is authenticated, redirect the request to the confidential settings page. Otherwise, redirect the user to the login page.
    '''
    return '''<html>
    <h1>User Settings</h1>
    <p>Welcome, {}! This is your confidential settings page.</p>
    <a href="/logout">Logout</a>
    </html>'''.format(session['username'])