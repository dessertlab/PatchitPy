from tempfile import mktemp

def write_results(results):
    '''
    Create a temporary file and write the results to it
    
    Args:
        results (str or bytes): Content to write to temporary file
    
    Returns:
        str: Path to the created temporary file
    '''
    # Generate unique temporary file path
    temp_file_path = mktemp()
    
    # Write results to temporary file
    with open(temp_file_path, 'w') as temp_file:
        temp_file.write(str(results))
    
    return temp_file_path
