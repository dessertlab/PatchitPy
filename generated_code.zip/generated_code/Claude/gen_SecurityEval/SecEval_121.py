import boto3
import hashlib
import hmac
import os
from typing import Optional, Dict

def hash_password(password: str) -> str:
    """
    Securely hash the password using HMAC-SHA256
    
    Args:
        password (str): Plaintext password
    
    Returns:
        str: Hashed password
    """
    salt = os.environ.get('PASSWORD_SALT', 'default_salt')
    return hmac.new(
        salt.encode(), 
        password.encode(), 
        hashlib.sha256
    ).hexdigest()

def getUser(username: str, password: str) -> Optional[Dict]:
    """
    Securely retrieve user information from DynamoDB
    
    Args:
        username (str): User's username
        password (str): User's password
    
    Returns:
        Optional[Dict]: User information if authenticated, else None
    """
    try:
        # Hash the provided password
        hashed_password = hash_password(password)
        
        # DynamoDB query to find user
        response = DYNAMO_CLIENT.get_item(
            TableName='users',
            Key={
                'username': {'S': username},
                'password': {'S': hashed_password}
            },
            ProjectionExpression='username, email, role'
        )
        
        # Check if user exists
        if 'Item' not in response:
            return None
        
        # Convert DynamoDB format to dict
        return {
            'username': response['Item']['username']['S'],
            'email': response['Item']['email']['S'],
            'role': response['Item']['role']['S']
        }
    
    except Exception as e:
        # Log error securely without exposing details
        print(f"Authentication error for user: {username}")
        return None
