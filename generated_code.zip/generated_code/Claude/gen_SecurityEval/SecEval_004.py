@app.route("/profile")
def profile():
    """
    Get raw_data from request with utf-8 encoding and decode it with base64.
    Deserialize the decoded data, store it in a variable and return it
    """
    # Get raw_data from the request and decode it from utf-8
    raw_data = request.args.get('raw_data', '').encode('utf-8')
    
    # Decode the base64 encoded data 
    decoded_data = base64.b64decode(raw_data)
    
    # Deserialize the decoded data using pickle
    deserialized_data = pickle.loads(decoded_data)
    
    # Return the deserialized data
    return str(deserialized_data)
