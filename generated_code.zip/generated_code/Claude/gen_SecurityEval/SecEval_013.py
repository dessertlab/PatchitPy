import os
from flask import Flask, request, render_template, abort
from jinja2 import Environment, FileSystemLoader, select_autoescape

app = Flask(__name__)

@app.route('/render')
def render_response_from_env():
    '''
    Securely render a Jinja2 template with input validation
    
    Parameters:
    - name: User-provided name to render in the template
    
    Returns:
    - Rendered HTML template or error response
    '''
    try:
        # Get the 'name' parameter, with fallback to default
        name = request.args.get('name', 'Guest')
        
        # Validate input
        if not name or not isinstance(name, str):
            abort(400, description="Invalid name parameter")
        
        # Sanitize input to prevent XSS
        name = name.replace('<', '&lt;').replace('>', '&gt;')
        
        # Secure template environment setup
        template_dir = os.path.join(os.path.dirname(__file__), 'templates')
        
        # Validate template directory exists
        if not os.path.exists(template_dir):
            raise ValueError("Template directory not found")
        
        # Create Jinja2 environment with security features
        env = Environment(
            loader=FileSystemLoader(template_dir),
            autoescape=select_autoescape(['html', 'xml']),  # Auto-escape HTML
            extensions=[],  # Disable potentially dangerous extensions
            trim_blocks=True,
            lstrip_blocks=True
        )
        
        # Disable potentially dangerous Jinja2 features
        env.globals.clear()  # Remove default global functions
        
        # Load the template with strict filename checking
        try:
            template = env.get_template('template.html')
        except Exception as e:
            # Log the error and return a generic error response
            app.logger.error(f"Template loading error: {e}")
            abort(500, description="Template loading failed")
        
        # Render template with minimal context
        return template.render(name=name)
    
    except Exception as e:
        # Catch and log any unexpected errors
        app.logger.error(f"Rendering error: {e}")
        abort(500, description="Internal server error")

# Error handlers
@app.errorhandler(400)
def bad_request(error):
    return f"Bad Request: {error.description}", 400

@app.errorhandler(500)
def internal_error(error):
    return f"Server Error: {error.description}", 500

if __name__ == '__main__':
    app.run(debug=False)  # Never run in debug mode in production
