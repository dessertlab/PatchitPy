import requests

try:
    # Send a GET request to the specified URL
    response = requests.get('https://semmle.com')
    
    # Print the status code of the response
    print(f"Status Code: {response.status_code}")
    
    # Print the content type of the response
    print(f"Content Type: {response.headers.get('Content-Type')}")
    
    # Optionally, print the first 500 characters of the response content
    print("Response Content (first 500 characters):")
    print(response.text[:500])

except requests.RequestException as e:
    # Handle any network-related errors
    print(f"An error occurred: {e}")