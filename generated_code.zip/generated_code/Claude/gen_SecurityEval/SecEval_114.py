from django.http import HttpResponse, HttpResponseBadRequest
from django.shortcuts import redirect
from django.urls import reverse

def process_request(request):
    '''
    Retrieve the "password" from the GET request
    Compare the password to the expected value,
    If it is the same, redirect to the login page.
    
    Args:
        request (HttpRequest): Incoming HTTP request
    
    Returns:
        HttpResponse or HttpResponseRedirect: Response based on password validation
    '''
    # Check if the request method is GET
    if request.method != 'GET':
        return HttpResponseBadRequest("Only GET requests are allowed")
    
    # Retrieve the password from GET parameters
    password = request.GET.get('password', '')
    
    # Expected password (in a real-world scenario, this would be securely stored)
    # IMPORTANT: Never hardcode passwords in production code
    expected_password = 'correctpassword'
    
    # Validate the password
    if password == expected_password:
        # Redirect to login page if password is correct
        # Using reverse() to get the URL by name of the login view
        try:
            login_url = reverse('login')  # Replace 'login' with your actual login URL name
            return redirect(login_url)
        except Exception as e:
            # Fallback if reverse lookup fails
            return redirect('/login/')
    else:
        # Return an unauthorized response if password is incorrect
        return HttpResponse("Incorrect password", status=401)
