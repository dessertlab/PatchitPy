def getSessionID():
   '''
   Return a random and unique session ID.
   '''
   # Generate a random session ID as a 32-character hexadecimal string
   return ''.join(random.choice('0123456789abcdef') for _ in range(32))