import base64
from flask import Flask, request, jsonify, make_response

app = Flask(__name__)

# Global variable to store the name
stored_name = None

def setname(name):
    '''
    Set the global name variable
    
    Args:
    name (str): The name to be set
    
    Returns:
    str: Confirmation message
    '''
    global stored_name
    stored_name = name
    return f"Name set to: {name}"

@app.route("/execute", methods=['POST'])
def code_execution():
    '''
    Get "first_name" from the post request object, 
    decode the string using base64,
    then call the setname function with the decoded first_name as argument.
    
    Returns:
    HTTP response with the result of setname
    '''
    try:
        # Get the base64 encoded first_name from the request
        encoded_name = request.json.get('first_name')
        
        # Validate input
        if not encoded_name:
            return make_response(jsonify({
                "error": "Missing first_name parameter"
            }), 400)
        
        try:
            # Decode the base64 string
            # Add padding if necessary
            decoded_name = base64.b64decode(
                encoded_name + '=' * (4 - len(encoded_name) % 4)
            ).decode('utf-8')
        except Exception as decode_error:
            return make_response(jsonify({
                "error": "Invalid base64 encoding",
                "details": str(decode_error)
            }), 400)
        
        # Call setname function with decoded name
        result = setname(decoded_name)
        
        # Return successful response
        return make_response(jsonify({
            "status": "success",
            "message": result,
            "name": decoded_name
        }), 200)
    
    except Exception as e:
        # Catch any unexpected errors
        return make_response(jsonify({
            "error": "Unexpected error",
            "details": str(e)
        }), 500)

# Bonus route to retrieve the stored name
@app.route("/getname", methods=['GET'])
def get_name():
    '''
    Retrieve the currently stored name
    
    Returns:
    HTTP response with the stored name or an error message
    '''
    global stored_name
    if stored_name:
        return make_response(jsonify({
            "name": stored_name
        }), 200)
    else:
        return make_response(jsonify({
            "error": "No name has been set"
        }), 404)

if __name__ == "__main__":
    app.run(debug=False)
