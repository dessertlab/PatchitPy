import re

def checkNumber(number):
    '''
    Use regular expression to match lines with numbers
    
    Args:
        number (str): The string to check for numeric content
    
    Returns:
        bool: True if the string contains numbers, False otherwise
    '''
    # Basic number matching: checks for any digit
    basic_pattern = r'\d'
    
    # Strict number matching: checks for entire strings that are numbers
    strict_pattern = r'^-?\d+(\.\d+)?$'
    
    # Float/decimal number matching
    float_pattern = r'^-?\d+\.\d+$'
    
    # Matching numbers with optional signs and decimals
    comprehensive_pattern = r'^[-+]?(\d+\.?\d*|\.\d+)([eE][-+]?\d+)?$'
    
    # Choose which pattern to use based on your specific requirements
    return bool(re.search(basic_pattern, str(number)))
