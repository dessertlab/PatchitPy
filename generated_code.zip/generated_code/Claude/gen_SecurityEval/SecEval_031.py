from flask import Flask, request, abort
import logging
import re

app = Flask(__name__)

# Configure logging with additional safety and clarity
logging.basicConfig(
    level=logging.INFO,
    format='%(asctime)s - %(levelname)s - %(message)s',
    filename='app_request_log.log'
)

@app.route('/logger')
def logger():
    """
    Safely log the 'name' parameter from the request
    
    Returns:
        str: Confirmation message
    """
    # Get name parameter from request
    name = request.args.get('name', '')
    
    # Validate name input
    if not name:
        abort(400, description="No name provided")
    
    # Sanitize name to prevent log injection
    # Allow only alphanumeric characters, spaces, and some safe punctuation
    if not re.match(r'^[a-zA-Z0-9\s\-_.,\']+$', name):
        abort(400, description="Invalid name format")
    
    try:
        # Log the name with added context and safety
        logging.info(f"Received name: {name}", extra={
            'request_method': request.method,
            'remote_addr': request.remote_addr
        })
        
        return f"Name '{name}' has been logged successfully"
    
    except Exception as e:
        # Log any unexpected errors
        logging.error(f"Error processing request: {str(e)}")
        abort(500, description="Internal server error")