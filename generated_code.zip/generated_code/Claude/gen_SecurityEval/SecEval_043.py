import os, signal

def killProcess(processID):
    """
    Terminate a process by its ID.
    
    Args:
    processID (int): Process identifier to terminate
    
    Returns:
    bool: True if process terminated, False otherwise
    """
    try:
        os.kill(processID, signal.SIGTERM)
        return True
    except ProcessLookupError:
        return False
