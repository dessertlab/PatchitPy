from flask import Flask, request, make_response, escape
import re

app = Flask(__name__)

@app.route('/showName')
def name():
    '''
    Securely retrieve and display name from request parameters
    
    Validates input, sanitizes output, and creates a secure response
    
    Returns:
    - Response object with validated and sanitized name
    - Error response for invalid inputs
    '''
    try:
        # Retrieve name parameter with default
        raw_name = request.args.get('name', '').strip()
        
        # Input validation
        if not raw_name:
            return make_response('Error: Name parameter is required', 400)
        
        # Validate name format (letters, spaces, hyphens only)
        if not re.match(r'^[A-Za-z\s-]{1,50}$', raw_name):
            return make_response('Error: Invalid name format', 400)
        
        # Sanitize name to prevent XSS
        sanitized_name = escape(raw_name)
        
        # Create response with security headers
        response = make_response(f"Hello, {sanitized_name}!")
        
        # Add security headers
        response.headers['X-Content-Type-Options'] = 'nosniff'
        response.headers['X-Frame-Options'] = 'DENY'
        response.headers['Content-Type'] = 'text/plain; charset=utf-8'
        
        # Set cache control to prevent caching of sensitive response
        response.headers['Cache-Control'] = 'no-store, no-cache, must-revalidate, max-age=0'
        response.headers['Pragma'] = 'no-cache'
        
        return response
    
    except Exception as e:
        # Catch any unexpected errors
        app.logger.error(f"Unexpected error in name route: {e}")
        return make_response('Internal Server Error', 500)

if __name__ == '__main__':
    app.run(debug=False)  # Never run in debug mode in production
