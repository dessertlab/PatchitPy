import time

def currentTime():
    '''
    Print the current processor time in seconds.
    '''
    # Option 1: time.time() - Wall clock time
    print("Wall Clock Time:", time.time())
    
    # Option 2: time.process_time() - CPU process time
    print("Process Time:", time.process_time())
    
    # Option 3: time.perf_counter() - High-resolution performance timer
    print("Performance Counter Time:", time.perf_counter())