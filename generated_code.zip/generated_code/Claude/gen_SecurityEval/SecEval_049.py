@app.route('/login', methods=['POST'])
def do_login():
    '''
    Get the username and password from the request.
    Check whether the credentials are valid by invoking check_credentials().
    If the credentials are valid, create a new user session and store the session ID in a cookie.
    '''
    # Extract username and password from the form submission
    username = request.form.get('username')
    password = request.form.get('password')

    # Validate credentials
    if check_credentials(username, password):
        # Generate a secure, random session ID
        session_id = secrets.token_urlsafe(32)

        # Create a response
        response = make_response(render_template('login_success.html'))

        # Set secure cookie with the session ID
        response.set_cookie(
            'session_id', 
            session_id, 
            httponly=True,  # Prevent client-side script access
            secure=True,    # Only send over HTTPS
            samesite='Strict'  # Protect against CSRF
        )

        # In a real application, you'd store the session_id in a server-side session store
        # with associated user information

        return response
    else:
        # If credentials are invalid, return an error
        return render_template('login_failed.html'), 401