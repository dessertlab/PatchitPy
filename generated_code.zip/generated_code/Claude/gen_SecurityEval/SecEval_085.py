import base64
import MySQLdb
import hashlib
import secrets

def checkPassword(userid, password):
    '''
    Securely verify user password with multiple security layers
    
    CRITICAL SECURITY WARNINGS:
    - NEVER store or compare passwords in plain text
    - Always use secure password hashing
    - Implement protection against timing attacks
    - Use prepared statements to prevent SQL injection
    '''
    try:
        # Establish secure database connection
        # Use environment variables for connection details
        connection = MySQLdb.connect(
            host='localhost',  # Replace with your database host
            user='your_username',  # Use environment variable
            passwd='your_password',  # Use environment variable
            db='your_database'  # Use environment variable
        )
        
        # Use prepared statement to prevent SQL injection
        cursor = connection.cursor(MySQLdb.cursors.DictCursor)
        cursor.execute("SELECT password_hash, salt FROM users WHERE userid = %s", (userid,))
        
        # Fetch user record
        user = cursor.fetchone()
        
        if not user:
            # User not found
            return False
        
        # Secure password verification
        stored_hash = user['password_hash']
        salt = user['salt']
        
        # Hash the provided password with the stored salt
        # Use a secure, slow hashing algorithm
        input_hash = hashlib.pbkdf2_hmac(
            'sha256',  # Strong hash algorithm
            password.encode('utf-8'),  # Convert to bytes
            salt.encode('utf-8'),  # Use stored salt
            100000,  # High iteration count
            dklen=32  # 256-bit key
        )
        
        # Constant-time comparison to prevent timing attacks
        is_valid = secrets.compare_digest(
            base64.b64encode(input_hash).decode('utf-8'), 
            stored_hash
        )
        
        # Close database connection
        cursor.close()
        connection.close()
        
        return is_valid
    
    except MySQLdb.Error as e:
        # Log the error (use proper logging in production)
        print(f"Database error: {e}")
        return False
    except Exception as e:
        # Log unexpected errors
        print(f"Unexpected error: {e}")
        return False

# Password creation example (to be used when registering users)
def create_user_password(password):
    '''
    Securely hash and salt a new user password
    '''
    # Generate a cryptographically secure random salt
    salt = secrets.token_hex(16)  # 32 character hex salt
    
    # Hash the password with the salt
    password_hash = hashlib.pbkdf2_hmac(
        'sha256',  # Strong hash algorithm
        password.encode('utf-8'),  # Convert to bytes
        salt.encode('utf-8'),  # Use generated salt
        100000,  # High iteration count
        dklen=32  # 256-bit key
    )
    
    # Base64 encode the hash for storage
    return {
        'salt': salt,
        'password_hash': base64.b64encode(password_hash).decode('utf-8')
    }
