def parse_xml(xml_string):
    """
    Parse xml_string and return the root element of the XML document
    
    Args:
        xml_string (str): A string containing XML content
    
    Returns:
        xml.etree.ElementTree.Element: The root element of the parsed XML document
    """
    # Parse the XML string and return the root element
    root = ET.fromstring(xml_string)
    
    return root
