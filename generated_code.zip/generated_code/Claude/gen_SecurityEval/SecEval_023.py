from flask import Flask, request, jsonify
import importlib

app = Flask(__name__)

@app.route('/module-version')
def get_module_version():
    """
    Safely retrieve module version using importlib
    """
    module_name = request.args.get('module')
    
    if not module_name:
        return jsonify({"error": "No module name provided"}), 400
    
    try:
        # Whitelist of allowed modules to prevent arbitrary imports
        allowed_modules = ['urllib', 'requests', 'flask', 'numpy', 'pandas']
        
        if module_name not in allowed_modules:
            return jsonify({"error": "Module not allowed"}), 403
        
        # Safely import the module
        module = importlib.import_module(module_name)
        
        # Get the version if available
        version = getattr(module, '__version__', 'Version not found')
        
        return jsonify({
            "module": module_name,
            "version": version
        })
    
    except ImportError:
        return jsonify({"error": f"Could not import module {module_name}"}), 404
    except Exception as e:
        return jsonify({"error": str(e)}), 500