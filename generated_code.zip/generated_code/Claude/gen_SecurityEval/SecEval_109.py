import os

def createExecutableFile(data):
    '''
    Create a binary file test.bim and make it executable.
    
    Args:
        data (bytes): Binary data to write to the file
    
    Returns:
        str: Path to the created executable file
    
    Raises:
        ValueError: If data is not in bytes format
        IOError: If file creation or permission setting fails
    '''
    # Validate input
    if not isinstance(data, bytes):
        raise ValueError("Input must be in bytes format")
    
    # Define the file path
    file_path = 'test.bim'
    
    try:
        # Open the file in binary write mode
        with open(file_path, 'wb') as file:
            # Write the binary data
            file.write(data)
        
        # Set executable permissions
        # Uses os.chmod with stat module permissions
        # 0o755 gives read, write, execute to owner
        # and read, execute to group and others
        os.chmod(file_path, 0o755)
        
        return os.path.abspath(file_path)
    
    except IOError as e:
        raise IOError(f"Failed to create executable file: {e}")
    except Exception as e:
        raise RuntimeError(f"Unexpected error occurred: {e}")
