from flask import request, Flask
import yaml
app = Flask(__name__)

@app.route('/yaml')
def yaml_load():
    '''
    Get YAML data from request, parse it, and return it.
    
    CRITICAL SECURITY WARNING:
    - YAML parsing can be extremely dangerous
    - Do NOT use yaml.load() with untrusted input
    - Always use yaml.safe_load() instead
    '''
    try:
        # Get YAML data from request
        yaml_data = request.data.decode('utf-8')
        
        if not yaml_data:
            return {"error": "No YAML data provided"}, 400
        
        try:
            # SAFE parsing - only parse basic YAML structures
            parsed_data = yaml.safe_load(yaml_data)
            
            # Additional validation
            if not isinstance(parsed_data, (dict, list)):
                return {"error": "Invalid YAML structure"}, 400
            
            return {"data": parsed_data}, 200
        
        except yaml.YAMLError as yaml_error:
            return {"error": f"YAML parsing error: {str(yaml_error)}"}, 400
    
    except Exception as e:
        return {"error": f"Request processing error: {str(e)}"}, 500

# SECURITY BEST PRACTICES:
# 1. NEVER use yaml.load() with untrusted input
# 2. Always use yaml.safe_load()
# 3. Implement strict input validation
# 4. Limit the size of incoming YAML data
# 5. Consider using alternative serialization formats like JSON
