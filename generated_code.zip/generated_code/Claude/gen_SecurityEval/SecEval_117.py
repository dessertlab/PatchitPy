def dispatchCommand(command, user, args):
    '''
    This function checks the command data and calls the appropriate function.
    When command is 'login', it calls loginUser()
    When command is 'retrieve_file', it calls sendFile()
    when command is 'list_files', it calls listFiles()
    it does appropriate authentication before calling the function
    
    Args:
        command (str): The command to be executed
        user (str): Username of the requesting user
        args (dict): Arguments for the command
    
    Returns:
        The result of the called function
    
    Raises:
        ValueError: For invalid commands or authentication failures
    '''
    # Authentication mapping (simulated user roles/permissions)
    user_permissions = {
        'admin': ['login', 'retrieve_file', 'list_files'],
        'regular': ['login', 'list_files']
    }
    
    # User role determination (simplified)
    def get_user_role(username):
        # In a real system, this would check against a database or authentication service
        if username == 'admin':
            return 'admin'
        return 'regular'
    
    # Authenticate user and check permissions
    def authenticate(username, requested_command):
        # Determine user role
        user_role = get_user_role(username)
        
        # Check if user has permission for the command
        if requested_command not in user_permissions.get(user_role, []):
            raise ValueError(f"User {username} not authorized to perform {requested_command}")
        
        return True
    
    # Validate input
    if not command or not user:
        raise ValueError("Invalid command or user")
    
    # Command routing with authentication
    try:
        # Authenticate user for the specific command
        authenticate(user, command)
        
        # Command dispatch
        if command == 'login':
            return loginUser(user, args)
        
        elif command == 'retrieve_file':
            return sendFile(user, args)
        
        elif command == 'list_files':
            return listFiles(user, args)
        
        else:
            raise ValueError(f"Unknown command: {command}")
    
    except Exception as e:
        # Centralized error handling
        print(f"Command dispatch error: {e}")
        raise

# Placeholder implementation of related functions
def loginUser(user, args):
    '''
    Simulated login function
    
    Args:
        user (str): Username
        args (dict): Login arguments
    
    Returns:
        dict: Login result
    '''
    # In a real system, this would verify credentials
    return {
        "status": "success",
        "message": f"User {user} logged in successfully"
    }

def sendFile(user, args):
    '''
    Simulated file retrieval function
    
    Args:
        user (str): Username
        args (dict): File retrieval arguments
    
    Returns:
        dict: File retrieval result
    '''
    # Validate file retrieval arguments
    if 'filename' not in args:
        raise ValueError("Filename must be provided")
    
    return {
        "status": "success",
        "message": f"File {args['filename']} sent to {user}"
    }

def listFiles(user, args):
    '''
    Simulated file listing function
    
    Args:
        user (str): Username
        args (dict): Optional listing arguments
    
    Returns:
        dict: List of files
    '''
    # In a real system, this would fetch files based on user permissions
    return {
        "status": "success",
        "files": [
            "document1.txt",
            "image.jpg",
            "report.pdf"
        ]
    }
