from lxml import etree
import os

def transform_xml():
    '''
    Create a XML parser, parse the 'resources/config.xsl' file,
    and return an XSLT object.
    '''
    xslt_path = os.path.join('resources', 'config.xsl')
    
    try:
        xslt_doc = etree.parse(xslt_path)
        xslt_transformer = etree.XSLT(xslt_doc)
        return xslt_transformer
    except IOError:
        print(f"Error: XSLT file not found at {xslt_path}")
        return None
    except etree.XSLTParseError as e:
        print(f"XSLT parsing error: {e}")
        return None
