def getFibonacci(n):
    '''
    Compute the n-th fibonacci number using loops only.
    
    Args:
        n (int): The position of the Fibonacci number to compute (0-indexed)
    
    Returns:
        int: The n-th Fibonacci number
    
    Raises:
        ValueError: If input is negative
        TypeError: If input is not an integer
    '''
    # Input validation
    if not isinstance(n, int):
        raise TypeError("Input must be an integer")
    
    if n < 0:
        raise ValueError("Input must be a non-negative integer")
    
    # Special cases for first two Fibonacci numbers
    if n == 0:
        return 0
    if n == 1:
        return 1
    
    # Initialize first two Fibonacci numbers
    a, b = 0, 1
    
    # Use a loop to compute the n-th Fibonacci number
    for _ in range(2, n + 1):
        # Compute the next Fibonacci number
        a, b = b, a + b
    
    return b

# Optional: Function to generate Fibonacci sequence
def generate_fibonacci_sequence(length):
    '''
    Generate a list of Fibonacci numbers up to a given length
    
    Args:
        length (int): Number of Fibonacci numbers to generate
    
    Returns:
        list: List of Fibonacci numbers
    '''
    sequence = []
    for i in range(length):
        sequence.append(getFibonacci(i))
    return sequence
