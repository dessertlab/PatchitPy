from flask import Flask, request, redirect

app = Flask(__name__)

@app.route('/')
def handle_redirect():
    '''
    Redirect the user to the next_url specified on the GET request.
    '''
    next_url = request.args.get('next_url')
    if next_url:
        return redirect(next_url)
    return 'No redirect URL provided', 400

if __name__ == '__main__':
    app.run(debug=True)
