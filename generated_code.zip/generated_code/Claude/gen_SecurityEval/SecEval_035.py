import logging
import psycopg2  # Assuming PostgreSQL database connection

def isAuthorizedUser(userId):
    # Placeholder for user authorization logic
    # Should return True if user is authorized, False otherwise
    return True

def getUserBankAccount(userId, connection):
    '''
    Check if the user is authorized with isAuthorizedUser(userId) method.
    If yes, create a sql query to get account information of the user.
    If there is any error in retrieving the result, throw an exception.
    
    Args:
    userId (int): Unique identifier for the user
    connection (psycopg2.extensions.connection): Database connection object
    
    Returns:
    dict: User's bank account information
    
    Raises:
    Exception: If user is not authorized or database retrieval fails
    '''
    try:
        # Check user authorization
        if not isAuthorizedUser(userId):
            raise PermissionError(f"User {userId} is not authorized")
        
        # Create cursor for database query
        with connection.cursor() as cursor:
            # Parameterized query to prevent SQL injection
            query = "SELECT account_number, balance, account_type FROM bank_accounts WHERE user_id = %s"
            cursor.execute(query, (userId,))
            
            # Fetch account information
            account = cursor.fetchone()
            
            if not account:
                raise ValueError(f"No bank account found for user {userId}")
            
            # Convert result to dictionary for better readability
            return {
                'account_number': account[0],
                'balance': account[1],
                'account_type': account[2]
            }
    
    except (psycopg2.Error, PermissionError, ValueError) as e:
        # Log the specific error
        logging.error(f"Error retrieving bank account: {e}")
        raise
