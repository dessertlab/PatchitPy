import os
import requests
import psycopg2
from dotenv import load_dotenv

def unsubscribe_email(email):
    """
    Unsubscribe process for an email address.
    
    Args:
        email (str): Email address to unsubscribe
    
    Returns:
        int: 1 if successfully unsubscribed, 0 otherwise
    """
    try:
        # Establish database connection
        conn = psycopg2.connect(
            host=os.getenv('DB_HOST'),
            database=os.getenv('DB_NAME'),
            user=os.getenv('DB_USER'),
            password=os.getenv('DB_PASSWORD')
        )
        
        # Create a cursor object
        with conn.cursor() as cursor:
            # Check if email exists in the database
            check_query = """
            SELECT EXISTS(
                SELECT 1 
                FROM subscribers 
                WHERE email = %s
            )
            """
            cursor.execute(check_query, (email,))
            email_exists = cursor.fetchone()[0]
            
            # If email doesn't exist, return 0
            if not email_exists:
                return 0
            
            # Prepare to call PHP unsubscribe script
            try:
                # Replace with your actual PHP script URL
                php_unsubscribe_url = 'https://your-domain.com/unsubscribe.php'
                
                # Send request to PHP script
                response = requests.post(php_unsubscribe_url, data={'email': email})
                
                # Check PHP script response
                # Assuming the PHP script returns 0 or 1 as a string
                if response.text.strip() == '1':
                    # Successfully unsubscribed via PHP script
                    return 1
                else:
                    # PHP script failed to unsubscribe
                    return 0
            
            except requests.RequestException as request_error:
                print(f"Error calling PHP unsubscribe script: {request_error}")
                return 0
    
    except (Exception, psycopg2.Error) as error:
        print(f"Error during unsubscribe process: {error}")
        return 0
    
    finally:
        # Close the database connection
        if 'conn' in locals():
            conn.close()

# Example usage
def main():
    # Load environment variables
    load_dotenv()
    
    # Test email
    test_email = 'user@example.com'
    
    # Attempt to unsubscribe
    result = unsubscribe_email(test_email)
    
    # Print result
    print(f"Unsubscribe result for {test_email}: {result}")
    # 0 = Failed (not in database or PHP script failed)
    # 1 = Successfully unsubscribed

if __name__ == '__main__':
    main()

# Corresponding PHP Script (unsubscribe.php) Example
"""
<?php
// Database connection
$servername = "localhost";
$username = "your_username";
$password = "your_password";
$dbname = "your_database";

// Create connection
$conn = new mysqli($servername, $username, $password, $dbname);

// Check connection
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

// Get email from POST request
$email = $_POST['email'];

// Remove from mailing list table
$sql = "DELETE FROM mailing_list WHERE email = ?";
$stmt = $conn->prepare($sql);
$stmt->bind_param("s", $email);

// Execute and check result
if ($stmt->execute()) {
    // Successful deletion
    echo "1";
} else {
    // Failed deletion
    echo "0";
}

$stmt->close();
$conn->close();
?>
"""

# Database Setup SQL (for reference)
"""
CREATE TABLE subscribers (
    id SERIAL PRIMARY KEY,
    email VARCHAR(255) UNIQUE NOT NULL,
    subscribed_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);
"""
