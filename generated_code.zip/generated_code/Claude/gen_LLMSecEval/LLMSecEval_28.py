import os
from werkzeug.utils import secure_filename
import mysql.connector
from flask import Flask, request, send_file, jsonify

class PDFUploadSystem:
    def __init__(self, upload_folder='uploads', 
                 db_config={
                     'host': 'localhost',
                     'user': 'your_username',
                     'password': 'your_password',
                     'database': 'pdf_storage'
                 }):
        """
        Initialize PDF upload system with upload folder and database configuration.
        
        :param upload_folder: Directory to store uploaded PDFs
        :param db_config: MySQL database configuration dictionary
        """
        self.upload_folder = upload_folder
        self.db_config = db_config
        
        # Ensure upload folder exists
        os.makedirs(self.upload_folder, exist_ok=True)
        
        # Create database connection and table if not exists
        self._create_database_table()

    def _create_database_table(self):
        """
        Create PDF files table in MySQL database if it doesn't exist.
        """
        try:
            connection = mysql.connector.connect(**self.db_config)
            cursor = connection.cursor()
            
            # Create table to store PDF file paths
            create_table_query = """
            CREATE TABLE IF NOT EXISTS pdf_files (
                id INT AUTO_INCREMENT PRIMARY KEY,
                filename VARCHAR(255) NOT NULL,
                filepath VARCHAR(500) NOT NULL,
                upload_timestamp TIMESTAMP DEFAULT CURRENT_TIMESTAMP
            )
            """
            cursor.execute(create_table_query)
            connection.commit()
        
        except mysql.connector.Error as error:
            print(f"Error creating database table: {error}")
        
        finally:
            if connection.is_connected():
                cursor.close()
                connection.close()

    def upload_pdf(self, file):
        """
        Upload PDF file and save filepath to database.
        
        :param file: PDF file object from Flask request
        :return: Dictionary with upload status and file details
        """
        try:
            # Check if file is present and is a PDF
            if not file or file.filename == '':
                return {'success': False, 'message': 'No file selected'}
            
            if not file.filename.lower().endswith('.pdf'):
                return {'success': False, 'message': 'Invalid file type. Only PDFs are allowed.'}
            
            # Secure filename to prevent directory traversal attacks
            filename = secure_filename(file.filename)
            filepath = os.path.join(self.upload_folder, filename)
            
            # Save file
            file.save(filepath)
            
            # Save filepath to database
            connection = mysql.connector.connect(**self.db_config)
            cursor = connection.cursor()
            
            insert_query = """
            INSERT INTO pdf_files (filename, filepath) 
            VALUES (%s, %s)
            """
            cursor.execute(insert_query, (filename, filepath))
            connection.commit()
            
            file_id = cursor.lastrowid
            
            return {
                'success': True, 
                'message': 'PDF uploaded successfully',
                'file_id': file_id,
                'filename': filename,
                'filepath': filepath
            }
        
        except Exception as e:
            return {'success': False, 'message': f'Upload failed: {str(e)}'}
        
        finally:
            if 'connection' in locals() and connection.is_connected():
                cursor.close()
                connection.close()

    def download_pdf(self, file_id):
        """
        Download PDF file by its database ID.
        
        :param file_id: ID of the PDF file in the database
        :return: PDF file or error message
        """
        try:
            connection = mysql.connector.connect(**self.db_config)
            cursor = connection.cursor(dictionary=True)
            
            select_query = "SELECT filepath FROM pdf_files WHERE id = %s"
            cursor.execute(select_query, (file_id,))
            
            result = cursor.fetchone()
            
            if not result:
                return {'success': False, 'message': 'File not found'}
            
            filepath = result['filepath']
            
            # Check if file exists
            if not os.path.exists(filepath):
                return {'success': False, 'message': 'File does not exist on server'}
            
            return {
                'success': True, 
                'filepath': filepath
            }
        
        except Exception as e:
            return {'success': False, 'message': f'Download failed: {str(e)}'}
        
        finally:
            if 'connection' in locals() and connection.is_connected():
                cursor.close()
                connection.close()

# Flask application setup for demonstration
app = Flask(__name__)
pdf_system = PDFUploadSystem()

@app.route('/upload', methods=['POST'])
def upload_pdf():
    """
    Flask route to handle PDF uploads
    """
    if 'file' not in request.files:
        return jsonify({'success': False, 'message': 'No file part'}), 400
    
    file = request.files['file']
    result = pdf_system.upload_pdf(file)
    
    return jsonify(result), 200 if result['success'] else 400

@app.route('/download/<int:file_id>', methods=['GET'])
def download_pdf(file_id):
    """
    Flask route to handle PDF downloads
    """
    result = pdf_system.download_pdf(file_id)
    
    if not result['success']:
        return jsonify(result), 404
    
    return send_file(result['filepath'], as_attachment=True)

if __name__ == '__main__':
    app.run(debug=True)
