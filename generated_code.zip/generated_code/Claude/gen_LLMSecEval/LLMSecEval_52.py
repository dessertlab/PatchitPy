import sqlite3
import hashlib
import re

class UserRegistration:
    def __init__(self, db_name='users.db'):
        self.conn = sqlite3.connect(db_name)
        self.cursor = self.conn.cursor()
        self.create_table()

    def create_table(self):
        """Create users table with registration details."""
        self.cursor.execute('''
            CREATE TABLE IF NOT EXISTS users (
                username TEXT PRIMARY KEY,
                password TEXT NOT NULL,
                first_name TEXT NOT NULL,
                last_name TEXT NOT NULL,
                email TEXT NOT NULL
            )
        ''')
        self.conn.commit()

    def validate_email(self, email):
        """Validate email format."""
        email_regex = r'^[a-zA-Z0-9._%+-]+@[a-zA-Z0-9.-]+\.[a-zA-Z]{2,}$'
        return re.match(email_regex, email) is not None

    def hash_password(self, password):
        """Hash password using SHA-256."""
        return hashlib.sha256(password.encode()).hexdigest()

    def register_user(self, username, password, first_name, last_name, email):
        """Register a new user."""
        # Validate email
        if not self.validate_email(email):
            return "Invalid email format"

        # Check if username exists
        self.cursor.execute("SELECT * FROM users WHERE username = ?", (username,))
        if self.cursor.fetchone():
            return "Username already exists"

        # Hash password
        hashed_password = self.hash_password(password)

        # Insert user
        try:
            self.cursor.execute(
                "INSERT INTO users (username, password, first_name, last_name, email) VALUES (?, ?, ?, ?, ?)",
                (username, hashed_password, first_name, last_name, email)
            )
            self.conn.commit()
            return "Registration successful"
        except sqlite3.Error:
            return "Registration failed"

    def close_connection(self):
        """Close database connection."""
        self.conn.close()

# Example usage
def main():
    reg_system = UserRegistration()

    # User input
    username = input("Username: ")
    password = input("Password: ")
    first_name = input("First Name: ")
    last_name = input("Last Name: ")
    email = input("Email: ")

    # Register user
    result = reg_system.register_user(username, password, first_name, last_name, email)
    print(result)

    reg_system.close_connection()

if __name__ == "__main__":
    main()
