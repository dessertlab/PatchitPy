from flask import Flask, request
import yaml

app = Flask(__name__)

# Product price dictionary (simulating a price database)
PRODUCT_PRICES = {
    'PROD001': 10.50,   # Product 1 price
    'PROD002': 15.75,   # Product 2 price
    'PROD003': 5.25,    # Product 3 price
}

def get_price_for_product_code(product_code):
    """
    Retrieve the price for a given product code.
    
    Args:
        product_code (str): The unique identifier for a product
    
    Returns:
        float: The price of the product, or None if not found
    """
    return PRODUCT_PRICES.get(product_code)

@app.route('/calculate_price', methods=['POST'])
def calculate_price():
    """
    Calculate price from a YAML payload.
    
    Expected YAML payload:
    product_code: str
    quantity: int
    
    Returns:
    YAML payload with total price
    """
    try:
        # Get YAML payload from request
        yaml_payload = request.get_data(as_text=True)
        
        # Parse YAML payload
        try:
            payload_dict = yaml.safe_load(yaml_payload)
        except yaml.YAMLError:
            return "Error: Invalid YAML payload", 400
        
        # Extract product code and quantity
        product_code = payload_dict.get('product_code')
        quantity = payload_dict.get('quantity')
        
        # Validate inputs
        if not product_code:
            return "Error: Product code is required", 400
        
        if not quantity or not isinstance(quantity, int) or quantity <= 0:
            return "Error: Invalid quantity", 400
        
        # Get product price
        unit_price = get_price_for_product_code(product_code)
        
        # Check if product exists
        if unit_price is None:
            return f"Error: Product {product_code} not found", 404
        
        # Calculate total price
        total_price = unit_price * quantity
        
        # Prepare response YAML
        response_dict = {
            'product_code': product_code,
            'quantity': quantity,
            'unit_price': unit_price,
            'total_price': round(total_price, 2)
        }
        
        # Convert response to YAML and return
        return yaml.safe_dump(response_dict), 200, {'Content-Type': 'application/x-yaml'}
    
    except Exception as e:
        return f"Error: Unexpected error - {str(e)}", 500

if __name__ == '__main__':
    app.run(host='0.0.0.0', port=5000, debug=True)

# Example usage:
"""
Curl command to test the microservice:
curl -X POST \
     -H "Content-Type: application/x-yaml" \
     -d "product_code: PROD001
quantity: 5" \
     http://localhost:5000/calculate_price
"""
