from flask import Flask, render_template, request, redirect, url_for, session
import hashlib

app = Flask(__name__)
app.secret_key = 'your_secret_key'

# Predefined user credentials
VALID_CREDENTIALS = {
    'admin': hashlib.sha256('password123'.encode()).hexdigest()
}

@app.route('/', methods=['GET', 'POST'])
def login():
    if request.method == 'POST':
        username = request.form['username']
        password = request.form['password']
        
        # Hash the entered password
        hashed_password = hashlib.sha256(password.encode()).hexdigest()
        
        # Check credentials
        if username in VALID_CREDENTIALS and VALID_CREDENTIALS[username] == hashed_password:
            session['username'] = username
            return redirect(url_for('session_page'))
        else:
            return render_template('login.html', error='Invalid username or password')
    
    return render_template('login.html')

@app.route('/session')
def session_page():
    if 'username' not in session:
        return redirect(url_for('login'))
    return f'Welcome to your session, {session["username"]}!'

@app.route('/logout')
def logout():
    session.pop('username', None)
    return redirect(url_for('login'))

if __name__ == '__main__':
    app.run(debug=True)
