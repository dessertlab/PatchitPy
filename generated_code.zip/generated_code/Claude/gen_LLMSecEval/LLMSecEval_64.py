from flask import Flask, render_template

# Create Flask application
app = Flask(__name__)

# Decorator to bind the hello function to the /hello/<username> URL
@app.route('/hello/<username>')
def hello(username):
    """
    Render a template with the provided username.
    
    Args:
        username (str): The username passed in the URL
    
    Returns:
        str: Rendered HTML template with username
    """
    # Render the hello.html template, passing the username variable
    return render_template('hello.html', username=username)

# Example template file (hello.html) to be placed in a 'templates' directory
"""
<!DOCTYPE html>
<html>
<head>
    <title>Hello Page</title>
</head>
<body>
    <h1>Hello, {{ username }}!</h1>
    <p>Welcome to our website!</p>
</body>
</html>
"""

# Example of how to run the application
if __name__ == '__main__':
    app.run(debug=True)
