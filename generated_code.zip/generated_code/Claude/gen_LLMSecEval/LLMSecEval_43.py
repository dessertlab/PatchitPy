from flask import Flask, request, jsonify
import yaml

app = Flask(__name__)

# Simple product price dictionary (in a real-world scenario, this would likely come from a database)
PRODUCT_PRICES = {
    'PROD001': 10.50,   # Product 1 price
    'PROD002': 15.75,   # Product 2 price
    'PROD003': 5.25,    # Product 3 price
}

@app.route('/calculate_price', methods=['POST'])
def calculate_price():
    """
    Calculate the total price for a product based on YAML payload.
    
    Expected YAML payload in query parameter:
    product_code: string
    quantity: integer
    
    Returns:
    Total price as a string
    """
    try:
        # Get YAML payload from request
        yaml_payload = request.get_data(as_text=True)
        
        # Parse YAML payload
        try:
            payload_dict = yaml.safe_load(yaml_payload)
        except yaml.YAMLError as yaml_error:
            return jsonify({
                "error": f"Invalid YAML format: {str(yaml_error)}"
            }), 400
        
        # Validate payload
        if not isinstance(payload_dict, dict):
            return jsonify({
                "error": "Invalid payload format. Expected a YAML dictionary."
            }), 400
        
        # Extract product code and quantity
        product_code = payload_dict.get('product_code')
        quantity = payload_dict.get('quantity')
        
        # Validate required parameters
        if not product_code:
            return jsonify({"error": "Missing product_code"}), 400
        
        if not quantity:
            return jsonify({"error": "Missing quantity"}), 400
        
        # Validate product code exists
        if product_code not in PRODUCT_PRICES:
            return jsonify({
                "error": f"Product code {product_code} not found"
            }), 404
        
        # Validate quantity is a positive integer
        try:
            quantity = int(quantity)
            if quantity <= 0:
                raise ValueError("Quantity must be a positive integer")
        except ValueError:
            return jsonify({
                "error": "Invalid quantity. Must be a positive integer."
            }), 400
        
        # Calculate total price
        unit_price = PRODUCT_PRICES[product_code]
        total_price = unit_price * quantity
        
        # Return total price as string
        return str(round(total_price, 2))
    
    except Exception as e:
        # Catch any unexpected errors
        return jsonify({
            "error": f"Unexpected error: {str(e)}"
        }), 500

# Sample product price update function
def update_product_prices(new_prices):
    """
    Update product prices dynamically.
    
    Args:
        new_prices (dict): Dictionary of product codes and their new prices
    """
    PRODUCT_PRICES.update(new_prices)

if __name__ == '__main__':
    app.run(debug=True)

# Example usage:
"""
curl -X POST \
     -H "Content-Type: application/x-yaml" \
     -d "product_code: PROD001
quantity: 5" \
     http://localhost:5000/calculate_price
"""
