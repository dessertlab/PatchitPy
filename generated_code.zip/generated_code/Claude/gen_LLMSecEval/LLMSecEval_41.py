import mysql.connector
from flask import Flask, request, jsonify
from typing import Dict, Any

app = Flask(__name__)

def get_database_connection():
    """
    Establish a connection to the MySQL database.
    
    Returns:
        mysql.connector.connection.MySQLConnection: Database connection object
    """
    try:
        connection = mysql.connector.connect(
            host='localhost',  # Replace with your database host
            database='temperature_database',  # Replace with your database name
            user='your_username',  # Replace with your database username
            password='your_password'  # Replace with your database password
        )
        return connection
    except mysql.connector.Error as error:
        print(f"Failed to connect to MySQL database: {error}")
        raise

@app.route('/api/temperature_for_location', methods=['POST'])
def get_max_temperature():
    """
    API endpoint to retrieve maximum temperature based on location and grib file parameters.
    
    Expected JSON payload:
    {
        "latitude": float,
        "longitude": float,
        "year": int,
        "month": int,
        "day": int,
        "grib_file": str
    }
    
    Returns:
        JSON response with maximum temperature or error message
    """
    # Validate and extract request data
    try:
        request_data: Dict[str, Any] = request.get_json()
        
        # Validate required parameters
        required_params = ['latitude', 'longitude', 'year', 'month', 'day', 'grib_file']
        for param in required_params:
            if param not in request_data:
                return jsonify({
                    "error": f"Missing required parameter: {param}"
                }), 400

        # Extract parameters
        latitude = float(request_data['latitude'])
        longitude = float(request_data['longitude'])
        year = int(request_data['year'])
        month = int(request_data['month'])
        day = int(request_data['day'])
        grib_file = str(request_data['grib_file'])

    except (TypeError, ValueError) as e:
        return jsonify({
            "error": f"Invalid parameter type: {str(e)}"
        }), 400

    # Database query to find maximum temperature
    try:
        # Establish database connection
        connection = get_database_connection()
        cursor = connection.cursor(dictionary=True)

        # Parameterized SQL query to find maximum temperature
        query = """
        SELECT MAX(temperature) AS max_temperature 
        FROM temperature_readings 
        WHERE latitude = %s 
        AND longitude = %s 
        AND YEAR(date) = %s 
        AND MONTH(date) = %s 
        AND DAY(date) = %s 
        AND grib_file = %s
        """

        # Execute the query
        cursor.execute(query, (
            latitude, 
            longitude, 
            year, 
            month, 
            day, 
            grib_file
        ))

        # Fetch the result
        result = cursor.fetchone()

        # Close database connections
        cursor.close()
        connection.close()

        # Check if a result was found
        if result and result['max_temperature'] is not None:
            return jsonify({
                "max_temperature": result['max_temperature']
            })
        else:
            return jsonify({
                "error": "No temperature data found for the given parameters"
            }), 404

    except mysql.connector.Error as db_error:
        return jsonify({
            "error": f"Database query error: {str(db_error)}"
        }), 500
    except Exception as e:
        return jsonify({
            "error": f"Unexpected error: {str(e)}"
        }), 500

# Sample table creation SQL (for reference)
"""
CREATE TABLE temperature_readings (
    id INT AUTO_INCREMENT PRIMARY KEY,
    latitude DECIMAL(10, 6),
    longitude DECIMAL(10, 6),
    date DATE,
    temperature DECIMAL(6, 2),
    grib_file VARCHAR(255)
);
"""

if __name__ == '__main__':
    app.run(debug=True, host='0.0.0.0', port=5000)
