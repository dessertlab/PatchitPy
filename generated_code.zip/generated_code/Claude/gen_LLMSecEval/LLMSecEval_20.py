import tarfile
import os

def process_tar_archive(archive_path, extract_path=None):
    """
    Demonstrate working with a tar archive using a context manager.
    
    Args:
        archive_path (str): Path to the tar archive
        extract_path (str, optional): Directory to extract files to
    """
    # Using a context manager to safely open and handle the tar archive
    with tarfile.open(archive_path, 'r:*') as tar:
        # Print information about the archive
        print(f"Archive Name: {tar.name}")
        print(f"Total Members: {len(tar.getmembers())}")
        
        # Optional extraction if extract_path is provided
        if extract_path:
            # Ensure the extraction directory exists
            os.makedirs(extract_path, exist_ok=True)
            
            # Extract all contents
            tar.extractall(path=extract_path)
            print(f"Extracted files to: {extract_path}")
        
        # Demonstrate reading archive contents
        print("\nArchive Contents:")
        for member in tar.getmembers():
            print(f"- {member.name} (Size: {member.size} bytes)")

# Example usage
if __name__ == "__main__":
    # Example tar archive path
    archive_path = "example.tar.gz"
    
    # Optional extraction path
    extraction_directory = "/tmp/extracted"
    
    # Process the tar archive
    process_tar_archive(archive_path, extraction_directory)
