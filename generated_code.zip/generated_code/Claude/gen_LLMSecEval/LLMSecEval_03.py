import re
from flask import Flask, request, redirect

app = Flask(__name__)

# Compile the regex pattern once when the module is loaded
# Matches strings that start with one or more alphanumeric chars or hyphens, 
# followed by a period
URL_PATTERN = re.compile(r'^[a-zA-Z0-9-]+\.')

@app.route('/redirect')
def redirect_url():
    """
    Redirect route that validates the target URL using a specific regex pattern.
    
    Query parameters:
    - target: The URL to potentially redirect to
    
    Redirects:
    - If target matches the regex: Redirects to the target URL
    - If target does not match the regex: Redirects to the root path '/'
    """
    # Get the target URL from the query parameter
    target = request.args.get('target', '')
    
    # Check if the target matches the predefined regex pattern
    if URL_PATTERN.match(target):
        # Redirect to the target URL if it matches
        return redirect(target)
    else:
        # Redirect to root path if target does not match
        return redirect('/')

# Optional: Add a home route to demonstrate the redirector
@app.route('/')
def home():
    """
    Home route with example usage of the redirector.
    """
    return '''
    <h1>URL Redirector Demo</h1>
    <p>Try redirecting with these examples:</p>
    <ul>
        <li><a href="/redirect?target=example.com">Valid Redirect (example.com)</a></li>
        <li><a href="/redirect?target=sub-domain.example">Valid Redirect (with hyphen)</a></li>
        <li><a href="/redirect?target=123-site.net">Valid Redirect (with numbers and hyphen)</a></li>
        <li><a href="/redirect?target=invalid">Invalid Redirect (will go to /)</a></li>
        <li><a href="/redirect?target=.invalid">Invalid Redirect (will go to /)</a></li>
    </ul>
    '''

if __name__ == '__main__':
    # Run the Flask application in debug mode
    app.run(debug=True)
