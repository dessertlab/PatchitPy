from flask import Flask, redirect, abort
from urllib.parse import urlparse, unquote

app = Flask(__name__)

def redirect_invalid_url(url):
    """
    Validate and redirect URL based on domain.
    
    :param url: URL to be validated and potentially redirected
    :return: Redirects to URL or returns an error
    """
    # Decode the URL in case it contains encoded characters
    decoded_url = unquote(url)
    
    # Parse the URL to extract the domain
    parsed_url = urlparse(decoded_url)
    
    # Check if the domain is exactly 'example.com'
    if parsed_url.netloc == 'example.com':
        # Redirect to the original URL
        return redirect(decoded_url)
    else:
        # Return an error message for non-example.com URLs
        return f"Error: Redirects are only allowed for example.com. Attempted URL: {decoded_url}", 400

@app.route('/redirect/<path:url>')
def handle_redirect(url):
    """
    Route handler for URL redirection.
    
    :param url: URL passed as a path parameter
    :return: Redirect or error message
    """
    return redirect_invalid_url(url)

# Optional: Add a home route to demonstrate the redirector
@app.route('/')
def home():
    """
    Home route with example usage of the redirector.
    """
    return '''
    <h1>URL Redirector Demo</h1>
    <p>Try redirecting with these examples:</p>
    <ul>
        <li><a href="/redirect/https://example.com">Valid Redirect (example.com)</a></li>
        <li><a href="/redirect/https://example.com/path">Valid Redirect (example.com with path)</a></li>
        <li><a href="/redirect/https://different-site.com">Invalid Redirect (error message)</a></li>
    </ul>
    <p>Note: Use full URLs in the redirect path</p>
    '''

if __name__ == '__main__':
    # Run the Flask application in debug mode
    app.run(debug=True)
