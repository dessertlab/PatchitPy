import os
import psycopg2
from flask import Flask, request, render_template, jsonify
from dotenv import load_dotenv
import yfinance as yf

# Load environment variables
load_dotenv()

# Create Flask application
app = Flask(__name__)

def buy_function(stock_name):
    """
    Retrieve current stock information.
    
    Args:
        stock_name (str): The stock symbol to retrieve information for
    
    Returns:
        dict: Stock information or None if retrieval fails
    """
    try:
        # Fetch stock data using yfinance
        stock = yf.Ticker(stock_name)
        
        # Get current stock price
        current_price = stock.history(period="1d")['Close'][-1]
        
        # Get additional stock information
        stock_info = {
            'symbol': stock_name,
            'current_price': current_price,
            'company_name': stock.info.get('longName', 'N/A'),
            'market_cap': stock.info.get('marketCap', 'N/A')
        }
        
        return stock_info
    
    except Exception as e:
        print(f"Error retrieving stock information for {stock_name}: {e}")
        return None

def buy_stock(user_id, stock_name, quantity):
    """
    Process stock purchase and insert transaction into database.
    
    Args:
        user_id (int): ID of the user making the purchase
        stock_name (str): Stock symbol
        quantity (int): Number of stocks to purchase
    
    Returns:
        dict: Purchase result
    """
    try:
        # First, get stock information
        stock_info = buy_function(stock_name)
        
        if not stock_info:
            return {
                'status': 'error',
                'message': 'Unable to retrieve stock information'
            }
        
        # Calculate total purchase cost
        total_cost = stock_info['current_price'] * quantity
        
        # Establish database connection
        conn = psycopg2.connect(
            host=os.getenv('DB_HOST'),
            database=os.getenv('DB_NAME'),
            user=os.getenv('DB_USER'),
            password=os.getenv('DB_PASSWORD')
        )
        
        # Create a cursor object
        with conn.cursor() as cursor:
            # Insert stock purchase transaction
            insert_query = """
            INSERT INTO stock_transactions (
                user_id, 
                stock_symbol, 
                quantity, 
                price_per_share, 
                total_cost, 
                transaction_type
            ) VALUES (%s, %s, %s, %s, %s, 'BUY')
            """
            
            cursor.execute(insert_query, (
                user_id, 
                stock_name, 
                quantity, 
                stock_info['current_price'], 
                total_cost
            ))
            
            # Commit the transaction
            conn.commit()
        
        return {
            'status': 'success',
            'message': 'Stock purchase successful',
            'stock_info': stock_info,
            'quantity': quantity,
            'total_cost': total_cost
        }
    
    except (Exception, psycopg2.Error) as error:
        print(f"Error processing stock purchase: {error}")
        return {
            'status': 'error',
            'message': 'Failed to process stock purchase'
        }
    
    finally:
        # Close the database connection
        if 'conn' in locals():
            conn.close()

@app.route('/buy_stock', methods=['GET', 'POST'])
def stock_purchase_route():
    """
    Route to handle stock purchase requests.
    
    Returns:
        JSON response with purchase result
    """
    if request.method == 'POST':
        # Get form data
        user_id = request.form.get('user_id')
        stock_name = request.form.get('stock_name')
        quantity = request.form.get('quantity')
        
        # Validate inputs
        if not all([user_id, stock_name, quantity]):
            return jsonify({
                'status': 'error',
                'message': 'Missing required purchase information'
            }), 400
        
        try:
            # Convert quantity to integer
            quantity = int(quantity)
        except ValueError:
            return jsonify({
                'status': 'error',
                'message': 'Invalid quantity'
            }), 400
        
        # Process stock purchase
        result = buy_stock(user_id, stock_name, quantity)
        
        # Return appropriate response
        if result['status'] == 'success':
            return jsonify(result), 200
        else:
            return jsonify(result), 400
    
    # GET request - render purchase form
    return render_template('buy_stock.html')

# Sample HTML Template (buy_stock.html)
"""
<!DOCTYPE html>
<html>
<head>
    <title>Buy Stock</title>
</head>
<body>
    <h1>Buy Stock</h1>
    <form action="/buy_stock" method="POST">
        <input type="hidden" name="user_id" value="123">
        <label for="stock_name">Stock Symbol:</label>
        <input type="text" id="stock_name" name="stock_name" required>
        
        <label for="quantity">Quantity:</label>
        <input type="number" id="quantity" name="quantity" min="1" required>
        
        <button type="submit">Buy Stock</button>
    </form>
</body>
</html>
"""

# Database Setup SQL (for reference)
"""
CREATE TABLE stock_transactions (
    id SERIAL PRIMARY KEY,
    user_id INTEGER NOT NULL,
    stock_symbol VARCHAR(10) NOT NULL,
    quantity INTEGER NOT NULL,
    price_per_share DECIMAL(10,2) NOT NULL,
    total_cost DECIMAL(10,2) NOT NULL,
    transaction_type VARCHAR(10) NOT NULL,
    transaction_date TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);
"""

if __name__ == '__main__':
    app.run(debug=True)
