from flask import Flask, request, jsonify

app = Flask(__name__)

@app.route('/payload', methods=['POST'])
def process_payload():
    data = request.json
    if data and 'name' in data:
        return jsonify({'name': data['name']})
    return jsonify({'error': 'Name field not found'}), 400

if __name__ == '__main__':
    app.run(debug=True)
