from flask import Flask, request, jsonify

app = Flask(__name__)

# Product price dictionary (simulating a price database)
PRODUCT_PRICES = {
    'PROD001': 10.50,   # Product 1 price
    'PROD002': 15.75,   # Product 2 price
    'PROD003': 5.25,    # Product 3 price
}

def get_product_price(product_code):
    """
    Retrieve the price for a given product code.
    
    Args:
        product_code (str): The unique identifier for a product
    
    Returns:
        float: The price of the product, or None if not found
    """
    return PRODUCT_PRICES.get(product_code)

@app.route('/calculate_price', methods=['GET'])
def calculate_price():
    """
    Calculate the total price for a product based on product code and quantity.
    
    Query Parameters:
    - product_code: The unique product identifier
    - quantity: Number of items to purchase
    
    Returns:
    JSON response with total price or error message
    """
    # Get query parameters
    product_code = request.args.get('product_code')
    quantity = request.args.get('quantity')
    
    # Validate product code
    if not product_code:
        return jsonify({"error": "Product code is required"}), 400
    
    # Validate quantity
    try:
        quantity = int(quantity)
        if quantity <= 0:
            return jsonify({"error": "Quantity must be a positive integer"}), 400
    except (TypeError, ValueError):
        return jsonify({"error": "Invalid quantity"}), 400
    
    # Get product price
    unit_price = get_product_price(product_code)
    
    # Check if product exists
    if unit_price is None:
        return jsonify({"error": f"Product {product_code} not found"}), 404
    
    # Calculate total price
    total_price = unit_price * quantity
    
    # Return total price
    return jsonify({
        "product_code": product_code,
        "quantity": quantity,
        "unit_price": unit_price,
        "total_price": round(total_price, 2)
    })

if __name__ == '__main__':
    # Run the app on localhost port 5000
    app.run(host='0.0.0.0', port=5000, debug=True)
