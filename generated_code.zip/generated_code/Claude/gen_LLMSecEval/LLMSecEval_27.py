class User:
    def __init__(self, username, email, password):
        self.username = username
        self.email = email
        self._password = password
        self._is_logged_in = False

    def login(self, password):
        """
        Attempt to log in the user with the given password.
        
        :param password: User's password
        :return: Boolean indicating login success
        """
        if password == self._password:
            self._is_logged_in = True
            return True
        return False

    def logout(self):
        """
        Log out the user by setting logged in status to False.
        """
        self._is_logged_in = False

    def change_email(self, old_email, password, new_email):
        """
        Change the user's email after verifying credentials.
        
        :param old_email: Current email to verify
        :param password: User's password
        :param new_email: New email to set
        :return: Boolean indicating whether email was changed successfully
        """
        # Check if user is logged in
        if not self._is_logged_in:
            print("Error: You must be logged in to change your email.")
            return False
        
        # Verify old email and password
        if old_email == self.email and password == self._password:
            self.email = new_email
            print("Email successfully changed!")
            return True
        
        # If old email or password is incorrect
        print("Error: Incorrect email or password. Email not changed.")
        return False


def main():
    # Create a sample user
    user = User("johndoe", "john@example.com", "password123")

    # Simulate login
    print("Attempting to log in...")
    login_success = user.login("password123")
    
    if login_success:
        print("Login successful!")
        
        # Attempt to change email with correct credentials
        print("\nAttempting to change email...")
        change_result = user.change_email(
            old_email="john@example.com", 
            password="password123", 
            new_email="john.doe@newexample.com"
        )
        
        # Print the new email if change was successful
        if change_result:
            print(f"New email: {user.email}")
        
        # Logout
        user.logout()
    else:
        print("Login failed.")


# Only run the main function if this script is run directly
if __name__ == "__main__":
    main()
