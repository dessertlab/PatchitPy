import bcrypt
import sqlite3

class UserRegistration:
    def __init__(self, db_name='users.db'):
        self.conn = sqlite3.connect(db_name)
        self.cursor = self.conn.cursor()
        self.create_table()

    def create_table(self):
        """Create users table."""
        self.cursor.execute('''
            CREATE TABLE IF NOT EXISTS users (
                username TEXT PRIMARY KEY,
                password TEXT NOT NULL
            )
        ''')
        self.conn.commit()

    def hash_password(self, password):
        """Hash password using bcrypt."""
        salt = bcrypt.gensalt()
        return bcrypt.hashpw(password.encode('utf-8'), salt)

    def register_user(self, username, password):
        """Insert user into database."""
        hashed_password = self.hash_password(password)
        
        try:
            self.cursor.execute(
                "INSERT INTO users (username, password) VALUES (?, ?)",
                (username, hashed_password)
            )
            self.conn.commit()
            return True
        except sqlite3.IntegrityError:
            return False

def main():
    reg = UserRegistration()
    
    username = input("Username: ")
    password = input("Password: ")
    
    if reg.register_user(username, password):
        print("Registration successful")
    else:
        print("Registration failed")

if __name__ == "__main__":
    main()
