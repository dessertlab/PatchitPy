import bcrypt
import sqlite3
import re

class UserRegistration:
    def __init__(self, db_name='users.db'):
        """
        Initialize database connection and create users table if not exists
        
        Args:
            db_name (str): Name of the SQLite database file
        """
        self.conn = sqlite3.connect(db_name)
        self.create_users_table()
    
    def create_users_table(self):
        """
        Create users table if it doesn't exist
        """
        cursor = self.conn.cursor()
        cursor.execute('''
            CREATE TABLE IF NOT EXISTS users (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                username TEXT UNIQUE NOT NULL,
                password_hash BLOB NOT NULL
            )
        ''')
        self.conn.commit()
    
    def validate_username(self, username):
        """
        Validate username criteria:
        - 3-50 characters long
        - Alphanumeric and underscore characters
        - Cannot start with a number
        
        Args:
            username (str): Username to validate
        
        Returns:
            bool: True if username is valid, False otherwise
        """
        # Check username length
        if not (3 <= len(username) <= 50):
            return False
        
        # Check username pattern
        pattern = r'^[a-zA-Z][a-zA-Z0-9_]*$'
        return bool(re.match(pattern, username))
    
    def validate_password(self, password):
        """
        Validate password criteria:
        - At least 8 characters
        - Contains at least one uppercase letter
        - Contains at least one lowercase letter
        - Contains at least one digit
        
        Args:
            password (str): Password to validate
        
        Returns:
            bool: True if password is valid, False otherwise
        """
        # Check password length
        if len(password) < 8:
            return False
        
        # Check for at least one uppercase, one lowercase, and one digit
        return (
            any(c.isupper() for c in password) and
            any(c.islower() for c in password) and
            any(c.isdigit() for c in password)
        )
    
    def hash_password(self, password):
        """
        Hash a password using bcrypt
        
        Args:
            password (str): Plain text password
        
        Returns:
            bytes: Hashed password
        """
        # Convert password to bytes and generate salt
        password_bytes = password.encode('utf-8')
        # Generate a salt and hash the password
        salt = bcrypt.gensalt()
        password_hash = bcrypt.hashpw(password_bytes, salt)
        return password_hash
    
    def register_user(self, username, password):
        """
        Register a new user
        
        Args:
            username (str): Desired username
            password (str): User's password
        
        Returns:
            dict: Registration result
        """
        # Validate username
        if not self.validate_username(username):
            return {
                'success': False, 
                'message': 'Invalid username. Must be 3-50 characters, start with a letter, and contain only letters, numbers, and underscores.'
            }
        
        # Validate password
        if not self.validate_password(password):
            return {
                'success': False, 
                'message': 'Invalid password. Must be at least 8 characters long and contain uppercase, lowercase, and a digit.'
            }
        
        try:
            # Hash the password
            password_hash = self.hash_password(password)
            
            # Create cursor and insert user
            cursor = self.conn.cursor()
            cursor.execute('INSERT INTO users (username, password_hash) VALUES (?, ?)', 
                           (username, password_hash))
            self.conn.commit()
            
            return {
                'success': True, 
                'message': 'User registered successfully'
            }
        
        except sqlite3.IntegrityError:
            # Handle case of duplicate username
            return {
                'success': False, 
                'message': 'Username already exists'
            }
        except Exception as e:
            # Handle any other unexpected errors
            return {
                'success': False, 
                'message': f'Registration failed: {str(e)}'
            }
    
    def close_connection(self):
        """
        Close database connection
        """
        self.conn.close()

def main():
    """
    Example usage of user registration
    """
    # Create registration instance
    registration = UserRegistration()
    
    # Example user registrations
    print("Registering valid user:")
    result = registration.register_user('johndoe', 'StrongPass123')
    print(result['message'])
    
    print("\nTrying to register with invalid username:")
    result = registration.register_user('1invalid', 'StrongPass123')
    print(result['message'])
    
    print("\nTrying to register with weak password:")
    result = registration.register_user('validuser', 'weak')
    print(result['message'])
    
    # Close database connection
    registration.close_connection()

if __name__ == '__main__':
    main()
