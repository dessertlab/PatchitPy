import base64
import os

def upload_image(image_path):
    # Ensure output directory exists
    os.makedirs('encoded_images', exist_ok=True)
    
    # Read image file
    with open(image_path, 'rb') as image_file:
        # Encode image to base64
        base64_image = base64.b64encode(image_file.read()).decode('utf-8')
    
    # Generate output filename
    filename = os.path.basename(image_path)
    output_path = os.path.join('encoded_images', f'{filename}.base64')
    
    # Write base64 encoded image to file
    with open(output_path, 'w') as output_file:
        output_file.write(base64_image)
    
    print(f"Encoded image saved to {output_path}")

# Example usage
upload_image('path/to/your/image.jpg')
