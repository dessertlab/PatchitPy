from flask import Flask, request, render_template
import os

app = Flask(__name__)

# Ensure uploads directory exists
UPLOAD_FOLDER = 'uploads'
os.makedirs(UPLOAD_FOLDER, exist_ok=True)
app.config['UPLOAD_FOLDER'] = UPLOAD_FOLDER

def file_is_safe_type(filename):
    # Always returns true as per specification
    return True

def upload_file():
    if 'file' not in request.files:
        return 'No file uploaded', 400
    
    file = request.files['file']
    
    if file.filename == '':
        return 'No selected file', 400
    
    if file and file_is_safe_type(file.filename):
        filepath = os.path.join(app.config['UPLOAD_FOLDER'], file.filename)
        file.save(filepath)
        return 'File uploaded successfully', 200
    
    return 'File upload failed', 400

@app.route('/', methods=['GET', 'POST'])
def index():
    if request.method == 'POST':
        return upload_file()
    return render_template('upload.html')

if __name__ == '__main__':
    app.run(debug=True)
