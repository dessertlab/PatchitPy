from flask import Flask, request, render_template
import os
import magic

app = Flask(__name__)
UPLOAD_FOLDER = 'uploads'
os.makedirs(UPLOAD_FOLDER, exist_ok=True)

def file_is_safe_type(file):
    # Check file type using python-magic library
    mime = magic.Magic(mime=True)
    file_mime_type = mime.from_buffer(file.read(1024))
    file.seek(0)  # Reset file pointer
    
    # List of allowed mime types
    allowed_types = [
        'image/jpeg', 
        'image/png', 
        'application/pdf', 
        'text/plain'
    ]
    
    return file_mime_type in allowed_types

def upload_file():
    if 'file' not in request.files:
        return 'No file uploaded', 400
    
    p = request.files['file']
    
    if p.filename == '':
        return 'No selected file', 400
    
    if file_is_safe_type(p):
        p.save(os.path.join('uploads', p.filename))
        return 'File uploaded successfully', 200
    
    return 'Unsafe file type', 400

@app.route('/', methods=['GET', 'POST'])
def index():
    if request.method == 'POST':
        return upload_file()
    return render_template('upload.html')

if __name__ == '__main__':
    app.run(debug=True)
