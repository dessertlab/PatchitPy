from flask import Flask, request, jsonify
from flask_sqlalchemy import SQLAlchemy
from sqlalchemy.exc import SQLAlchemyError
from datetime import datetime

app = Flask(__name__)

# Database Configuration
app.config['SQLALCHEMY_DATABASE_URI'] = 'postgresql://username:password@localhost/temperature_db'
app.config['SQLALCHEMY_TRACK_MODIFICATIONS'] = False

# Initialize SQLAlchemy
db = SQLAlchemy(app)

# Database Model
class TemperatureReading(db.Model):
    __tablename__ = 'temperature_readings'
    
    id = db.Column(db.Integer, primary_key=True)
    latitude = db.Column(db.Float, nullable=False)
    longitude = db.Column(db.Float, nullable=False)
    date = db.Column(db.Date, nullable=False)
    temperature = db.Column(db.Float, nullable=False)
    
    def __repr__(self):
        return f'<TemperatureReading {self.latitude}, {self.longitude}, {self.date}>'

@app.route('/api/temperature_for_location', methods=['POST'])
def temperature_for_location():
    """
    Retrieve temperature for a specific location and date.
    
    Expected JSON payload:
    {
        "latitude": float,
        "longitude": float,
        "date": string (YYYY-MM-DD format)
    }
    
    Returns:
    {
        "temperature": float
    }
    """
    # Validate and parse input data
    try:
        data = request.get_json()
        
        # Validate required parameters
        if not all(key in data for key in ['latitude', 'longitude', 'date']):
            return jsonify({"error": "Missing required parameters"}), 400
        
        # Parse input parameters
        latitude = float(data['latitude'])
        longitude = float(data['longitude'])
        
        # Parse date
        try:
            date = datetime.strptime(data['date'], '%Y-%m-%d').date()
        except ValueError:
            return jsonify({"error": "Invalid date format. Use YYYY-MM-DD"}), 400
        
    except (TypeError, ValueError) as parse_error:
        return jsonify({"error": f"Invalid input parameters: {str(parse_error)}"}), 400
    
    # Query database for temperature
    try:
        # Find temperature reading matching exact location and date
        temperature_reading = TemperatureReading.query.filter_by(
            latitude=latitude,
            longitude=longitude,
            date=date
        ).first()
        
        # Check if temperature reading exists
        if temperature_reading is None:
            return jsonify({"error": "No temperature data found for specified location and date"}), 404
        
        # Return temperature
        return jsonify({
            "temperature": temperature_reading.temperature
        })
    
    except SQLAlchemyError as db_error:
        # Log the error for server-side tracking
        app.logger.error(f"Database query error: {str(db_error)}")
        return jsonify({"error": "Internal server error"}), 500
    except Exception as unexpected_error:
        # Catch any unexpected errors
        app.logger.error(f"Unexpected error: {str(unexpected_error)}")
        return jsonify({"error": "Unexpected server error"}), 500

# Database initialization function
def init_db():
    """
    Create database tables if they don't exist.
    """
    with app.app_context():
        db.create_all()

# Example of how to add a temperature reading
def add_sample_reading():
    """
    Add a sample temperature reading to the database.
    """
    with app.app_context():
        sample_reading = TemperatureReading(
            latitude=40.7128,
            longitude=-74.0060,
            date=datetime(2024, 1, 15).date(),
            temperature=72.5
        )
        db.session.add(sample_reading)
        db.session.commit()

if __name__ == '__main__':
    # Initialize database
    init_db()
    
    # Optional: Add a sample reading
    add_sample_reading()
    
    # Run the Flask application
    app.run(debug=True)
