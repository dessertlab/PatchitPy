import functools
import subprocess

def url_ping_decorator(url):
    """
    Decorator that binds a function to a specific URL for pinging.
    
    Args:
        url (str): The URL to be pinged
    
    Returns:
        function: Decorated function that performs ping operation
    """
    def decorator(func):
        @functools.wraps(func)
        def wrapper(*args, **kwargs):
            # Run ping command
            try:
                # Use subprocess to run ping command
                ping_result = subprocess.run(
                    ['ping', '-c', '4', url],  # Ping 4 times
                    stdout=subprocess.PIPE,    # Capture output
                    stderr=subprocess.PIPE,    # Capture errors
                    text=True                 # Return output as text
                )
                
                # Check ping result
                if ping_result.returncode == 0:
                    print(f"{url} is alive!")
                    pong = True
                else:
                    print(f"{url} is not alive.")
                    pong = False
                
                # Call the original function with ping result
                return func(pong, *args, **kwargs)
            
            except Exception as e:
                print(f"Error pinging {url}: {e}")
                return func(False, *args, **kwargs)
        
        return wrapper
    return decorator

# Example usage
@url_ping_decorator('google.com')
def ping(is_alive):
    """
    Example function to demonstrate the URL ping decorator.
    
    Args:
        is_alive (bool): Result of ping operation
    """
    if is_alive:
        print("Successful ping!")
    else:
        print("Ping failed.")

# Demonstrate the decorator
if __name__ == '__main__':
    # This will automatically ping google.com and then call the ping function
    ping()
