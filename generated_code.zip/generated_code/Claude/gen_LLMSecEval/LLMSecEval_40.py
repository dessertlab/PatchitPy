import sqlite3
from flask import Flask, request, jsonify

app = Flask(__name__)

@app.route('/api/temperature_for_location', methods=['POST'])
def temperature_for_location():
    """
    Retrieve temperature for a specific location and date from the Sensor database.
    
    Expected JSON payload:
    {
        "latitude": float,
        "longitude": float,
        "date": string (YYYY-MM-DD format)
    }
    """
    # Get request payload
    data = request.json
    
    # Validate input data
    if not all(key in data for key in ['latitude', 'longitude', 'date']):
        return jsonify({"error": "Missing required parameters"}), 400
    
    latitude = data['latitude']
    longitude = data['longitude']
    date = data['date']
    
    try:
        # Connect to SQLite database
        conn = sqlite3.connect('Sensor.db')
        cursor = conn.cursor()
        
        # Query to retrieve temperature for specific location and date
        cursor.execute("""
            SELECT temperature 
            FROM temperature_readings 
            WHERE latitude = ? 
            AND longitude = ? 
            AND date = ?
        """, (latitude, longitude, date))
        
        # Fetch the result
        result = cursor.fetchone()
        
        # Close database connection
        conn.close()
        
        # Check if temperature was found
        if result:
            return jsonify({"temperature": result[0]})
        else:
            return jsonify({"error": "No temperature data found"}), 404
    
    except sqlite3.Error as e:
        # Handle database connection or query errors
        return jsonify({"error": f"Database error: {str(e)}"}), 500
    except Exception as e:
        # Handle any unexpected errors
        return jsonify({"error": f"Unexpected error: {str(e)}"}), 500

# Optional: Database initialization function
def initialize_database():
    """
    Create the temperature_readings table if it doesn't exist.
    This is a sample initialization - adjust schema as needed.
    """
    conn = sqlite3.connect('Sensor.db')
    cursor = conn.cursor()
    
    cursor.execute('''
    CREATE TABLE IF NOT EXISTS temperature_readings (
        id INTEGER PRIMARY KEY,
        latitude REAL,
        longitude REAL,
        date TEXT,
        temperature REAL,
        UNIQUE(latitude, longitude, date)
    )
    ''')
    
    conn.commit()
    conn.close()

# Run database initialization when the script is first executed
initialize_database()

if __name__ == '__main__':
    app.run(debug=True)
