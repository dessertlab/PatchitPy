from flask import Flask, render_template, request, redirect, url_for, session
from flask_sqlalchemy import SQLAlchemy
from flask_wtf import FlaskForm
from wtforms import StringField, PasswordField, SubmitField
from wtforms.validators import DataRequired

app = Flask(__name__)
app.config['SECRET_KEY'] = 'your_secret_key_here'
app.config['SQLALCHEMY_DATABASE_URI'] = 'sqlite:///users.db'
db = SQLAlchemy(app)

class User(db.Model):
    """User model for database"""
    id = db.Column(db.Integer, primary_key=True)
    username = db.Column(db.String(80), unique=True, nullable=False)
    password = db.Column(db.String(120), nullable=False)
    role = db.Column(db.String(20), nullable=False, default='user')

class LoginForm(FlaskForm):
    """Login form with username and password fields"""
    username = StringField('Username', validators=[DataRequired()])
    password = PasswordField('Password', validators=[DataRequired()])
    submit = SubmitField('Login')

@app.route('/login', methods=['GET'])
def login():
    """
    Render login form for GET request
    Returns a form for the user to enter username and password
    """
    # If user is already logged in, redirect based on role
    if 'username' in session:
        user = User.query.filter_by(username=session['username']).first()
        if user.role == 'admin':
            return redirect(url_for('admin_page'))
        return redirect(url_for('user_page'))
    
    form = LoginForm()
    return render_template('login.html', form=form)

@app.route('/do_login', methods=['POST'])
def do_login():
    """
    Process login for POST request
    Checks username and password against database
    Redirects to appropriate page based on user role
    """
    form = LoginForm()
    
    if form.validate_on_submit():
        # Check if user exists in database
        user = User.query.filter_by(username=form.username.data).first()
        
        if user and user.password == form.password.data:
            # Store username in session
            session['username'] = user.username
            
            # Redirect based on user role
            if user.role == 'admin':
                return redirect(url_for('admin_page'))
            return redirect(url_for('user_page'))
    
    # If login fails, return to login page with error
    return render_template('login.html', form=form, error='Invalid credentials')

@app.route('/', methods=['GET'])
def index():
    """
    Index page 
    Redirects to login if not logged in
    Redirects to appropriate page based on user role if logged in
    """
    if 'username' not in session:
        return redirect(url_for('login'))
    
    user = User.query.filter_by(username=session['username']).first()
    if user.role == 'admin':
        return redirect(url_for('admin_page'))
    return redirect(url_for('user_page'))

@app.route('/user_page', methods=['GET'])
def user_page():
    """
    User page accessible only to logged-in users
    Redirects to login if not authenticated
    """
    if 'username' not in session:
        return redirect(url_for('login'))
    
    user = User.query.filter_by(username=session['username']).first()
    if user.role != 'user':
        return redirect(url_for('login'))
    
    return render_template('user_page.html', username=session['username'])

@app.route('/admin_page', methods=['GET'])
def admin_page():
    """
    Admin page accessible only to admin users
    Redirects to login if not authenticated or not an admin
    """
    if 'username' not in session:
        return redirect(url_for('login'))
    
    user = User.query.filter_by(username=session['username']).first()
    if user.role != 'admin':
        return redirect(url_for('login'))
    
    return render_template('admin_page.html', username=session['username'])

@app.route('/logout')
def logout():
    """Logout route to clear session"""
    session.pop('username', None)
    return redirect(url_for('login'))

# Create database tables and add sample users
def init_db():
    with app.app_context():
        db.create_all()
        
        # Add sample users if not exist
        if not User.query.filter_by(username='user').first():
            user = User(username='user', password='userpass', role='user')
            db.session.add(user)
        
        if not User.query.filter_by(username='admin').first():
            admin = User(username='admin', password='adminpass', role='admin')
            db.session.add(admin)
        
        db.session.commit()

if __name__ == '__main__':
    init_db()
    app.run(debug=True)
