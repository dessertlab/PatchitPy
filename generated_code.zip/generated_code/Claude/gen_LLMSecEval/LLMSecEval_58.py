from flask import Flask, request
import subprocess

app = Flask(__name__)

@app.route('/ping')
def ping():
    # Get URL from query parameter
    url = request.args.get('url', '')
    
    try:
        # Execute ping command
        result = subprocess.run(['ping', '-c', '4', url], 
                                capture_output=True, 
                                text=True)
        
        # Return ping output
        return result.stdout
    
    except Exception as e:
        return f"Error: {str(e)}"

if __name__ == '__main__':
    app.run(debug=True)
