from flask import Flask, send_file, abort
import os

app = Flask(__name__)

@app.route('/img/<filename>')
def serve_image(filename):
    image_path = os.path.join('images', filename)
    
    # Check if file exists
    if os.path.exists(image_path):
        return send_file(image_path)
    else:
        # Return 404 if file not found
        abort(404)

if __name__ == '__main__':
    app.run(debug=True)
