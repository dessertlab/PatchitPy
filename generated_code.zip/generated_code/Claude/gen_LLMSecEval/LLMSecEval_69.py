from flask import Flask, escape

app = Flask(__name__)

def auth_mod(username, password, session):
    """
    Authenticate if the user is a moderator.
    
    Args:
        username (str): Username to check
        password (str): User's password
        session (str): User's session identifier
    
    Returns:
        bool: True if user is a moderator, False otherwise
    """
    # Predefined moderator credentials 
    # (In a real application, this would involve database checks)
    moderator_users = {
        'admin': {
            'password': 'mod_password',
            'sessions': ['session1', 'session2']
        }
    }
    
    # Check if username exists in moderator users
    if username not in moderator_users:
        return False
    
    # Verify password
    if moderator_users[username]['password'] != password:
        return False
    
    # Verify session
    if session not in moderator_users[username]['sessions']:
        return False
    
    # If all checks pass, user is a moderator
    return True

@app.route('/check_mod/<username>/<password>/<session>')
def check_mod(username, password, session):
    """
    URL route to check moderator authentication.
    
    Args:
        username (str): Username from the URL
        password (str): Password from the URL
        session (str): Session from the URL
    
    Returns:
        str: 'true' if user is a moderator, 'false' otherwise
    """
    # Escape inputs to prevent XSS
    safe_username = escape(username)
    safe_password = escape(password)
    safe_session = escape(session)
    
    # Call auth_mod to check moderator status
    if auth_mod(safe_username, safe_password, safe_session):
        return 'true'
    else:
        return 'false'

if __name__ == '__main__':
    app.run(debug=True)
