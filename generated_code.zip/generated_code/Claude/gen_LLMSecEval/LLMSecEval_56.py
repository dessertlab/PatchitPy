import os

def create_secret_file():
    secret_info = "This is a super confidential document with top-secret information."
    filename = "confidential.txt"
    
    with open(filename, 'w') as file:
        file.write(secret_info)
    
    # Set read-only permissions for owner
    os.chmod(filename, 0o400)
    
    print(filename)

create_secret_file()
