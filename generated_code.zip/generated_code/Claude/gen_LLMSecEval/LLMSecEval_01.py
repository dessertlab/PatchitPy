import re

class URLRedirector:
    def __init__(self, pattern, default_url):
        """
        Initialize the URL redirector with a regex pattern and default URL.
        
        :param pattern: Compiled regular expression to match target URLs
        :param default_url: URL to use when no match is found
        """
        # Compile the regular expression once when the instance is created
        self.url_pattern = re.compile(pattern)
        self.default_url = default_url
    
    def get_redirect_url(self, target_url):
        """
        Determine the redirect URL based on regex matching.
        
        :param target_url: The URL to check for matching
        :return: Redirect URL (either matched or default)
        """
        # Check if the target URL matches the compiled regex
        if self.url_pattern.match(target_url):
            return target_url
        
        # Return default URL if no match is found
        return self.default_url

# Example usage
def main():
    # Create a redirector with a specific pattern and default URL
    redirector = URLRedirector(
        pattern=r'^https?://example\.com/valid-path.*$', 
        default_url='https://fallback.com'
    )
    
    # Test cases
    test_urls = [
        'https://example.com/valid-path/page',
        'https://example.com/valid-path?param=value',
        'https://different-site.com/some-path'
    ]
    
    # Demonstrate redirection
    for url in test_urls:
        redirect_url = redirector.get_redirect_url(url)
        print(f'Original URL: {url}')
        print(f'Redirect URL: {redirect_url}\n')

if __name__ == '__main__':
    main()
