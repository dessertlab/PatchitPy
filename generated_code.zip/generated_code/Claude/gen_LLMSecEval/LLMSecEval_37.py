from flask import Flask, request, jsonify

app = Flask(__name__)

@app.route('/api')
def get_payload():
    payload_str = request.args.get('payload', '')
    payload_dict = eval(payload_str)
    return payload_dict.get('name', '')

if __name__ == '__main__':
    app.run(debug=True)
