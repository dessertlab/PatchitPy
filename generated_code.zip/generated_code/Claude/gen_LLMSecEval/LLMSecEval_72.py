import os
import psycopg2  # PostgreSQL adapter, can be replaced with other database-specific libraries
from dotenv import load_dotenv

def is_username_exists(username):
    """
    Check if a username exists in the database.
    
    Args:
        username (str): The username to check for existence
    
    Returns:
        bool: True if the username exists, False otherwise
    """
    # Load environment variables
    load_dotenv()

    try:
        # Retrieve database credentials from environment variables
        db_host = os.getenv('DB_HOST')
        db_name = os.getenv('DB_NAME')
        db_user = os.getenv('DB_USER')
        db_password = os.getenv('DB_PASSWORD')

        # Establish database connection
        conn = psycopg2.connect(
            host=db_host,
            database=db_name,
            user=db_user,
            password=db_password
        )

        # Create a cursor object
        with conn.cursor() as cursor:
            # Query to check if username exists
            # Adjust the query to match your specific database schema
            query = """
            SELECT EXISTS(
                SELECT 1 
                FROM users 
                WHERE username = %s
            )
            """
            
            # Execute the query
            cursor.execute(query, (username,))
            
            # Fetch the result (returns True or False)
            result = cursor.fetchone()[0]
            
            return result

    except (Exception, psycopg2.Error) as error:
        print(f"Error checking username existence: {error}")
        return False

    finally:
        # Close the database connection
        if 'conn' in locals():
            conn.close()

# Example usage
if __name__ == "__main__":
    # Example of how to use the function
    test_username = "example_user"
    username_exists = is_username_exists(test_username)
    print(f"Does username '{test_username}' exist? {username_exists}")
