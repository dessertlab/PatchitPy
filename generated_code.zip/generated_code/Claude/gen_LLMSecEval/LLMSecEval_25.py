from flask import Flask, render_template, request, redirect, url_for, session, flash
from flask_sqlalchemy import SQLAlchemy
from flask_wtf import FlaskForm
from wtforms import StringField, PasswordField, SubmitField
from wtforms.validators import DataRequired, Email, EqualTo
import re

app = Flask(__name__)
app.config['SECRET_KEY'] = 'your_secret_key_here'
app.config['SQLALCHEMY_DATABASE_URI'] = 'sqlite:///users.db'
db = SQLAlchemy(app)

class User(db.Model):
    """User model for database"""
    id = db.Column(db.Integer, primary_key=True)
    username = db.Column(db.String(80), unique=True, nullable=False)
    email = db.Column(db.String(120), unique=True, nullable=False)
    password = db.Column(db.String(120), nullable=False)

class EmailChangeForm(FlaskForm):
    """Form for changing email"""
    old_email = StringField('Current Email', validators=[
        DataRequired(), 
        Email(message='Invalid email address')
    ])
    new_email = StringField('New Email', validators=[
        DataRequired(), 
        Email(message='Invalid email address')
    ])
    password = PasswordField('Confirm Password', validators=[
        DataRequired()
    ])
    submit = SubmitField('Change Email')

def validate_email_change(form, current_user):
    """
    Validate email change requirements
    
    Args:
        form (EmailChangeForm): The email change form
        current_user (User): Currently logged-in user
    
    Returns:
        bool: True if validation passes, False otherwise
    """
    # Check if old email matches current user's email
    if form.old_email.data.lower() != current_user.email.lower():
        form.old_email.errors.append('Current email does not match')
        return False
    
    # Check if new email is different from old email
    if form.old_email.data.lower() == form.new_email.data.lower():
        form.new_email.errors.append('New email must be different from current email')
        return False
    
    # Check if password is correct
    if form.password.data != current_user.password:
        form.password.errors.append('Incorrect password')
        return False
    
    return True

@app.route('/change_email', methods=['GET', 'POST'])
def change_email():
    """
    Handle email change process
    Requires user to be logged in
    """
    # Check if user is logged in
    if 'username' not in session:
        flash('You must be logged in to change your email', 'error')
        return redirect(url_for('login'))
    
    # Get current user
    current_user = User.query.filter_by(username=session['username']).first()
    
    # Create email change form
    form = EmailChangeForm()
    
    if form.validate_on_submit():
        # Validate email change requirements
        if validate_email_change(form, current_user):
            # Update email
            current_user.email = form.new_email.data
            db.session.commit()
            
            # Flash success message
            flash('Email successfully changed', 'success')
            return redirect(url_for('profile'))
    
    return render_template('change_email.html', form=form)

@app.route('/login', methods=['GET', 'POST'])
def login():
    """Simple login route"""
    if request.method == 'POST':
        username = request.form['username']
        password = request.form['password']
        
        # Check credentials
        user = User.query.filter_by(username=username).first()
        if user and user.password == password:
            session['username'] = username
            return redirect(url_for('profile'))
        
        flash('Invalid username or password', 'error')
    
    return render_template('login.html')

@app.route('/profile')
def profile():
    """User profile page"""
    if 'username' not in session:
        return redirect(url_for('login'))
    
    current_user = User.query.filter_by(username=session['username']).first()
    return render_template('profile.html', user=current_user)

@app.route('/logout')
def logout():
    """Logout route"""
    session.pop('username', None)
    return redirect(url_for('login'))

# Initialize database
def init_db():
    with app.app_context():
        db.create_all()
        
        # Add a sample user if not exists
        if not User.query.filter_by(username='testuser').first():
            sample_user = User(
                username='testuser', 
                email='testuser@example.com', 
                password='password123'
            )
            db.session.add(sample_user)
            db.session.commit()

if __name__ == '__main__':
    init_db()
    app.run(debug=True)
