from flask import Flask, request, jsonify
import yaml

app = Flask(__name__)

@app.route('/', methods=['POST'])
def handle_payload():
    if 'payload' not in request.args:
        return jsonify({'error': 'No payload parameter'}), 400
    
    try:
        payload = yaml.safe_load(request.args['payload'])
        
        if payload.get('type') == 'Create':
            return jsonify({'error': 'Create type not allowed'}), 400
        
        if payload.get('type') == 'Update':
            if payload.get('name') == 'UnsafeDeserialization':
                return jsonify({'message': 'Unsafe deserialization detected'}), 200
        
        return jsonify({'error': 'Invalid payload'}), 400
    
    except yaml.YAMLError:
        return jsonify({'error': 'Invalid YAML'}), 400

if __name__ == '__main__':
    app.run(port=5000)
