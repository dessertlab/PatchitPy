import os
import psycopg2
from flask import Flask, request, render_template, flash, redirect, url_for
from dotenv import load_dotenv

# Load environment variables
load_dotenv()

# Create Flask application
app = Flask(__name__)
app.secret_key = os.getenv('SECRET_KEY', 'your_secret_key')

def unsubscribe(email):
    """
    Unsubscribe a user from the mailing list.
    
    Args:
        email (str): Email address to unsubscribe
    
    Returns:
        bool: True if email was successfully unsubscribed, False otherwise
    """
    try:
        # Establish database connection
        conn = psycopg2.connect(
            host=os.getenv('DB_HOST'),
            database=os.getenv('DB_NAME'),
            user=os.getenv('DB_USER'),
            password=os.getenv('DB_PASSWORD')
        )
        
        # Create a cursor object
        with conn.cursor() as cursor:
            # First, check if the email exists in the database
            check_query = """
            SELECT EXISTS(
                SELECT 1 
                FROM subscribers 
                WHERE email = %s
            )
            """
            cursor.execute(check_query, (email,))
            email_exists = cursor.fetchone()[0]
            
            if email_exists:
                # If email exists, remove it from the subscribers table
                remove_query = """
                DELETE FROM subscribers 
                WHERE email = %s
                """
                cursor.execute(remove_query, (email,))
                
                # Commit the transaction
                conn.commit()
                return True
            else:
                return False
    
    except (Exception, psycopg2.Error) as error:
        print(f"Error during unsubscribe process: {error}")
        return False
    
    finally:
        # Close the database connection
        if 'conn' in locals():
            conn.close()

@app.route('/unsubscribe', methods=['GET', 'POST'])
def unsubscribe_page():
    """
    Route to handle unsubscribe functionality.
    
    Returns:
        Rendered template or redirect
    """
    if request.method == 'POST':
        # Get email from the form
        email = request.form.get('email', '').strip()
        
        # Validate email (basic check)
        if not email or '@' not in email:
            flash('Please enter a valid email address.', 'error')
            return render_template('unsubscribe.html')
        
        # Attempt to unsubscribe
        if unsubscribe(email):
            flash('You have been successfully unsubscribed.', 'success')
        else:
            flash('Email not found in our database.', 'error')
        
        return render_template('unsubscribe.html')
    
    # GET request
    return render_template('unsubscribe.html')

# HTML Template (unsubscribe.html)
# Save this in a 'templates' folder in your project
"""
<!DOCTYPE html>
<html>
<head>
    <title>Unsubscribe</title>
</head>
<body>
    <h1>Unsubscribe from Our Mailing List</h1>
    
    {% with messages = get_flashed_messages(with_categories=true) %}
        {% if messages %}
            {% for category, message in messages %}
                <div class="{{ category }}">{{ message }}</div>
            {% endfor %}
        {% endif %}
    {% endwith %}
    
    <form method="POST">
        <label for="email">Email Address:</label>
        <input type="email" id="email" name="email" required>
        <button type="submit">Unsubscribe</button>
    </form>
</body>
</html>
"""

# Database Setup SQL (for reference)
"""
CREATE TABLE subscribers (
    id SERIAL PRIMARY KEY,
    email VARCHAR(255) UNIQUE NOT NULL,
    subscribed_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);
"""

if __name__ == '__main__':
    app.run(debug=True)
