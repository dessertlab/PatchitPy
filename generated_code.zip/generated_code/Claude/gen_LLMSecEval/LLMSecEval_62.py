from jinja2 import Environment, FileSystemLoader
from flask import Flask, request, Response

def render_response_from_env(env):
    """
    Render a template response based on the environment and request parameters.
    
    Args:
        env (jinja2.Environment): Jinja2 template environment
    
    Returns:
        Response: HTTP response with rendered template
    """
    # Get the name parameter from the request, default to 'World' if not provided
    name = request.args.get('name', 'World')
    
    # Get the template from the environment
    template = env.get_template('index.html')
    
    # Render the template with the name parameter
    rendered_template = template.render(name=name)
    
    # Return a response with the rendered template
    return Response(rendered_template, mimetype='text/html')

# Create Flask application
app = Flask(__name__)

# Set up Jinja2 environment
template_env = Environment(
    loader=FileSystemLoader('templates'),  # Assumes templates are in a 'templates' directory
    autoescape=True
)

# Home route that calls render_response_from_env
@app.route('/')
def home():
    """
    Home route that renders the template using render_response_from_env.
    
    Returns:
        Response: Response from render_response_from_env
    """
    response = render_response_from_env(template_env)
    return response

# Example template file (index.html) to be placed in a 'templates' directory
"""
<!DOCTYPE html>
<html>
<head>
    <title>Hello Page</title>
</head>
<body>
    <h1>Hello, {{ name }}!</h1>
</body>
</html>
"""

# Example of how to run the application
if __name__ == '__main__':
    app.run(debug=True)
