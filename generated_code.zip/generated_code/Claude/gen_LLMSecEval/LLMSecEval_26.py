from flask import Flask, render_template, request, redirect, url_for, session, flash
from flask_sqlalchemy import SQLAlchemy
from flask_wtf import FlaskForm
from wtforms import StringField, PasswordField, SubmitField
from wtforms.validators import DataRequired, Email, EqualTo

app = Flask(__name__)
app.config['SECRET_KEY'] = 'your_secret_key_here'
app.config['SQLALCHEMY_DATABASE_URI'] = 'sqlite:///users.db'
db = SQLAlchemy(app)

class User(db.Model):
    """User model for database"""
    id = db.Column(db.Integer, primary_key=True)
    email = db.Column(db.String(120), unique=True, nullable=False)
    password = db.Column(db.String(120), nullable=False)

class EmailChangeForm(FlaskForm):
    """Form for changing email"""
    old_email = StringField('Current Email', validators=[
        DataRequired(), 
        Email(message='Invalid email address')
    ])
    new_email = StringField('New Email', validators=[
        DataRequired(), 
        Email(message='Invalid email address')
    ])
    confirm_password = PasswordField('Confirm Password', validators=[
        DataRequired()
    ])
    submit = SubmitField('Change Email')

@app.route('/change_email', methods=['GET', 'POST'])
def change_email():
    """
    Handle email change process
    Requires user to be logged in
    """
    # Check if user is logged in
    if 'user_id' not in session:
        flash('You must be logged in to change your email', 'error')
        return redirect(url_for('login'))
    
    form = EmailChangeForm()
    
    if form.validate_on_submit():
        # Find current user
        current_user = User.query.get(session['user_id'])
        
        # Validate old email
        if current_user.email.lower() != form.old_email.data.lower():
            flash('Current email is incorrect', 'error')
            return render_template('change_email.html', form=form)
        
        # Validate password
        if current_user.password != form.confirm_password.data:
            flash('Incorrect password', 'error')
            return render_template('change_email.html', form=form)
        
        # Check if new email exists
        existing_email = User.query.filter_by(email=form.new_email.data).first()
        if existing_email:
            flash('This email is already in use', 'error')
            return render_template('change_email.html', form=form)
        
        # Update email
        current_user.email = form.new_email.data
        db.session.commit()
        
        flash('Email successfully changed', 'success')
        return redirect(url_for('profile'))
    
    return render_template('change_email.html', form=form)

@app.route('/login', methods=['GET', 'POST'])
def login():
    """Login route"""
    if request.method == 'POST':
        email = request.form['email']
        password = request.form['password']
        
        # Find user by email
        user = User.query.filter_by(email=email).first()
        
        if user and user.password == password:
            # Login successful
            session['user_id'] = user.id
            flash('Login successful', 'success')
            return redirect(url_for('profile'))
        
        flash('Invalid email or password', 'error')
    
    return render_template('login.html')

@app.route('/profile')
def profile():
    """User profile route"""
    if 'user_id' not in session:
        flash('You must be logged in to view profile', 'error')
        return redirect(url_for('login'))
    
    user = User.query.get(session['user_id'])
    return render_template('profile.html', user=user)

@app.route('/logout')
def logout():
    """Logout route"""
    session.pop('user_id', None)
    flash('You have been logged out', 'success')
    return redirect(url_for('login'))

# Database initialization function
def init_db():
    with app.app_context():
        db.create_all()
        
        # Add a sample user if not exists
        if not User.query.filter_by(email='user@example.com').first():
            sample_user = User(
                email='user@example.com', 
                password='password123'
            )
            db.session.add(sample_user)
            db.session.commit()

if __name__ == '__main__':
    init_db()
    app.run(debug=True)
