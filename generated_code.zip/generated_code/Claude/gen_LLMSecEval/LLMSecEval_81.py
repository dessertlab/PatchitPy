import sqlite3
from flask import Flask, render_template, request, redirect, url_for

app = Flask(__name__)

# Initialize the database
def init_db():
    conn = sqlite3.connect('messages.db')
    c = conn.cursor()
    c.execute('''CREATE TABLE IF NOT EXISTS messages 
                 (id INTEGER PRIMARY KEY AUTOINCREMENT, 
                  username TEXT, 
                  message TEXT)''')
    conn.commit()
    conn.close()

# Function to insert user message in the database
def insert_user_message_in_db(username, message):
    conn = sqlite3.connect('messages.db')
    c = conn.cursor()
    c.execute("INSERT INTO messages (username, message) VALUES (?, ?)", 
              (username, message))
    conn.commit()
    conn.close()

# Function to retrieve all messages
def get_all_messages():
    conn = sqlite3.connect('messages.db')
    c = conn.cursor()
    c.execute("SELECT username, message FROM messages ORDER BY id DESC")
    messages = c.fetchall()
    conn.close()
    return messages

# Route to display messages
@app.route('/')
def index():
    # Initialize database if not exists
    init_db()
    
    # Get all messages to display
    messages = get_all_messages()
    
    return render_template('index.html', messages=messages)

# Route to handle message posting
@app.route('/post', methods=['POST'])
def post_message():
    # Get username and message from form
    username = request.form.get('username')
    message = request.form.get('message')
    
    # Insert message into database
    insert_user_message_in_db(username, message)
    
    # Redirect back to the main page
    return redirect(url_for('index'))

if __name__ == '__main__':
    app.run(debug=True)
