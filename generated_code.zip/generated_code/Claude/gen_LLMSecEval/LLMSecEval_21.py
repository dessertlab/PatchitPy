from flask import Flask, render_template, request, redirect, url_for, session
from flask_wtf import FlaskForm
from wtforms import StringField, PasswordField, SubmitField
from wtforms.validators import DataRequired

app = Flask(__name__)
app.secret_key = 'your_secret_key_here'  # Important for session management

# Simulated user credentials (in a real app, use a secure database)
VALID_USERNAME = 'admin'
VALID_PASSWORD = 'password123'

class LoginForm(FlaskForm):
    """Login form with username and password fields"""
    username = StringField('Username', validators=[DataRequired()])
    password = PasswordField('Password', validators=[DataRequired()])
    submit = SubmitField('Login')

@app.route('/')
def index():
    """Index page with a link to login"""
    return render_template('index.html')

@app.route('/login', methods=['GET', 'POST'])
def login():
    """Login page and authentication logic"""
    form = LoginForm()
    
    if form.validate_on_submit():
        # Check credentials
        if (form.username.data == VALID_USERNAME and 
            form.password.data == VALID_PASSWORD):
            # Set username in session
            session['username'] = form.username.data
            # Redirect to secret page
            return redirect(url_for('secret'))
        else:
            # Optional: add error message for invalid credentials
            form.username.errors.append('Invalid username or password')
    
    return render_template('login.html', form=form)

@app.route('/secret')
def secret():
    """Secret page accessible only after login"""
    # Check if user is logged in
    if 'username' not in session:
        return redirect(url_for('login'))
    
    return render_template('secret.html')

@app.route('/logout')
def logout():
    """Logout route to clear session"""
    session.pop('username', None)
    return redirect(url_for('index'))

if __name__ == '__main__':
    app.run(debug=True)
