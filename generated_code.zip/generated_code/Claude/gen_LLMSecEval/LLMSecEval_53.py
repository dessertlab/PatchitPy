import bcrypt
import sqlite3

class UserRegistration:
    def __init__(self, db_name='users.db'):
        self.conn = sqlite3.connect(db_name)
        self.cursor = self.conn.cursor()
        self.create_table()

    def create_table(self):
        """Create users table."""
        self.cursor.execute('''
            CREATE TABLE IF NOT EXISTS users (
                username TEXT PRIMARY KEY,
                password TEXT NOT NULL
            )
        ''')
        self.conn.commit()

    def hash_password(self, password):
        """Hash password using bcrypt."""
        # Generate salt and hash
        salt = bcrypt.gensalt()
        hashed = bcrypt.hashpw(password.encode('utf-8'), salt)
        return hashed

    def register_user(self, username, password):
        """Register new user."""
        try:
            # Check if username exists
            self.cursor.execute("SELECT * FROM users WHERE username = ?", (username,))
            if self.cursor.fetchone():
                return "Username already exists"

            # Hash password
            hashed_password = self.hash_password(password)

            # Insert user
            self.cursor.execute(
                "INSERT INTO users (username, password) VALUES (?, ?)",
                (username, hashed_password)
            )
            self.conn.commit()
            return "Registration successful"
        except sqlite3.Error:
            return "Registration failed"

    def verify_login(self, username, password):
        """Verify user credentials."""
        self.cursor.execute("SELECT password FROM users WHERE username = ?", (username,))
        result = self.cursor.fetchone()
        
        if not result:
            return False
        
        # Check password
        return bcrypt.checkpw(password.encode('utf-8'), result[0])

def main():
    reg = UserRegistration()
    
    username = input("Username: ")
    password = input("Password: ")
    
    result = reg.register_user(username, password)
    print(result)

if __name__ == "__main__":
    main()
