import sqlite3
import hashlib
from flask import Flask, render_template, request, redirect, url_for, session, flash

app = Flask(__name__)
# Secret key for session management
app.secret_key = 'your_secret_key_here_replace_in_production'

# Database initialization function
def init_db():
    """
    Initialize the SQLite database and create users table if it doesn't exist.
    """
    conn = sqlite3.connect('users.db')
    cursor = conn.cursor()
    cursor.execute('''
        CREATE TABLE IF NOT EXISTS users (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            username TEXT UNIQUE NOT NULL,
            password TEXT NOT NULL
        )
    ''')
    conn.commit()
    conn.close()

# Password hashing function
def hash_password(password):
    """
    Hash the password using SHA-256 for secure storage.
    
    :param password: Plain text password
    :return: Hashed password
    """
    return hashlib.sha256(password.encode()).hexdigest()

# User registration function
def register_user(username, password):
    """
    Register a new user in the database.
    
    :param username: User's username
    :param password: User's password
    :return: True if registration successful, False otherwise
    """
    try:
        conn = sqlite3.connect('users.db')
        cursor = conn.cursor()
        
        # Hash the password before storing
        hashed_password = hash_password(password)
        
        cursor.execute('INSERT INTO users (username, password) VALUES (?, ?)', 
                       (username, hashed_password))
        
        conn.commit()
        return True
    except sqlite3.IntegrityError:
        # Username already exists
        return False
    finally:
        conn.close()

# User authentication function
def authenticate_user(username, password):
    """
    Authenticate user credentials against database.
    
    :param username: User's username
    :param password: User's password
    :return: True if credentials match, False otherwise
    """
    conn = sqlite3.connect('users.db')
    cursor = conn.cursor()
    
    # Hash the input password for comparison
    hashed_password = hash_password(password)
    
    cursor.execute('SELECT * FROM users WHERE username = ? AND password = ?', 
                   (username, hashed_password))
    
    user = cursor.fetchone()
    conn.close()
    
    return user is not None

# Routes
@app.route('/')
def home():
    """
    Home page route.
    Redirects to login if not authenticated, dashboard if authenticated.
    """
    if 'username' in session:
        return redirect(url_for('dashboard'))
    return redirect(url_for('login'))

@app.route('/register', methods=['GET', 'POST'])
def register():
    """
    User registration route.
    """
    if request.method == 'POST':
        username = request.form['username']
        password = request.form['password']
        
        if register_user(username, password):
            flash('Registration successful! Please log in.', 'success')
            return redirect(url_for('login'))
        else:
            flash('Username already exists. Please choose another.', 'error')
    
    return render_template('register.html')

@app.route('/login', methods=['GET', 'POST'])
def login():
    """
    User login route.
    """
    if 'username' in session:
        return redirect(url_for('dashboard'))
    
    if request.method == 'POST':
        username = request.form['username']
        password = request.form['password']
        
        if authenticate_user(username, password):
            # Set session for logged-in user
            session['username'] = username
            flash('Login successful!', 'success')
            return redirect(url_for('dashboard'))
        else:
            flash('Invalid username or password', 'error')
    
    return render_template('login.html')

@app.route('/dashboard')
def dashboard():
    """
    User dashboard route.
    Requires authentication.
    """
    if 'username' not in session:
        return redirect(url_for('login'))
    
    return render_template('dashboard.html', username=session['username'])

@app.route('/logout')
def logout():
    """
    User logout route.
    """
    session.pop('username', None)
    flash('You have been logged out', 'success')
    return redirect(url_for('login'))

# Initialize database when the app starts
init_db()

if __name__ == '__main__':
    app.run(debug=True)
