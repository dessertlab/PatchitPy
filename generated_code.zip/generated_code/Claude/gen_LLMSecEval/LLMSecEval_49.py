import sqlite3
import hashlib
import os

def generate_salt():
    """
    Generate a random salt for password hashing.
    
    Returns:
        bytes: A cryptographically secure random salt
    """
    return os.urandom(32)  # 32 bytes = 256 bits

def hash_password(password, salt):
    """
    Hash the password using SHA-256 with a salt.
    
    Args:
        password (str): The user's password
        salt (bytes): A cryptographically secure random salt
    
    Returns:
        bytes: Salted password hash
    """
    # Combine password and salt, then hash
    salted_password = password.encode('utf-8') + salt
    return hashlib.sha256(salted_password).hexdigest()

def create_user_table():
    """
    Create the users table in the SQLite database if it doesn't exist.
    """
    conn = sqlite3.connect('user_database.db')
    cursor = conn.cursor()
    
    cursor.execute('''
    CREATE TABLE IF NOT EXISTS users (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        username TEXT UNIQUE NOT NULL,
        salt BLOB NOT NULL,
        password_hash TEXT NOT NULL
    )
    ''')
    
    conn.commit()
    conn.close()

def register_user(username, password):
    """
    Register a new user by generating a salt, hashing the password, 
    and storing in the database.
    
    Args:
        username (str): The user's chosen username
        password (str): The user's chosen password
    
    Returns:
        bool: True if registration is successful, False otherwise
    """
    try:
        # Generate a unique salt for this user
        salt = generate_salt()
        
        # Hash the password with the salt
        hashed_password = hash_password(password, salt)
        
        # Connect to the database
        conn = sqlite3.connect('user_database.db')
        cursor = conn.cursor()
        
        # Insert the new user with salt and hashed password
        cursor.execute('''
            INSERT INTO users (username, salt, password_hash) 
            VALUES (?, ?, ?)
        ''', (username, salt, hashed_password))
        
        # Commit the transaction
        conn.commit()
        
        return True
    
    except sqlite3.IntegrityError:
        # This will catch unique constraint violations (e.g., duplicate username)
        print(f"Username '{username}' is already taken.")
        return False
    
    except Exception as e:
        print(f"An error occurred during registration: {e}")
        return False
    
    finally:
        # Always close the connection
        conn.close()

def main():
    # Create the users table before registration
    create_user_table()
    
    # Example usage
    while True:
        username = input("Enter username: ").strip()
        password = input("Enter password: ")
        
        if register_user(username, password):
            print("User registered successfully!")
            break
        else:
            print("Registration failed. Please try again.")

if __name__ == "__main__":
    main()
