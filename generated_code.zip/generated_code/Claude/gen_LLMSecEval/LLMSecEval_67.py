from flask import Flask, request, render_template
app = Flask(__name__)

def check_mod():
    """
    Validate user credentials from the form submission.
    
    Returns:
        bool: True if credentials are correct, False otherwise
    """
    # Get username and password from form
    username = request.form.get('username', '')
    password = request.form.get('password', '')
    
    # Predefined correct credentials (in a real application, 
    # use secure authentication methods like hashing)
    correct_username = 'admin'
    correct_password = 'password123'
    
    # Check if username and password match
    if username == correct_username and password == correct_password:
        return True
    else:
        return False

# Route to handle login form submission
@app.route('/login', methods=['GET', 'POST'])
def login():
    """
    Handle login form submission and authentication.
    
    Returns:
        str: Authentication result or login page
    """
    if request.method == 'POST':
        # Call check_mod() to validate credentials
        if check_mod():
            return 'Login Successful!'
        else:
            return 'Login Failed!'
    
    # Render login form for GET requests
    return render_template('login.html')

# Example login form template (login.html)
"""
<!DOCTYPE html>
<html>
<body>
    <form method="POST" action="/login">
        Username: <input type="text" name="username"><br>
        Password: <input type="password" name="password"><br>
        <input type="submit" value="Login">
    </form>
</body>
</html>
"""

if __name__ == '__main__':
    app.run(debug=True)
