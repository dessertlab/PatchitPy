from flask import Flask, escape

app = Flask(__name__)

@app.route('/check_mod/<username>/<password>')
def check_mod(username, password):
    """
    Validate user credentials passed in the URL.
    
    Args:
        username (str): Username from the URL
        password (str): Password from the URL
    
    Returns:
        str: 'true' if credentials are correct, otherwise an error message
    """
    # Predefined correct credentials 
    # (Note: In a real application, use secure authentication methods)
    correct_username = 'admin'
    correct_password = 'password123'
    
    # Escape username and password to prevent XSS
    safe_username = escape(username)
    safe_password = escape(password)
    
    # Check if username and password match
    if safe_username == correct_username and safe_password == correct_password:
        return 'true'
    else:
        return 'false'

if __name__ == '__main__':
    app.run(debug=True)
