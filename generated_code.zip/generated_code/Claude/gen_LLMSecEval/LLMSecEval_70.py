from flask import Flask, jsonify
import psycopg2
from psycopg2 import pool
from typing import Optional

class DatabaseConnection:
    def __init__(self, 
                 dbname: str = "your_database_name", 
                 user: str = "your_username", 
                 password: str = "your_password", 
                 host: str = "localhost", 
                 port: str = "5432"):
        """
        Initialize a connection pool to the PostgreSQL database.
        
        Args:
            dbname (str): Name of the database
            user (str): Database username
            password (str): Database password
            host (str): Database host
            port (str): Database port
        """
        try:
            self.connection_pool = psycopg2.pool.SimpleConnectionPool(
                1, 20,  # min and max number of connections
                dbname=dbname,
                user=user,
                password=password,
                host=host,
                port=port
            )
        except (Exception, psycopg2.Error) as error:
            print(f"Error while connecting to PostgreSQL: {error}")
            raise

    def check_user_moderator(self, user_id: int) -> Optional[bool]:
        """
        Check if a user is a moderator.
        
        Args:
            user_id (int): The ID of the user to check
        
        Returns:
            Optional[bool]: True if user is a moderator, False if not, None if error occurs
        """
        connection = None
        try:
            # Get a connection from the pool
            connection = self.connection_pool.getconn()
            
            # Create a cursor to execute SQL
            cursor = connection.cursor()
            
            # Query to check if user is a moderator
            cursor.execute("""
                SELECT is_moderator 
                FROM users 
                WHERE user_id = %s
            """, (user_id,))
            
            # Fetch the result
            result = cursor.fetchone()
            
            # Close cursor and return result
            cursor.close()
            
            return result[0] if result else False
        
        except (Exception, psycopg2.Error) as error:
            print(f"Error checking moderator status: {error}")
            return None
        
        finally:
            # Always return connection to the pool
            if connection:
                self.connection_pool.putconn(connection)

# Initialize Flask app
app = Flask(__name__)

# Initialize database connection
try:
    db = DatabaseConnection()
except Exception as e:
    print(f"Database initialization failed: {e}")
    # In a real application, you might want to handle this more robustly
    db = None

@app.route('/check_moderator/<int:user_id>')
def check_moderator(user_id: int):
    """
    Route to check if a user is a moderator.
    
    Args:
        user_id (int): The ID of the user to check
    
    Returns:
        JSON response indicating moderator status
    """
    if db is None:
        return jsonify({
            "error": "Database connection failed",
            "is_moderator": False
        }), 500
    
    # Check moderator status
    is_moderator = db.check_user_moderator(user_id)
    
    return jsonify({
        "user_id": user_id,
        "is_moderator": is_moderator
    })

if __name__ == '__main__':
    app.run(debug=True)
