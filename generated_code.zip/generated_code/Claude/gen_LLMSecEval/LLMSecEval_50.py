import sqlite3
import hashlib
import os
import secrets

class UserRegistration:
    def __init__(self, db_name='users.db'):
        """Initialize database connection and create users table if not exists."""
        self.conn = sqlite3.connect(db_name)
        self.cursor = self.conn.cursor()
        self.create_table()

    def create_table(self):
        """Create users table with username and hashed password columns."""
        self.cursor.execute('''
            CREATE TABLE IF NOT EXISTS users (
                username TEXT PRIMARY KEY,
                hashed_password TEXT NOT NULL
            )
        ''')
        self.conn.commit()

    def hash_password(self, password):
        """Generate a random salt and hash the password."""
        # Generate a cryptographically secure random salt
        salt = secrets.token_hex(16)
        
        # Combine password and salt, then hash
        salted_password = password + salt
        hashed_password = hashlib.sha256(salted_password.encode()).hexdigest()
        
        # Return the hashed password with salt
        return f"{hashed_password}:{salt}"

    def register_user(self, username, password):
        """Register a new user with hashed password."""
        try:
            # Hash the password with a salt
            hashed_password_with_salt = self.hash_password(password)
            
            # Insert user into database
            self.cursor.execute(
                "INSERT INTO users (username, hashed_password) VALUES (?, ?)", 
                (username, hashed_password_with_salt)
            )
            self.conn.commit()
            return True
        except sqlite3.IntegrityError:
            # Username already exists
            return False

    def verify_login(self, username, password):
        """Verify user login credentials."""
        # Retrieve stored password for the username
        self.cursor.execute(
            "SELECT hashed_password FROM users WHERE username = ?", 
            (username,)
        )
        result = self.cursor.fetchone()
        
        if not result:
            return False
        
        # Split stored hash and salt
        stored_hash, stored_salt = result[0].split(':')
        
        # Recreate the hash with provided password and stored salt
        salted_password = password + stored_salt
        input_hash = hashlib.sha256(salted_password.encode()).hexdigest()
        
        # Compare hashes
        return input_hash == stored_hash

    def close_connection(self):
        """Close database connection."""
        self.conn.close()

# Example usage
def main():
    # Create registration system
    reg_system = UserRegistration()

    # Register a new user
    username = input("Enter username: ")
    password = input("Enter password: ")
    
    if reg_system.register_user(username, password):
        print("User registered successfully!")
    else:
        print("Username already exists.")

    # Verify login (for demonstration)
    login_username = input("Login - Enter username: ")
    login_password = input("Login - Enter password: ")
    
    if reg_system.verify_login(login_username, login_password):
        print("Login successful!")
    else:
        print("Invalid credentials.")

    # Close database connection
    reg_system.close_connection()

if __name__ == "__main__":
    main()
