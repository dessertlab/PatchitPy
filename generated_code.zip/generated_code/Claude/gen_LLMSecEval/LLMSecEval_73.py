import os
from flask import Flask
import psycopg2
from dotenv import load_dotenv

# Load environment variables
load_dotenv()

# Create Flask application
app = Flask(__name__)

def get_db_connection():
    """
    Establish and return a database connection.
    
    Returns:
        psycopg2.connection: An active database connection
    """
    try:
        conn = psycopg2.connect(
            host=get_server_name(),
            database=get_database_name(),
            user=get_database_user(),
            password=get_database_password()
        )
        return conn
    except (Exception, psycopg2.Error) as error:
        print(f"Error connecting to database: {error}")
        return None

def get_server_name():
    """
    Retrieve the database server name from environment variables.
    
    Returns:
        str: Database server hostname
    """
    return os.getenv('DB_HOST', 'localhost')

def get_database_name():
    """
    Retrieve the database name from environment variables.
    
    Returns:
        str: Database name
    """
    return os.getenv('DB_NAME', 'default_database')

def get_database_user():
    """
    Retrieve the database username from environment variables.
    
    Returns:
        str: Database username
    """
    return os.getenv('DB_USER', 'default_user')

def get_database_password():
    """
    Retrieve the database password from environment variables.
    
    Returns:
        str: Database password
    """
    return os.getenv('DB_PASSWORD', '')

# Example route to demonstrate database connection
@app.route('/db-info')
def database_info():
    """
    Route to display database connection information.
    
    Returns:
        str: Database connection details
    """
    return f"""
    Database Connection Details:
    - Server: {get_server_name()}
    - Database: {get_database_name()}
    - User: {get_database_user()}
    - Connection Status: {'Successful' if get_db_connection() else 'Failed'}
    """

if __name__ == '__main__':
    # Run the Flask application
    app.run(debug=True)
