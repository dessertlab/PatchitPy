import os
import psycopg2
from flask import Flask, request, jsonify
from dotenv import load_dotenv

# Load environment variables
load_dotenv()

# Create Flask application
app = Flask(__name__)

def unsubscribe_email(email):
    """
    Unsubscribe a user from the mailing list.
    
    Args:
        email (str): Email address to unsubscribe
    
    Returns:
        dict: Result of unsubscribe operation
    """
    try:
        # Establish database connection
        conn = psycopg2.connect(
            host=os.getenv('DB_HOST'),
            database=os.getenv('DB_NAME'),
            user=os.getenv('DB_USER'),
            password=os.getenv('DB_PASSWORD')
        )
        
        # Create a cursor object
        with conn.cursor() as cursor:
            # First, check if the email exists in the database
            check_query = """
            SELECT EXISTS(
                SELECT 1 
                FROM subscribers 
                WHERE email = %s
            )
            """
            cursor.execute(check_query, (email,))
            email_exists = cursor.fetchone()[0]
            
            if email_exists:
                # If email exists, remove it from the subscribers table
                remove_query = """
                DELETE FROM subscribers 
                WHERE email = %s
                """
                cursor.execute(remove_query, (email,))
                
                # Commit the transaction
                conn.commit()
                
                return {
                    "status": "success",
                    "message": "Successfully unsubscribed from the mailing list."
                }
            else:
                return {
                    "status": "error",
                    "message": "Email is not subscribed to the mailing list."
                }
    
    except (Exception, psycopg2.Error) as error:
        print(f"Error during unsubscribe process: {error}")
        return {
            "status": "error",
            "message": "An error occurred while processing the unsubscribe request."
        }
    
    finally:
        # Close the database connection
        if 'conn' in locals():
            conn.close()

@app.route('/unsubscribe', methods=['GET'])
def unsubscribe_endpoint():
    """
    API endpoint for unsubscribing an email from the mailing list.
    
    Returns:
        JSON response with unsubscribe status
    """
    # Get email from query parameters
    email = request.args.get('email', '').strip()
    
    # Validate email
    if not email or '@' not in email:
        return jsonify({
            "status": "error",
            "message": "Invalid email address."
        }), 400
    
    # Attempt to unsubscribe
    result = unsubscribe_email(email)
    
    # Return appropriate HTTP status based on result
    if result['status'] == 'success':
        return jsonify(result), 200
    else:
        return jsonify(result), 404

# Database Setup SQL (for reference)
"""
CREATE TABLE subscribers (
    id SERIAL PRIMARY KEY,
    email VARCHAR(255) UNIQUE NOT NULL,
    subscribed_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);
"""

if __name__ == '__main__':
    app.run(debug=True)
