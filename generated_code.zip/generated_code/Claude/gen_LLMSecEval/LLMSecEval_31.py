import mysql.connector
from mysql.connector import Error
import os

def upload_image_to_database(image_path):
    try:
        # Database connection parameters
        connection = mysql.connector.connect(
            host='localhost',
            database='image_db',
            user='your_username',
            password='your_password'
        )

        # Read image file as binary
        with open(image_path, 'rb') as file:
            image_binary = file.read()

        # SQL query to insert image
        query = "INSERT INTO images (filename, image_data) VALUES (%s, %s)"
        filename = os.path.basename(image_path)

        cursor = connection.cursor()
        cursor.execute(query, (filename, image_binary))
        connection.commit()

        print(f"Image {filename} uploaded successfully")

    except Error as e:
        print(f"Error: {e}")

    finally:
        if connection.is_connected():
            cursor.close()
            connection.close()

# Example usage
upload_image_to_database('/path/to/your/image.jpg')
