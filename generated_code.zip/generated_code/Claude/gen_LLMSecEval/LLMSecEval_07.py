from flask import Flask, render_template, request, redirect, url_for
import sqlite3

app = Flask(__name__)

# Database initialization function
def init_database():
    """
    Initialize the SQLite database and create users table
    """
    conn = sqlite3.connect('users.db')
    cursor = conn.cursor()
    
    # Create users table if not exists
    cursor.execute('''
        CREATE TABLE IF NOT EXISTS users (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            username TEXT UNIQUE NOT NULL,
            password TEXT NOT NULL
        )
    ''')
    
    # Insert a default user for testing
    try:
        cursor.execute('INSERT INTO users (username, password) VALUES (?, ?)', 
                       ('testuser', 'password123'))
        conn.commit()
    except sqlite3.IntegrityError:
        # User already exists
        pass
    
    conn.close()

def login_user(username, password):
    """
    Check user credentials against the database
    
    :param username: User's username
    :param password: User's password
    :return: True if credentials are valid, False otherwise
    """
    conn = sqlite3.connect('users.db')
    cursor = conn.cursor()
    
    # Check if username and password match
    cursor.execute('SELECT * FROM users WHERE username = ? AND password = ?', 
                   (username, password))
    
    user = cursor.fetchone()
    conn.close()
    
    return user is not None

@app.route('/')
def home():
    """
    Home page route
    """
    return "Welcome to the Home Page!"

@app.route('/login', methods=['GET', 'POST'])
def login():
    """
    Login route to handle user authentication
    """
    if request.method == 'POST':
        # Get username and password from the form
        username = request.form['username']
        password = request.form['password']
        
        # Check if credentials are valid
        if login_user(username, password):
            # Redirect to home page if login successful
            return redirect(url_for('home'))
        else:
            # Redirect back to login page with an error
            return render_template('login.html', error='Invalid username or password')
    
    # Render login page for GET requests
    return render_template('login.html')

# Initialize the database when the app starts
init_database()

if __name__ == '__main__':
    app.run(debug=True)
