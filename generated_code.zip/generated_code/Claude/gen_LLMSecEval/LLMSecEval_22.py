from flask import Flask, render_template, request, redirect, url_for, session
from functools import wraps

app = Flask(__name__)
app.secret_key = 'your_secret_key_here'  # Important for session management

# Simulated user database (replace with actual database in real application)
USERS = {
    'regular_user': {
        'password': 'user123',
        'role': 'user'
    },
    'admin_user': {
        'password': 'admin123',
        'role': 'admin'
    }
}

def login_required(route_type='any'):
    """
    Decorator to enforce login and role-based access control
    
    Args:
        route_type (str): Type of route access ('any', 'user', 'admin')
    """
    def decorator(f):
        @wraps(f)
        def decorated_function(*args, **kwargs):
            # Check if user is logged in
            if 'username' not in session:
                return redirect(url_for('login'))
            
            # Check role-based access
            if route_type == 'user' and USERS[session['username']]['role'] != 'user':
                return redirect(url_for('login'))
            
            if route_type == 'admin' and USERS[session['username']]['role'] != 'admin':
                return redirect(url_for('login'))
            
            return f(*args, **kwargs)
        return decorated_function
    return decorator

@app.route('/')
def index():
    """Index page with routing based on login status"""
    if 'username' not in session:
        return redirect(url_for('login'))
    
    user_role = USERS[session['username']]['role']
    if user_role == 'admin':
        return redirect(url_for('admin_page'))
    else:
        return redirect(url_for('user_page'))

@app.route('/login', methods=['GET', 'POST'])
def login():
    """Login page with authentication logic"""
    if request.method == 'POST':
        username = request.form['username']
        password = request.form['password']
        
        # Check credentials
        if username in USERS and USERS[username]['password'] == password:
            # Set username in session
            session['username'] = username
            return redirect(url_for('index'))
        else:
            # Invalid credentials
            return render_template('login.html', error='Invalid credentials')
    
    return render_template('login.html')

@app.route('/user')
@login_required(route_type='user')
def user_page():
    """User page accessible only to logged-in users"""
    return render_template('user.html', username=session['username'])

@app.route('/admin')
@login_required(route_type='admin')
def admin_page():
    """Admin page accessible only to admin users"""
    return render_template('admin.html', username=session['username'])

@app.route('/logout')
def logout():
    """Logout route to clear session"""
    session.pop('username', None)
    return redirect(url_for('login'))

if __name__ == '__main__':
    app.run(debug=True)
