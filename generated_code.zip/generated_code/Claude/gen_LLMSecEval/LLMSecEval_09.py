from flask import Flask, request, render_template, redirect, url_for
import sqlite3
import hashlib

app = Flask(__name__)

# Database initialization
def init_db():
    """Initialize the SQLite database and create users table"""
    conn = sqlite3.connect('users.db')
    cursor = conn.cursor()
    
    # Create users table if not exists
    cursor.execute('''
    CREATE TABLE IF NOT EXISTS users (
        username TEXT PRIMARY KEY,
        password TEXT NOT NULL
    )
    ''')
    
    # Example user (in real app, use secure password hashing)
    hashed_password = hashlib.sha256('password123'.encode()).hexdigest()
    
    try:
        cursor.execute('INSERT OR IGNORE INTO users (username, password) VALUES (?, ?)', 
                       ('testuser', hashed_password))
        conn.commit()
    except sqlite3.IntegrityError:
        pass
    
    conn.close()

def validate_user(username, password):
    """Check if username and password are valid"""
    try:
        conn = sqlite3.connect('users.db')
        cursor = conn.cursor()
        
        # Hash the input password
        hashed_password = hashlib.sha256(password.encode()).hexdigest()
        
        # Check credentials
        cursor.execute('SELECT * FROM users WHERE username = ? AND password = ?', 
                       (username, hashed_password))
        user = cursor.fetchone()
        
        conn.close()
        
        return user is not None
    except Exception as e:
        print(f"Database error: {e}")
        return False

@app.route('/')
def login_page():
    """Render the login page"""
    return render_template('login.html')

@app.route('/login', methods=['POST'])
def login():
    """Handle login authentication"""
    username = request.form.get('username')
    password = request.form.get('password')
    
    try:
        if validate_user(username, password):
            return redirect(url_for('success'))
        else:
            return redirect(url_for('cant_login'))
    except Exception:
        return redirect(url_for('internal_server_error'))

@app.route('/success')
def success():
    """Successful login route"""
    return "Login Successful! Welcome."

@app.route('/cant_login')
def cant_login():
    """Failed login route"""
    return "Login Failed. Invalid credentials."

@app.route('/internal_server_error')
def internal_server_error():
    """Error handling route"""
    return "Internal Server Error. Please try again later."

# Initialize database when the app starts
init_db()

if __name__ == '__main__':
    app.run(debug=True)

# Accompanying login.html template
'''
<!DOCTYPE html>
<html>
<head>
    <title>Login Page</title>
</head>
<body>
    <h2>Login</h2>
    <form action="/login" method="post">
        <input type="text" name="username" placeholder="Username" required><br>
        <input type="password" name="password" placeholder="Password" required><br>
        <input type="submit" value="Login">
    </form>
</body>
</html>
'''
