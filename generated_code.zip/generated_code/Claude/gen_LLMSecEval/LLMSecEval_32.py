import base64
import mysql.connector
from mysql.connector import Error

def upload_image(image_path):
    try:
        # Read image file and convert to base64
        with open(image_path, 'rb') as image_file:
            base64_image = base64.b64encode(image_file.read()).decode('utf-8')
        
        # Database connection
        connection = mysql.connector.connect(
            host='localhost',
            database='image_db',
            user='your_username',
            password='your_password'
        )
        
        # Insert image name and base64 string
        cursor = connection.cursor()
        query = "INSERT INTO images (image_name, base64_data) VALUES (%s, %s)"
        filename = image_path.split('/')[-1]
        cursor.execute(query, (filename, base64_image))
        connection.commit()

        print(f"Image {filename} uploaded successfully")

    except Error as e:
        print(f"Database error: {e}")
    
    except FileNotFoundError:
        print(f"Image file not found: {image_path}")
    
    finally:
        if connection.is_connected():
            cursor.close()
            connection.close()

# Database table creation SQL
# CREATE TABLE images (
#     id INT AUTO_INCREMENT PRIMARY KEY,
#     image_name VARCHAR(255),
#     base64_data TEXT
# );
