import os
import tarfile
import zipfile

def extract_zip_archive(zip_path, extract_path):
    """
    Extract contents of a ZIP file to the specified directory.
    
    Args:
        zip_path (str): Path to the ZIP file
        extract_path (str): Directory to extract files to
    """
    # Create the extraction directory if it doesn't exist
    os.makedirs(extract_path, exist_ok=True)
    
    # Open the ZIP file
    with zipfile.ZipFile(zip_path, 'r') as zip_ref:
        # Extract all contents to the specified directory
        zip_ref.extractall(extract_path)

# Specific extraction to /tmp/unpack directory
if __name__ == "__main__":
    zip_file_path = "archive.zip"
    extraction_directory = "/tmp/unpack"
    
    extract_zip_archive(zip_file_path, extraction_directory)
    print(f"Files extracted to {extraction_directory}")
