import sqlite3
from flask import Flask, render_template, request, redirect, url_for

app = Flask(__name__)

# Database initialization function
def init_db():
    """Initialize the database and create messages table if not exists"""
    conn = sqlite3.connect('messages.db')
    cursor = conn.cursor()
    cursor.execute('''
        CREATE TABLE IF NOT EXISTS messages (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            username TEXT NOT NULL,
            message TEXT NOT NULL,
            timestamp DATETIME DEFAULT CURRENT_TIMESTAMP
        )
    ''')
    conn.commit()
    conn.close()

# Initialize database when the app starts
init_db()

def insert_user_message_in_db(username, message):
    """
    Insert a user's message into the database
    
    Args:
        username (str): The name of the user sending the message
        message (str): The content of the message
    """
    # Validate input
    if not username or not message:
        return False
    
    try:
        # Connect to the database
        conn = sqlite3.connect('messages.db')
        cursor = conn.cursor()
        
        # Insert the message
        cursor.execute(
            'INSERT INTO messages (username, message) VALUES (?, ?)', 
            (username, message)
        )
        
        # Commit the transaction
        conn.commit()
        
        return True
    
    except sqlite3.Error as e:
        print(f"Database error: {e}")
        return False
    finally:
        # Always close the connection
        conn.close()

def get_all_messages():
    """
    Retrieve all messages from the database
    
    Returns:
        list: A list of tuples containing message details
    """
    try:
        # Connect to the database
        conn = sqlite3.connect('messages.db')
        cursor = conn.cursor()
        
        # Fetch all messages, ordered by most recent first
        cursor.execute('''
            SELECT username, message, timestamp 
            FROM messages 
            ORDER BY timestamp DESC
        ''')
        
        # Fetch all results
        messages = cursor.fetchall()
        
        return messages
    
    except sqlite3.Error as e:
        print(f"Database error: {e}")
        return []
    finally:
        # Always close the connection
        conn.close()

@app.route('/')
def index():
    """
    Main page route that displays all messages
    """
    # Get all messages from the database
    messages = get_all_messages()
    
    # Render the template with messages
    return render_template('index.html', messages=messages)

@app.route('/post', methods=['POST'])
def post():
    """
    Handle message submission
    
    - Get username and message from form
    - Insert message into database
    - Redirect to main page
    """
    # Get form data
    username = request.form.get('username')
    message = request.form.get('message')
    
    # Insert message into database
    insert_user_message_in_db(username, message)
    
    # Redirect to main page
    return redirect(url_for('index'))

if __name__ == '__main__':
    app.run(debug=True)
