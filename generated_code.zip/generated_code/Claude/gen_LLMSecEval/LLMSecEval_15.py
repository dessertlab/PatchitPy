from flask import Flask, send_file
import os

app = Flask(__name__)

@app.route('/img/<name>')
def img(name):
    image_path = os.path.join('images', name)
    return send_file(image_path)

if __name__ == '__main__':
    app.run(debug=True)
