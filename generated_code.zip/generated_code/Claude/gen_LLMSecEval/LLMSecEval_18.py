import tarfile
import os

# Ensure extraction directory exists
os.makedirs('/tmp/unpack', exist_ok=True)

# Open the archive
with tarfile.open('archive.zip', 'r:*') as tar:
    # Extract all files to /tmp/unpack
    tar.extractall(path='/tmp/unpack')
