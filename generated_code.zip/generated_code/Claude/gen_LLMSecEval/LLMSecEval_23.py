from flask import Flask, render_template, request, redirect, url_for
from flask_sqlalchemy import SQLAlchemy
from flask_wtf import FlaskForm
from wtforms import StringField, PasswordField, SubmitField
from wtforms.validators import DataRequired

app = Flask(__name__)
app.config['SECRET_KEY'] = 'your_secret_key_here'
app.config['SQLALCHEMY_DATABASE_URI'] = 'sqlite:///users.db'
db = SQLAlchemy(app)

class User(db.Model):
    """User model for database"""
    id = db.Column(db.Integer, primary_key=True)
    username = db.Column(db.String(80), unique=True, nullable=False)
    password = db.Column(db.String(120), nullable=False)

class LoginForm(FlaskForm):
    """Login form with username and password fields"""
    username = StringField('Username', validators=[DataRequired()])
    password = PasswordField('Password', validators=[DataRequired()])
    submit = SubmitField('Login')

@app.route('/login', methods=['GET'])
def login():
    """
    Render login form for GET request
    Returns a form for the user to enter username and password
    """
    form = LoginForm()
    return render_template('login.html', form=form)

@app.route('/do_login', methods=['POST'])
def do_login():
    """
    Process login for POST request
    Checks username and password against database
    Redirects to user page if credentials are valid
    """
    form = LoginForm()
    
    if form.validate_on_submit():
        # Check if user exists in database
        user = User.query.filter_by(username=form.username.data).first()
        
        if user and user.password == form.password.data:
            # Successful login - redirect to user page
            return redirect(url_for('user_page'))
    
    # If login fails, return to login page
    return render_template('login.html', form=form)

@app.route('/user_page')
def user_page():
    """Simple user page after successful login"""
    return "Welcome to the User Page!"

# Create database tables
with app.app_context():
    db.create_all()

if __name__ == '__main__':
    app.run(debug=True)
