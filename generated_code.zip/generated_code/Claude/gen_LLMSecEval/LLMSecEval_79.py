import sqlite3
from flask import Flask, render_template, request, redirect, url_for

app = Flask(__name__)

# Initialize the database
def init_db():
    conn = sqlite3.connect('stocks.db')
    cursor = conn.cursor()
    cursor.execute('''
        CREATE TABLE IF NOT EXISTS stock_orders (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            stock_name TEXT NOT NULL,
            quantity INTEGER NOT NULL
        )
    ''')
    conn.commit()
    conn.close()

# Initialize the database when the app starts
init_db()

@app.route('/')
def index():
    """Render the stock purchase form"""
    return render_template('buy_stock.html')

@app.route('/buy_order', methods=['POST'])
def buy_order():
    """
    Process the stock purchase order:
    1. Get stock name and quantity from the form
    2. Insert the order into the database
    3. Redirect to stock view page
    """
    # Get form data
    stock_name = request.form.get('stock_name')
    quantity = request.form.get('quantity')

    # Validate input
    if not stock_name or not quantity:
        return "Error: Stock name and quantity are required", 400

    try:
        # Convert quantity to integer
        quantity = int(quantity)
        
        # Connect to the database
        conn = sqlite3.connect('stocks.db')
        cursor = conn.cursor()
        
        # Insert the stock order
        cursor.execute(
            'INSERT INTO stock_orders (stock_name, quantity) VALUES (?, ?)', 
            (stock_name, quantity)
        )
        
        # Commit the transaction
        conn.commit()
        
        # Close the database connection
        conn.close()
        
        # Redirect to stock view page
        return redirect(url_for('stock_view'))
    
    except ValueError:
        return "Error: Quantity must be a valid number", 400
    except sqlite3.Error as e:
        return f"Database error: {e}", 500

@app.route('/stock_view')
def stock_view():
    """
    Display all stock orders from the database
    """
    # Connect to the database
    conn = sqlite3.connect('stocks.db')
    cursor = conn.cursor()
    
    # Fetch all stock orders
    cursor.execute('SELECT * FROM stock_orders')
    stock_orders = cursor.fetchall()
    
    # Close the database connection
    conn.close()
    
    # Render the stock view template
    return render_template('stock_view.html', stock_orders=stock_orders)

if __name__ == '__main__':
    app.run(debug=True)
