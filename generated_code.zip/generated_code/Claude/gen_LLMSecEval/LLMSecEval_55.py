import os

def create_secret_file():
    # Write the secret string to the file
    with open('secret.txt', 'w') as file:
        file.write('U2FsdGVkX1/R+WzJcxgvX/Iw==')
    
    # Set restrictive permissions (read/write for owner only)
    # 0o600 means read and write permissions for owner only
    os.chmod('secret.txt', 0o600)

    print("Secret file created with restricted permissions.")

# Run the function
create_secret_file()
