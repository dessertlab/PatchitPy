from flask import Flask, render_template, request, redirect, url_for
import sqlite3

app = Flask(__name__)

def init_database():
    """
    Initialize the SQLite database and create users table
    """
    conn = sqlite3.connect('users.db')
    cursor = conn.cursor()
    
    # Create users table
    cursor.execute('''
        CREATE TABLE IF NOT EXISTS users (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            username TEXT UNIQUE NOT NULL,
            password TEXT NOT NULL
        )
    ''')
    
    # Insert a default user for testing
    try:
        cursor.execute('INSERT INTO users (username, password) VALUES (?, ?)', 
                       ('testuser', 'password123'))
        conn.commit()
    except sqlite3.IntegrityError:
        # User already exists
        pass
    
    conn.close()

def login(username, password):
    """
    Authenticate user login
    
    :param username: User's username
    :param password: User's password
    :return: Tuple (success, message)
    """
    # Connect to the database
    conn = sqlite3.connect('users.db')
    cursor = conn.cursor()
    
    try:
        # Check if username exists
        cursor.execute('SELECT password FROM users WHERE username = ?', (username,))
        result = cursor.fetchone()
        
        # If username doesn't exist
        if result is None:
            return False, "Username not found"
        
        # Check if password is correct
        stored_password = result[0]
        if stored_password == password:
            return True, "Login successful"
        else:
            return False, "Incorrect password"
    
    except sqlite3.Error as e:
        # Handle any database errors
        return False, f"Database error: {str(e)}"
    
    finally:
        # Always close the database connection
        conn.close()

@app.route('/')
def home():
    """
    Home page route
    """
    return "Welcome to the Home Page!"

@app.route('/login', methods=['GET', 'POST'])
def login_route():
    """
    Login route to handle user authentication
    """
    if request.method == 'POST':
        # Get username and password from the form
        username = request.form['username']
        password = request.form['password']
        
        # Attempt to log in
        success, message = login(username, password)
        
        if success:
            # Redirect to home page if login successful
            return redirect(url_for('home'))
        else:
            # Render login page with error message
            return render_template('login.html', error=message)
    
    # Render login page for GET requests
    return render_template('login.html')

# Initialize the database when the app starts
init_database()

if __name__ == '__main__':
    app.run(debug=True)
