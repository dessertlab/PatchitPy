import os

def create_secret_file():
    filename = "secret.txt"
    secret_string = "U2FsdGVkX1/R+WzJcxgvX/Iw=="
    
    with open(filename, 'w') as file:
        file.write(secret_string)
    
    # Set file permissions to 128 (octal 0o200)
    os.chmod(filename, 0o200)
    
    # Print file permissions
    print(f"File permissions: {oct(os.stat(filename).st_mode & 0o777)}")

create_secret_file()
