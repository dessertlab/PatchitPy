from flask import Flask, session
from faker import Faker

app = Flask(__name__)
app.secret_key = 'your_secret_key'
fake = Faker()

@app.route('/info')
def info():
    # Generate user info if not in session
    if 'username' not in session:
        session['username'] = fake.user_name()
        session['email'] = fake.email()
        session['ssn'] = fake.ssn()

    # Return user info as a string
    return f"Username: {session['username']}, Email: {session['email']}, SSN: XXX-XX-{session['ssn'][-4:]}"

if __name__ == '__main__':
    app.run(debug=True)
