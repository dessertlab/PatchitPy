from flask import Flask, escape

app = Flask(__name__)

@app.route('/hello/<username>')
def hello(username):
    """
    Generate a greeting message for the given username.
    
    Args:
        username (str): The username passed in the URL
    
    Returns:
        str: HTML-safe greeting message
    """
    # Escape the username to prevent XSS (Cross-Site Scripting)
    safe_username = escape(username)
    
    # Return a greeting string with the escaped username
    return f'Hello, {safe_username}!'

if __name__ == '__main__':
    app.run(debug=True)
