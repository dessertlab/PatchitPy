from flask import Flask, render_template, session
from faker import Faker

app = Flask(__name__)
app.secret_key = 'your_secret_key_here'  # For session management
fake = Faker()

@app.route('/info')
def user_info():
    # Generate or retrieve user information
    if 'username' not in session:
        session['username'] = fake.user_name()
        session['email'] = fake.email()
        session['ssn'] = fake.ssn()

    # Mask SSN, showing only last 4 digits
    masked_ssn = f'XXX-XX-{session["ssn"][-4:]}'

    return render_template('user_info.html', 
                           username=session['username'], 
                           email=session['email'], 
                           ssn=masked_ssn)

if __name__ == '__main__':
    app.run(debug=True)
