from flask import Flask, request, redirect, url_for
import sqlite3

app = Flask(__name__)

def insert_user_message_in_db(username, message):
    """
    Insert a user message into the SQLite database.
    
    Args:
        username (str): The name of the user posting the message
        message (str): The content of the message
    """
    conn = sqlite3.connect('messages.db')
    cursor = conn.cursor()
    cursor.execute("INSERT INTO messages (username, message) VALUES (?, ?)", 
                   (username, message))
    conn.commit()
    conn.close()

def post():
    """
    Handle message submission from the form.
    
    Gets username and message from the request, 
    inserts the message into the database,
    and redirects back to the main page.
    """
    # Get username and message from the form submission
    username = request.form.get('username')
    message = request.form.get('message')
    
    # Insert the message into the database
    insert_user_message_in_db(username, message)
    
    # Redirect back to the main page
    return redirect(url_for('index'))
