import os
import sqlite3
import hashlib

class UserRegistration:
    def __init__(self, db_name='users.db'):
        self.conn = sqlite3.connect(db_name)
        self.cursor = self.conn.cursor()
        self.create_table()

    def create_table(self):
        """Create users table with username and password columns."""
        self.cursor.execute('''
            CREATE TABLE IF NOT EXISTS users (
                username TEXT PRIMARY KEY,
                password_hash TEXT NOT NULL
            )
        ''')
        self.conn.commit()

    def hash_password(self, password):
        """Generate salt and hash password."""
        # Generate 16-byte random salt
        salt = os.urandom(16)
        
        # Hash password with salt using SHA-256
        password_bytes = password.encode('utf-8')
        salted_password = salt + password_bytes
        hashed_password = hashlib.sha256(salted_password).hexdigest()
        
        # Combine salt and hashed password
        return salt + bytes.fromhex(hashed_password)

    def register_user(self, username, password):
        """Register new user."""
        try:
            # Hash password with salt
            password_hash = self.hash_password(password)
            
            # Store in database
            self.cursor.execute(
                "INSERT INTO users (username, password_hash) VALUES (?, ?)", 
                (username, password_hash)
            )
            self.conn.commit()
            return True
        except sqlite3.IntegrityError:
            return False

    def verify_password(self, username, password):
        """Verify user credentials."""
        self.cursor.execute(
            "SELECT password_hash FROM users WHERE username = ?", 
            (username,)
        )
        result = self.cursor.fetchone()
        
        if not result:
            return False
        
        # Extract salt and stored hash
        stored_hash = result[0]
        salt = stored_hash[:16]
        
        # Recreate hash
        password_bytes = password.encode('utf-8')
        salted_password = salt + password_bytes
        input_hash = hashlib.sha256(salted_password).hexdigest()
        
        return input_hash == stored_hash[16:].hex()

# Example usage
def main():
    reg = UserRegistration()
    
    # Register user
    username = input("Username: ")
    password = input("Password: ")
    
    if reg.register_user(username, password):
        print("Registration successful!")
    else:
        print("Registration failed.")

    # Verify login
    login_user = input("Login username: ")
    login_pass = input("Login password: ")
    
    if reg.verify_password(login_user, login_pass):
        print("Login successful!")
    else:
        print("Login failed.")

if __name__ == "__main__":
    main()
