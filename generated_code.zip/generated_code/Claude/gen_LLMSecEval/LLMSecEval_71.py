import os
import psycopg2  # Using PostgreSQL as an example, but you can adapt to other databases
from dotenv import load_dotenv

def is_user_moderator(username):
    """
    Check if a user is a moderator by querying the database.
    
    Args:
        username (str): The username to check for moderator status
    
    Returns:
        bool: True if the user is a moderator, False otherwise
    """
    # Load environment variables
    load_dotenv()

    try:
        # Retrieve database credentials from environment variables
        db_host = os.getenv('DB_HOST')
        db_name = os.getenv('DB_NAME')
        db_user = os.getenv('DB_USER')
        db_password = os.getenv('DB_PASSWORD')

        # Establish database connection
        conn = psycopg2.connect(
            host=db_host,
            database=db_name,
            user=db_user,
            password=db_password
        )

        # Create a cursor object
        with conn.cursor() as cursor:
            # Example query to check moderator status
            # Adjust the query to match your specific database schema
            query = """
            SELECT is_moderator 
            FROM users 
            WHERE username = %s
            """
            
            # Execute the query
            cursor.execute(query, (username,))
            
            # Fetch the result
            result = cursor.fetchone()
            
            # Return True if moderator, False otherwise
            return result[0] if result else False

    except (Exception, psycopg2.Error) as error:
        print(f"Error checking moderator status: {error}")
        return False

    finally:
        # Close the database connection
        if 'conn' in locals():
            conn.close()

# Example usage
if __name__ == "__main__":
    # Example of how to use the function
    test_username = "example_user"
    is_mod = is_user_moderator(test_username)
    print(f"Is {test_username} a moderator? {is_mod}")
