import os
import psycopg2
from flask import Flask, request, redirect, url_for, session
from dotenv import load_dotenv

# Load environment variables
load_dotenv()

# Create Flask application
app = Flask(__name__)
app.secret_key = os.getenv('SECRET_KEY', 'your_secret_key')

def insert_buy_order(username, stock_name, stock_quantity):
    """
    Insert buy order into the database.
    
    Args:
        username (str): Username of the buyer
        stock_name (str): Stock symbol
        stock_quantity (int): Number of stocks to purchase
    
    Returns:
        bool: True if insertion successful, False otherwise
    """
    try:
        # Establish database connection
        conn = psycopg2.connect(
            host=os.getenv('DB_HOST'),
            database=os.getenv('DB_NAME'),
            user=os.getenv('DB_USER'),
            password=os.getenv('DB_PASSWORD')
        )
        
        # Create a cursor object
        with conn.cursor() as cursor:
            # Get user ID based on username
            user_query = "SELECT id FROM users WHERE username = %s"
            cursor.execute(user_query, (username,))
            user_result = cursor.fetchone()
            
            if not user_result:
                print(f"User {username} not found")
                return False
            
            user_id = user_result[0]
            
            # Fetch current stock price (simplified - you might want to use a real-time price API)
            price_query = "SELECT current_price FROM stocks WHERE symbol = %s"
            cursor.execute(price_query, (stock_name,))
            price_result = cursor.fetchone()
            
            if not price_result:
                print(f"Stock {stock_name} not found")
                return False
            
            current_price = price_result[0]
            total_cost = current_price * stock_quantity
            
            # Insert buy order
            insert_query = """
            INSERT INTO stock_orders (
                user_id, 
                stock_symbol, 
                quantity, 
                price_per_share, 
                total_cost, 
                order_type
            ) VALUES (%s, %s, %s, %s, %s, 'BUY')
            """
            
            cursor.execute(insert_query, (
                user_id, 
                stock_name, 
                stock_quantity, 
                current_price, 
                total_cost
            ))
            
            # Commit the transaction
            conn.commit()
            
            return True
    
    except (Exception, psycopg2.Error) as error:
        print(f"Error processing buy order: {error}")
        return False
    
    finally:
        # Close the database connection
        if 'conn' in locals():
            conn.close()

@app.route('/process_buy', methods=['POST'])
def process_buy():
    """
    Process stock buy order and redirect to profile page.
    
    Returns:
        Redirect to profile page
    """
    # Check if user is logged in
    if 'username' not in session:
        # Redirect to login page if not logged in
        return redirect(url_for('login'))
    
    # Get form data
    stock_name = request.form.get('stock_name')
    stock_quantity = request.form.get('stock_quantity')
    username = session['username']
    
    # Validate inputs
    try:
        stock_quantity = int(stock_quantity)
        if stock_quantity <= 0:
            raise ValueError("Quantity must be positive")
    except ValueError:
        # Handle invalid quantity
        # You might want to add a flash message here
        return redirect(url_for('buy_stock_page'))
    
    # Insert buy order
    if insert_buy_order(username, stock_name, stock_quantity):
        # Successful purchase
        # You might want to add a success flash message
        return redirect(url_for('profile'))
    else:
        # Failed purchase
        # You might want to add an error flash message
        return redirect(url_for('buy_stock_page'))

# Sample HTML Template for Buy Stock Page
"""
<!DOCTYPE html>
<html>
<head>
    <title>Buy Stock</title>
</head>
<body>
    <h1>Buy Stock</h1>
    <form action="/process_buy" method="POST">
        <label for="stock_name">Stock Symbol:</label>
        <input type="text" id="stock_name" name="stock_name" required>
        
        <label for="stock_quantity">Quantity:</label>
        <input type="number" id="stock_quantity" name="stock_quantity" min="1" required>
        
        <button type="submit">Buy Stock</button>
    </form>
</body>
</html>
"""

# Database Setup SQL (for reference)
"""
CREATE TABLE users (
    id SERIAL PRIMARY KEY,
    username VARCHAR(50) UNIQUE NOT NULL
);

CREATE TABLE stocks (
    id SERIAL PRIMARY KEY,
    symbol VARCHAR(10) UNIQUE NOT NULL,
    current_price DECIMAL(10,2) NOT NULL
);

CREATE TABLE stock_orders (
    id SERIAL PRIMARY KEY,
    user_id INTEGER NOT NULL,
    stock_symbol VARCHAR(10) NOT NULL,
    quantity INTEGER NOT NULL,
    price_per_share DECIMAL(10,2) NOT NULL,
    total_cost DECIMAL(10,2) NOT NULL,
    order_type VARCHAR(10) NOT NULL,
    order_date TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (user_id) REFERENCES users(id)
);
"""

if __name__ == '__main__':
    app.run(debug=True)
