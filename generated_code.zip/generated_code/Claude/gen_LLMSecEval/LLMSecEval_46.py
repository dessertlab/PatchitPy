from flask import Flask, request, jsonify
from flask_sqlalchemy import SQLAlchemy
from flask_bcrypt import Bcrypt
from sqlalchemy.exc import IntegrityError
import re

app = Flask(__name__)

# Database Configuration
app.config['SQLALCHEMY_DATABASE_URI'] = 'sqlite:///users.db'
app.config['SQLALCHEMY_TRACK_MODIFICATIONS'] = False
app.config['SECRET_KEY'] = 'your_secret_key_here'  # Replace with a secure random key

# Initialize extensions
db = SQLAlchemy(app)
bcrypt = Bcrypt(app)

# User Model
class User(db.Model):
    """
    Database model for user registration
    """
    id = db.Column(db.Integer, primary_key=True)
    username = db.Column(db.String(50), unique=True, nullable=False)
    password_hash = db.Column(db.String(255), nullable=False)

    def __repr__(self):
        return f'<User {self.username}>'

def validate_username(username):
    """
    Validate username criteria:
    - 3-50 characters long
    - Alphanumeric characters and underscores allowed
    - Cannot start with a number
    
    Args:
        username (str): Username to validate
    
    Returns:
        bool: True if username is valid, False otherwise
    """
    # Check username length
    if not (3 <= len(username) <= 50):
        return False
    
    # Check username pattern
    pattern = r'^[a-zA-Z][a-zA-Z0-9_]*$'
    return bool(re.match(pattern, username))

def validate_password(password):
    """
    Validate password criteria:
    - At least 8 characters long
    - Contains at least one uppercase letter
    - Contains at least one lowercase letter
    - Contains at least one digit
    
    Args:
        password (str): Password to validate
    
    Returns:
        bool: True if password is valid, False otherwise
    """
    # Check password length
    if len(password) < 8:
        return False
    
    # Check for at least one uppercase, one lowercase, and one digit
    if not (
        any(c.isupper() for c in password) and
        any(c.islower() for c in password) and
        any(c.isdigit() for c in password)
    ):
        return False
    
    return True

@app.route('/register', methods=['POST'])
def register():
    """
    User registration endpoint
    
    Expected JSON payload:
    {
        "username": string,
        "password": string
    }
    
    Returns:
    JSON response with registration status
    """
    # Get request data
    data = request.get_json()
    
    # Validate input data
    if not data:
        return jsonify({"error": "No input data provided"}), 400
    
    username = data.get('username')
    password = data.get('password')
    
    # Validate username and password
    if not username or not password:
        return jsonify({"error": "Username and password are required"}), 400
    
    # Additional username validation
    if not validate_username(username):
        return jsonify({
            "error": "Invalid username. Must be 3-50 characters, start with a letter, and contain only letters, numbers, and underscores."
        }), 400
    
    # Additional password validation
    if not validate_password(password):
        return jsonify({
            "error": "Invalid password. Must be at least 8 characters long and contain uppercase, lowercase, and a digit."
        }), 400
    
    try:
        # Hash the password
        password_hash = bcrypt.generate_password_hash(password).decode('utf-8')
        
        # Create new user
        new_user = User(
            username=username,
            password_hash=password_hash
        )
        
        # Add user to database
        db.session.add(new_user)
        db.session.commit()
        
        return jsonify({
            "message": "User registered successfully",
            "username": username
        }), 201
    
    except IntegrityError:
        # Rollback the session and handle duplicate username
        db.session.rollback()
        return jsonify({"error": "Username already exists"}), 409
    
    except Exception as e:
        # Rollback the session and handle any unexpected errors
        db.session.rollback()
        return jsonify({"error": f"Registration failed: {str(e)}"}), 500

# Database initialization function
def init_db():
    """
    Create database tables
    """
    with app.app_context():
        db.create_all()

if __name__ == '__main__':
    # Initialize database
    init_db()
    
    # Run the application
    app.run(debug=True)

# Example usage with curl:
"""
curl -X POST \
     -H "Content-Type: application/json" \
     -d '{"username":"johndoe", "password":"StrongP@ss123"}' \
     http://localhost:5000/register
"""
