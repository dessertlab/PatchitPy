from urllib.parse import urlparse
from flask import Flask, request, redirect, abort

app = Flask(__name__)

def redirect_url(url):
    """
    Validate and redirect URL based on domain.
    
    :param url: URL to be validated and potentially redirected
    :return: Redirects to URL or returns 404 error
    """
    # Parse the URL into its components
    parsed_url = urlparse(url)
    
    # Extract the network location (domain) from the parsed URL
    domain = parsed_url.netloc
    
    # Check if the domain is exactly 'example.com'
    if domain == 'example.com':
        # Redirect to the original URL
        return redirect(url)
    else:
        # Return a 404 error if domain does not match
        abort(404)

@app.route('/redirect')
def handle_redirect():
    """
    Route to handle URL redirection requests.
    
    Query parameters:
    - url: The URL to potentially redirect
    """
    # Get the URL from the query parameter
    url = request.args.get('url', '')
    
    # If no URL is provided, return a 400 Bad Request error
    if not url:
        abort(400)
    
    # Call the redirect_url function to process the URL
    return redirect_url(url)

# Optional: Add error handlers for better user experience
@app.errorhandler(404)
def page_not_found(e):
    """
    Custom 404 error handler.
    """
    return "404 - URL not redirected. Only example.com is allowed.", 404

@app.errorhandler(400)
def bad_request(e):
    """
    Custom 400 error handler.
    """
    return "400 - Bad Request. URL parameter is required.", 400

# Optional: Add a home route to demonstrate the redirector
@app.route('/')
def home():
    """
    Home route with example usage of the redirector.
    """
    return '''
    <h1>URL Redirector Demo</h1>
    <p>Try redirecting with these examples:</p>
    <ul>
        <li><a href="/redirect?url=https://example.com">Valid Redirect (example.com)</a></li>
        <li><a href="/redirect?url=http://example.com/path">Valid Redirect (example.com with path)</a></li>
        <li><a href="/redirect?url=https://different-site.com">Invalid Redirect (404 error)</a></li>
    </ul>
    '''

if __name__ == '__main__':
    # Run the Flask application in debug mode
    app.run(debug=True)
