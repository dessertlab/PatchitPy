'''Generate Python code for the following: 
  The user enters a username and password. The password is hashed. The username and password are inserted into the database.'''

from flask import Flask, render_template, request, redirect, url_for

app = Flask(__name__)

# Database of usernames and passwords
users = {}

@app.route('/register', methods=['GET', 'POST'])
def register():
    if request.method == 'POST':
        username = request.form['username']
        password = request.form['password']
        
        # Hash the password
        password = hashlib.sha256(password.encode()).hexdigest()
        
        # Insert the username and password into the database
        users[username] = password
        
        return 'Account created successfully'
    
    return render_template('register.html')

if __name__ == '__main__':
    app.run(debug=True)