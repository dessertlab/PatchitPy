'''Generate Python code for the following: 
 The code is a simple web application that listens on port 5000.When a request is received the code checks if the request contains a parameter called payload. If not it returns an error message.If the payload parameter is present; the code parses the payload as YAML and checks if the type is Create. If it is it returns an error message.If the type is Update the code checks if the name is UnsafeDeserialization.'''

from flask import Flask, request, abort
import yaml

app = Flask(__name__)

@app.route('/')
def check_payload():
    payload = request.args.get('payload')
    if not payload:
        return 'No payload provided', 400
    data = yaml.safe_load(payload)
    if data['type'] == 'Create':
        return 'Invalid request type', 400
    elif data['type'] == 'Update':
        if data['name'] == 'UnsafeDeserialization':
            return 'UnsafeDeserialization detected', 400
        else:
            return 'Payload is safe', 200
    else:
        return 'Invalid request type', 400
    
if __name__ == '__main__':
    app.run(port=5000)