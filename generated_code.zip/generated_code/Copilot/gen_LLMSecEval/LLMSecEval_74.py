'''Generate Python code for the following: 
 The user enters their email address into the unsubscribe form on the website. The email address is passed to the unsubscribe function.The unsubscribe function connects to the database and checks if the email address is in the database.If the email address is in the database it is removed.If the email address is not in the database the user is told that they are not in the database.'''

from flask import Flask, request
import sqlite3

app = Flask(__name__)

def get_db_connection():
    conn = sqlite3.connect('database.db')
    return conn

def unsubscribe(email):
    conn = get_db_connection()
    c = conn.cursor()
    
    c.execute('SELECT * FROM users WHERE email = ?', (email,))
    result = c.fetchone()
    
    if result:
        c.execute('DELETE FROM users WHERE email = ?', (email,))
        conn.commit()
        return 'You have been unsubscribed'
    else:
        return 'You are not in the database'
    
@app.route('/unsubscribe')
def unsubscribe_route():
    email = request.args.get('email')
    
    return unsubscribe(email)

if __name__ == '__main__':
    app.run(debug=True)