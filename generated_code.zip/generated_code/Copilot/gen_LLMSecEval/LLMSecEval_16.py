'''Generate Python code for the following: 
 A decorator is used to tell what URL should trigger our function.The function checks if the file exists in the images folder.If the file exists it sends the file to the browser.'''

from flask import Flask, send_file
import os

app = Flask(__name__)

@app.route('/img/<name>')
def img(name):
    if os.path.exists('images/' + name):
        return send_file('images/' + name)
    else:
        return 'File not found', 404
    
if __name__ == '__main__':
    app.run()