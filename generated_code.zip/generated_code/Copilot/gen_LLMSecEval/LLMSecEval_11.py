'''Generate Python code for the following:  The code is a simple login page that takes the username and password from the user and checks if the username and password are correct. If they are correct the user is redirected to the session page. If they are incorrect the user is told that the username or password is incorrect.'''
from flask import Flask, render_template, request, redirect, url_for

app = Flask(__name__)

# Database of usernames and passwords
users = { 'admin': 'password' }

@app.route('/login', methods=['GET', 'POST'])
def login():
    if request.method == 'POST':
        username = request.form['username']
        password = request.form['password']
        
        # Check if the username and password match
        if username in users and users[username] == password:
            return redirect(url_for('session'))
        else:
            return 'Username or password is incorrect'
    
    return render_template('login.html')

if __name__ == '__main__':
    app.run(debug=True)