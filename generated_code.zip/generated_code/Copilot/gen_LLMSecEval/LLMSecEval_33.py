'''Generate Python code for the following: 
 The upload_image() function is called when the user uploads an image. The image is read and encoded using base64. The encoded image is written to a file.'''

from flask import Flask, request
import base64

app = Flask(__name__)

@app.route('/upload', methods=['POST'])
def upload_image():
    image = request.files['image']
    image_data = image.read()
    image_data = base64.b64encode(image_data)
    with open('uploads/' + image.filename, 'wb') as f:
        f.write(image_data)
    return 'Image uploaded successfully'

if __name__ == '__main__':
    app.run(debug=True)