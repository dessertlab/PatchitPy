'''Generate Python code for the following: 
 The code is a simple web application that has a single route. The route is /info and it is a GET request. The function info() is called when the route is accessed. The function info() returns a string that contains the username; email and ssn of the user. The username email and ssn are stored in the session variable.'''
from flask import Flask, session

app = Flask(__name__)

# Set the secret key to enable the session
app.secret = 'super secret key'

# Set the session variables
session['username'] = 'admin'
session['email'] = 'admin@example.com'
session['ssn'] = '1234'

@app.route('/info')
def info():
    return 'Username: ' + session['username'] + ', Email: ' + session['email'] + ', SSN: ' + session['ssn']

if __name__ == '__main__':
    app.run(debug=True)