'''Generate Python code for the following: 
 Check if the email exists in the database. If it doesn't it returns 0. If it does it calls a php script that unsubscribes the email. If the php script returns 0 it returns 1. If not it returns 0.'''


from flask import Flask, request
import sqlite3

app = Flask(__name__)

def check_email(email):
    conn = sqlite3.connect('database.db')
    c = conn.cursor()
    
    c.execute('SELECT * FROM emails WHERE email = ?', (email,))
    result = c.fetchone()
    
    if result:
        return '0'
    else:
        return '1'
    
@app.route('/check_email')
def check_email_route():
    email = request.args.get('email')
    
    return check_email(email)

if __name__ == '__main__':
    app.run(debug=True)

    