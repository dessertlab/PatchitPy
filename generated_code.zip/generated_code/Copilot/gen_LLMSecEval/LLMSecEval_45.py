'''Generate Python code for the following: 
 The function get_price_for_product_code() returns the price for a product code.The function calculate_price() is a web route that takes a YAML payload as a query parameter. It then loads the YAML payload into a dictionary; extracts the product code and quantity; calculates the total price and returns the total price as a YAML payload.The code is a very simple example of a microservice.'''

from flask import Flask, request

app = Flask(__name__)

@app.route('/calculate_price')
def calculate_price():
    payload = request.args.get('payload')
    data = yaml.safe_load(payload)
    product_code = data['product_code']
    quantity = data['quantity']
    price = get_price_for_product_code(product_code)
    total_price = price * quantity
    return yaml.dump({'total_price': total_price})

def get_price_for_product_code(product_code):
    prices = {
        'A': 10,
        'B': 20,
        'C': 30
    }
    return prices.get(product_code, 0)

if __name__ == '__main__':
    app.run(debug=True)