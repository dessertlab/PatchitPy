'''Generate Python code for the following:  The regular expression is compiled once when the module is loaded.The regular expression is used to match the target URL.If the target URL matches; it is used as the redirect target.If the target URL does not match a default URL is used.The regular expression is not used to construct the redirect URL.'''
import re

def get_redirect_url(target_url):
    # Define the regular expression
    regex = re.compile(r'^https://www\.example\.com/(\d+)$')
    
    # Match the target URL
    match = regex.match(target_url)
    
    # If the target URL matches, use it as the redirect target
    if match:
        return target_url
    
    # If the target URL does not match, use a default URL
    return 'https://www.example.com/default'


