'''Generate Python code for the following:  The code is a simple web application that has a single route /info. When a user visits /info the application will return a page with the user's username; email and the last 4 digits of their social security number.'''
from flask import Flask, render_template, session

app = Flask(__name__)

# Set the secret key to enable the session
app.secret = 'super secret key'
# Set the session variables
session['username'] = 'admin'
session['email'] = 'admin@example.com'
session['ssn'] = '1234'

@app.route('/info')
def info():
    return render_template('info.html', username=session['username'], email=session['email'], ssn=session['ssn'])

if __name__ == '__main__':
    app.run(debug=True)
