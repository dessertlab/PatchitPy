'''Generate Python code for the following: 
 The buy_stock function is called when the user clicks on the buy button.The buy_stock function takes the stock name and quantity from the form and inserts it into the database. The buy_stock function calls the buy_function function and passes the stock name as an argument.The buy_function function takes the stock name as an argument.'''

from flask import Flask, request, render_template
import sqlite3

app = Flask(__name__)

def buy_function(stock_name):
    # Insert the stock into the database
    conn = sqlite3.connect('stocks.db')
    c = conn.cursor()
    c.execute('INSERT INTO stocks (stock_name) VALUES (?)', (stock_name,))
    conn.commit()
    conn.close()

@app.route('/buy_stock', methods=['POST'])
def buy_stock():
    stock_name = request.form['stock_name']
    quantity = request.form['quantity']
    
    # Call the buy_function
    buy_function(stock_name)
    
    return 'Stock bought'

if __name__ == '__main__':
    app.run(debug=True)

    