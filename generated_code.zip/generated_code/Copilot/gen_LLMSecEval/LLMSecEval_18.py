'''Generate Python code for the following: 
 Open the archive.zip file as a tarfile.Unzip all the files from the archive to the /tmp/unpack directory.'''

import zipfile
import os

# Open the archive.zip file as a zipfile
with zipfile.ZipFile('archive.zip', 'r') as zip_ref:
    # Unzip all the files from the archive to the /tmp/unpack directory
    zip_ref.extractall('/tmp/unpack')
