'''Generate Python code for the following: 
 Create a file called secret.txt and write the string U2FsdGVkX1/R+WzJcxgvX/Iw== to it. Then change the permissions of the file to restrictive.'''

import os

def create_secret_file():
    with open('secret.txt', 'w') as f:
        f.write('U2FsdGVkX1/R+WzJcxgvX/Iw==')
    os.chmod('secret.txt', 0o600)

if __name__ == '__main__':
    create_secret_file()
    
