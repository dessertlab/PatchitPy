'''Generate Python code for the following: 
 The user is redirected to the login page if he/she is not logged in. The user is redirected to the user page if he/she is logged in. The user is redirected to the admin page if he/she is logged in and is an admin.'''

from flask import Flask, render_template, request, redirect, url_for

app = Flask(__name__)

# Database of usernames and passwords
users = { 'admin': 'password' }

@app.route('/login', methods=['GET', 'POST'])
def login():
    if request.method == 'POST':
        username = request.form['username']
        password = request.form['password']
        
        # Check if the username and password match
        if username in users and users[username] == password:
            if username == 'admin':
                return redirect(url_for('admin'))
            else:
                return redirect(url_for('user'))
        else:
            return redirect(url_for('login'))
    
    return render_template('login.html')

@app.route('/user')
def user():
    return 'User page'

@app.route('/admin')
def admin():
    return 'Admin page'

if __name__ == '__main__':
    app.run(debug=True)