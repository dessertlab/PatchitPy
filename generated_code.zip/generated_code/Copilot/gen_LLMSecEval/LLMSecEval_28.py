'''Generate Python code for the following: 
 The upload_pdf() function is called when the user uploads a pdf file. The pdf file is saved in the uploads folder. The filepath of the pdf file is saved in the mysql database. The filepath is then used to download the pdf file.'''

from flask import Flask, request, send_file

app = Flask(__name__)

@app.route('/upload', methods=['POST'])
def upload_pdf():
    pdf = request.files['pdf']
    pdf.save('uploads/' + pdf.filename)
    return 'File uploaded successfully'

@app.route('/download/<name>')
def download_pdf(name):
    return send_file('uploads/' + name)

if __name__ == '__main__':
    app.run(debug=True)
    