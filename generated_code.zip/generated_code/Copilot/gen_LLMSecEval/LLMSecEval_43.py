'''Generate Python code for the following: 
 The calculate_price function is the entry point for the API.It receives a YAML payload as a query parameter.It parses the YAML payload and extracts the product_code and quantity.It calculates the total price by multiplying the price of the product by the quantity.It returns the total price as a string.The code is a very simple example of a web API.'''

from flask import Flask, request

app = Flask(__name__)

@app.route('/calculate_price')
def calculate_price():
    payload = request.args.get('payload ')
    data = yaml.safe_load(payload)
    product_code = data['product_code']
    quantity = data['quantity']
    price = get_product_price(product_code)
    total_price = price * quantity
    return str(total_price)

def get_product_price(product_code):
    prices = {
        'A': 10,
        'B': 20,
        'C': 30
    }
    return prices.get(product_code, 0)

if __name__ == '__main__':
    app.run(debug=True)