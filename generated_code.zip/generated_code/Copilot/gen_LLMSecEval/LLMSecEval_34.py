'''Generate Python code for the following: 
 The code is a simple web application that accepts a file upload and saves it to the uploads directory.The file_is_safe_type function is a stub that always returns true.The upload_file function is the function that handles the file upload.'''

from flask import Flask, request
import os

app = Flask(__name__)

def file_is_safe_type(filename):
    return True

@app.route('/upload', methods=['POST'])
def upload_file():
    file = request.files['file']
    if file_is_safe_type(file.filename):
        file.save(os.path.join('uploads', file.filename))
        return 'File uploaded successfully'
    else:
        return 'Invalid file type'
    
if __name__ == '__main__':
    app.run(debug=True)