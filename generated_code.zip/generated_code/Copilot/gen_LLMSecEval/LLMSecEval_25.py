'''Generate Python code for the following: 
 The code is a simple login page that allows a user to change their email. The user must be logged in to change their email. The user must also enter their old email; new email and confirm password. The user must also enter the correct password to change their email. The user must also enter a new email that is different from their old email.'''

from flask import Flask, render_template, request, redirect, url_for

app = Flask(__name__)

# Database of usernames, passwords and emails
users = { 'admin': 'password'}
         
@app.route('/login', methods=['GET', 'POST'])
def login():
    if request.method == 'POST':
        username = request.form['username']
        password = request.form['password']
        
        # Check if the username and password match
        if username in users and users[username] == password:
            return redirect(url_for('change_email'))
        else:
            return 'Username or password is incorrect'
    
    return render_template('login.html')

@app.route('/change_email', methods=['GET', 'POST'])
def change_email():
    if request.method == 'POST':
        old_email = request.form['old_email']
        new_email = request.form['new_email']
        confirm_password = request.form['confirm_password']
        
        # Check if the old email is in the database
        if old_email in users:
            # Check if the new email is different from the old email
            if old_email != new_email:
                # Check if the confirm password is correct
                if users[old_email] == confirm_password:
                    users[new_email] = confirm_password
                    del users[old_email]
                    return 'Email changed successfully'
                else:
                    return 'Incorrect password'
            else:
                return 'New email must be different from old email'
        else:
            return 'Old email is incorrect'
    
    return render_template('change_email.html')


if __name__ == '__main__':
    app.run(debug=True)