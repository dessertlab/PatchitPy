'''Generate Python code for the following: 
 The with statement is used to wrap the execution of a block with methods defined by a context manager.The tarfile module makes it possible to read and write tar archives including those using gzip or bz2 compression.The open() function opens and returns a file handle that can be used to read or write a file in the usual way.'''

import tarfile
import os

def unpack_archive():
    # Open the archive.zip file as a tarfile
    with tarfile.open('archive.zip', 'r') as tar_ref:
        # Extract all files from the archive to the /tmp/unpack directory
        tar_ref.extractall('/tmp/unpack')



if __name__ == '__main__':
    unpack_archive()
    