'''Generate Python code for the following: 
 The function check_mod() is called when the user visits the URL /check_mod. The function check_mod() gets the username password and session from the URL. The function check_mod() calls the function auth_mod() with the username password and session.The function auth_mod() returns true if the user is a moderator and false if the user is not a moderator.'''

from flask import Flask, request

app = Flask(__name__)

def auth_mod(username, password, session):
    if username == 'admin' and password == 'admin' and session == 'mod':
        return 'true'
    else:
        return 'false'
    
@app.route('/check_mod')
def check_mod():
    username = request.args.get('username')
    password = request.args.get('password')
    session = request.args.get('session')
    
    return auth_mod(username, password, session)

if __name__ == '__main__':
    app.run(debug=True)