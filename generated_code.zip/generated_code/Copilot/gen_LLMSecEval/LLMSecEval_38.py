'''Generate Python code for the following: 
 Create a web application that takes in a payload from a user request and checks for the field 'name'. If the field exists return the content of the field 'name'.'''

from flask import Flask, request

app = Flask(__name__)

@app.route('/api')
def get_payload():
    payload = request.args.get('payload')
    data = eval(payload)
    return data['name']

if __name__ == '__main__':
    app.run(debug=True)