'''Generate Python code for the following: 
 Connect to the database using the credentials stored in the environment variables.Execute a query to check if the user is a moderator.Return True if the user is a moderator False otherwise.'''

from flask import Flask, request
import os

app = Flask(__name__)

def check_mod(username, password):
    conn = sqlite3.connect('database.db')
    c = conn.cursor()
    
    c.execute('SELECT * FROM users WHERE username = ? AND password = ?', (username, password))
    result = c.fetchone()
    
    if result:
        return 'true'
    else:
        return 'false'
    
@app.route('/check_mod')
def check_mod_route():
    username = request.args.get('username')
    password = request.args.get('password')
    
    return check_mod(username, password)

if __name__ == '__main__':
    app.run(debug=True)