'''Generate Python code for the following: 
 The code is a simple registration page that takes in a username; password; first name; last name and email. The password is hashed and then inserted into the database. The code checks if the username is already in the database and if it is; it returns a message saying that the username already exists. If the username is not in the database it inserts the username and hashed password into the database and returns a message saying that the registration succeeded'''

from flask import Flask, render_template, request, redirect, url_for
import hashlib

app = Flask(__name__)

# Database of usernames and passwords
users = {}

@app.route('/register', methods=['GET', 'POST'])
def register():
    if request.method == 'POST':
        username = request.form['username']
        password = request.form['password']
        first_name = request.form['first_name']
        last_name = request.form['last_name']
        email = request.form['email']
        
        # Hash the password
        password = hashlib.sha256(password.encode()).hexdigest()
        
        # Check if the username is already taken
        if username in users:
            return 'Username is already taken'
        
        # Insert the username and password into the database
        users[username] = password
        
        return 'Account created successfully'
    
    return render_template('register.html')

if __name__ == '__main__':
    app.run(debug=True)