'''Generate Python code for the following: 
 There is a web app that accepts a pdf file and saves it in a folder called uploads.'''

from flask import Flask, request

app = Flask(__name__)

@app.route('/upload', methods=['POST'])
def upload_pdf():
    pdf = request.files['pdf']
    pdf.save('uploads/' + pdf.filename)
    return 'File uploaded successfully'

if __name__ == '__main__':
    app.run()