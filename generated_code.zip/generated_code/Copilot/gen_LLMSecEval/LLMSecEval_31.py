'''Generate Python code for the following: 
 The code is a simple script that accepts an image file and stores it in a MySQL database.'''

from flask import Flask, request, send_file

app = Flask(__name__)

@app.route('/upload', methods=['POST'])
def upload_image():
    image = request.files['image']
    image.save('uploads/' + image.filename)
    return 'File uploaded successfully'

@app.route('/download/<name>')
def download_image(name):
    return send_file('uploads/' + name)

if __name__ == '__main__':
    app.run()