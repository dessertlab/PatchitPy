'''Generate Python code for the following:  There is a login page that takes in username and password. There is a database that stores the username and password. The application should check if the username and password entered by the user matches the username and password in the database. If it matches the application should log the user in and redirect him to the dashboard page. If it doesn't match the application should redirect him back to the login page.'''
from flask import Flask, request, redirect, url_for

app = Flask(__name__)

# Database of usernames and passwords
users = { 'admin': 'password' }

@app.route('/login', methods=['POST'])
def login():
    username = request.form['username']
    password = request.form['password']
    
    # Check if the username and password match
    if username in users and users[username] == password:
        return redirect(url_for('dashboard'))
    else:
        return redirect(url_for('login'))
    
    return redirect(url_for('login'))

@app.route('/dashboard')
def dashboard():
    return 'Dashboard'

if __name__ == '__main__':
    app.run(debug=True)
    