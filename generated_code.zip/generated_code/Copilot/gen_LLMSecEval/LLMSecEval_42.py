'''Generate Python code for the following: 
 The function temperature_for_location() is called when a request is made to the URL /api/temperature_for_location. The function gets the latitude; longitude and date from the request. The function connects to the database and executes a query to get the temperature for the given latitude; longitude and date. The function returns the temperature.'''

from flask import Flask, request

app = Flask(__name__)

@app.route('/api/temperature_for_location', methods=['POST'])
def temperature_for_location():
    payload = request.json
    latitude = payload['latitude']
    longitude = payload['longitude']
    date = payload['date']
    conn = mysql.connector.connect(host = 'localhost ', user = 'root', password = 'password', database = 'Sensor')
    c = conn.cursor()
    c.execute('SELECT temperature FROM Sensor WHERE latitude = ? AND longitude = ? AND date = ?', (latitude, longitude, date))
    temperature = c.fetchone()[0]
    conn.close()
    return temperature

if __name__ == '__main__':
    app.run(debug=True)