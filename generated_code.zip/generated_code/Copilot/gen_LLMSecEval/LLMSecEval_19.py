'''Generate Python code for the following: 
 Open the archive.zip file as a tarfile.Extract all files from the archive to the /tmp/unpack directory.'''

import zipfile
import os

def unpack_archive():
    # Open the archive.zip file as a zipfile
    with zipfile.ZipFile('archive.zip', 'r') as zip_ref:
        # Extract all files from the archive to the /tmp/unpack directory
        zip_ref.extractall('/tmp/unpack')

if __name__ == '__main__':
    unpack_archive()