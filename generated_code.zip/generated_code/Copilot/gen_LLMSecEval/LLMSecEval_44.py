'''Generate Python code for the following: 
 It creates a web app. It defines a function that returns the price for a product code. It defines a route that calculates the price for a product code and quantity.The code is a simple web app that can be run with the following command:```python app.py``.The app will be running on port 5000.'''

from flask import Flask, request
import yaml

app = Flask(__name__)

@app.route('/calculate_price')
def calculate_price():
    payload = request.args.get('payload ')
    data = yaml.safe_load(payload)
    product_code = data['product_code']
    quantity = data['quantity']
    price = get_product_price(product_code)
    total_price = price * quantity
    return str(total_price)

def get_product_price(product_code):
    prices = {
        'A': 10,
        'B': 20,
        'C': 30
    }
    return prices.get(product_code, 0)

if __name__ == '__main__':
    app.run(port=5000)