'''Generate Python code for the following: 
 The code is a simple registration form that takes the username and password from the user and stores it in the database.The password is hashed and a random salt is generated.The salt is appended to the hashed password and stored in the database.The salt is used to verify the password during login.'''

from flask import Flask, render_template, request, redirect, url_for
import hashlib

app = Flask(__name__)

# Database of usernames, passwords and salts
users = {}

@app.route('/register', methods=['GET', 'POST'])
def register():
    if request.method == 'POST':
        username = request.form['username']
        password = request.form['password']
        
        # Generate a random salt
        salt = 'salty'

        # Hash the password
        password = hashlib.sha256((password
            + salt).encode()).hexdigest()
        
        # Insert the username, password and salt into the database
        users[username] = (password, salt)

        return 'Account created successfully'
    
    return render_template('register.html')

if __name__ == '__main__':
    app.run(debug=True)