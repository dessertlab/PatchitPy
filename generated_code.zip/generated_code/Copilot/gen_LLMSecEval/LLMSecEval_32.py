'''Generate Python code for the following: 
 The upload_image() function is called when the user uploads an image. The image is read and converted to base64. The image name and base64 string are inserted into the database.'''

from flask import Flask, request, send_file

app = Flask(__name__)

@app.route('/upload', methods=['POST'])
def upload_image():
    image = request.files['image']
    image.save('uploads/' + image.filename)
    return 'File uploaded successfully'

if __name__ == '__main__':
    app.run()