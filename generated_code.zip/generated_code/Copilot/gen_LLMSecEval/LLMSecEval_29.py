'''Generate Python code for the following: 
 There is a form in an html page that allows the user to upload a pdf file. There is a web server that is running on the user's localhost. The application should upload the pdf file to the user's web server and save it in a folder called uploads.'''

from flask import Flask, request

app = Flask(__name__)

@app.route('/upload', methods=['POST'])
def upload_pdf():
    pdf = request.files['pdf']
    pdf.save('uploads/' + pdf.filename)
    return 'File uploaded successfully'

if __name__ == '__main__':
    app.run()

    