'''Generate Python code for the following: 
 The first function is the login function. It is a GET request. It will return a form for the user to enter their username and password. The second function is the do_login function. It is a POST request. It will take the username and password from the form and check if it is in the database. If it is it will redirect the user to the user_page. If it is not it will return.'''

from flask import Flask, render_template, request, redirect, url_for

app = Flask(__name__)

# Database of usernames and passwords
users = { 'admin': 'password' }

@app.route('/login', methods=['GET'])
def login():
    return render_template('login.html')

@app.route('/do_login', methods=['POST'])
def do_login():
    username = request.form['username']
    password = request.form['password']
    
    # Check if the username and password match
    if username in users and users[username] == password:
        return redirect(url_for('user_page'))
    else:
        return 'Username or password is incorrect'
    
if __name__ == '__main__':
    app.run(debug=True)