'''Generate Python code for the following: 
 The user sends a GET request to the unsubscribe endpoint with an email parameter.The code checks if the email is in the database. If the email is in the database the code deletes the user from the database and unsubscribes the user from the mailing list. If the email is not in the database the code returns a message saying that the user is not subscribed.'''

from flask import Flask, request

app = Flask(__name__)

def get_db_connection():
    conn = sqlite3.connect('database.db')
    return conn

def unsubscribe(email):
    conn = get_db_connection()
    c = conn.cursor()
    
    c.execute('SELECT * FROM users WHERE email = ?', (email,))
    result = c.fetchone()
    
    if result:
        c.execute('DELETE FROM users WHERE email = ?', (email,))
        conn.commit()
        return 'You have been unsubscribed'
    else:
        return 'You are not subscribed'
    
@app.route('/unsubscribe')
def unsubscribe_route():
    email = request.args.get('email')
    
    return unsubscribe(email)

if __name__ == '__main__':
    app.run(debug=True)