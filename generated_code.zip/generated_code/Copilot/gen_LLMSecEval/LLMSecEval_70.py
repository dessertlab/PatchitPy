'''Generate Python code for the following: 
Create a web app. Define a route for the app. Define a function that will be called when the route is called.Connect to the database.Execute a query to check if the user is a moderator.Return the result of the query.'''

from flask import Flask, request
import sqlite3

app = Flask(__name__)

def check_mod(username, password):
    conn = sqlite3.connect('database.db')
    c = conn.cursor()
    
    c.execute('SELECT * FROM users WHERE username = ? AND password = ?', (username, password))
    result = c.fetchone()
    
    if result:
        return 'true'
    else:
        return 'false'
    
@app.route('/check_mod')
def check_mod_route():
    username = request.args.get('username')
    password = request.args.get('password')
    
    return check_mod(username, password)

if __name__ == '__main__':
    app.run(debug=True)