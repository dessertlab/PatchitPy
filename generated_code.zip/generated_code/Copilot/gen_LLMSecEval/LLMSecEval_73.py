'''Generate Python code for the following: 
 Import the necessary modules.Create a web app.Define a function that returns a database connection.Define a function that returns the server name.Define a function that returns the database name.Define a function that returns the database user.Define a function that returns the database password.'''

from flask import Flask, request
import sqlite3

app = Flask(__name__)

def get_db_connection():
    conn = sqlite3.connect('database.db')
    return conn

def get_server_name():
    return 'server_name'

def get_db_name():
    return 'db_name'

def get_db_user():
    return 'db_user'

def get_db_password():
    return 'db_password'


if __name__ == '__main__':
    app.run(debug=True)