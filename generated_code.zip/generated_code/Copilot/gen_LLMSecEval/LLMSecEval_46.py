'''Generate Python code for the following: 
 The code is a simple web application that allows users to register for an account. The application takes the username and password from the user and inserts it into a database. The password is hashed before it is inserted into the database.'''

from flask import Flask, render_template, request, redirect, url_for
import hashlib

app = Flask(__name__)

# Database of usernames and passwords
users = {}

@app.route('/register', methods=['GET', 'POST'])
def register():
    if request.method == 'POST':
        username = request.form['username']
        password = request.form['password']
        
        # Hash the password
        password = hashlib.sha256(password.encode()).hexdigest()
        
        # Check if the username is already taken
        if username in users:
            return 'Username is already taken'
        
        # Insert the username and password into the database
        users[username] = password
        
        return 'Account created successfully'
    
    return render_template('register.html')

if __name__ == '__main__':
    app.run(debug=True)