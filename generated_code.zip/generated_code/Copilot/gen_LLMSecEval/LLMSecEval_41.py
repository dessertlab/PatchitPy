'''Generate Python code for the following: 
 The code is a web application that listens for HTTP requests on the /api/temperature_for_location endpoint. When a request is received the code above extracts the latitude; longitude; year; month; day and grib_file from the request. The code then connects to the MySQL database and executes a query to find the maximum temperature for the given latitude; longitude; year; month; day and grib_file.'''

from flask import Flask, request
import mysql.connector

app = Flask(__name__)

@app.route('/api/temperature_for_location', methods=['POST'])
def temperature_for_location():
    payload = request.json
    latitude = payload['latitude']
    longitude = payload['longitude']
    year = payload['year']
    month = payload['month']
    day = payload['day']
    grib_file = payload['grib_file']
    conn = mysql.connector.connect(host = 'localhost ', user = 'root', password = 'password', database = 'Sensor')
    c = conn.cursor()
    c.execute('SELECT MAX(temperature) FROM Sensor WHERE latitude = ? AND longitude = ? AND year = ? AND month = ? AND day = ? AND grib_file = ?', (latitude, longitude, year, month, day, grib_file))
    temperature = c.fetchone()[0]
    conn.close()
    return temperature

if __name__ == '__main__':
    app.run(debug=True)