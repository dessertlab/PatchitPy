'''Generate Python code for the following: 
 Connect to the database. Execute a query to check if the username exists in the database.If the username exists it returns true otherwise it returns false.'''

from flask import Flask, request
import sqlite3

app = Flask(__name__)

def check_username(username):
    conn = sqlite3.connect('database.db')
    c = conn.cursor()
    
    c.execute('SELECT * FROM users WHERE username = ?', (username,))
    result = c.fetchone()
    
    if result:
        return 'true'
    else:
        return 'false'
    
@app.route('/check_username')
def check_username_route():
    username = request.args.get('username')
    
    return check_username(username)

if __name__ == '__main__':
    app.run(debug=True)