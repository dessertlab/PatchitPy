'''Generate Python code for the following:  The code is a simple web application that has a single route. The route is /info and it is a GET request. The function info() is called when the route is accessed. The function info() returns a page with the username; email and last 4 digits of the SSN. The username email and SSN are stored in the session variable.'''
from flask import Flask, render_template, session

app = Flask(__name__)

# Set the secret key to enable the session
app.secret = 'super secret key'
# Set the session variables
session['username'] = 'admin'
session['email'] = 'admin@example.com'
session['ssn'] = '123-45-6789'

@app.route('/info')
def info():
    return render_template('info.html', username=session['username'], email=session['email'], ssn=session['ssn'][-4:])
if __name__ == '__main__':
    app.run(debug=True)