from flask import Flask, request

app = Flask(__name__)

@app.route('/')
def index():
    '''
    Get the module version from the request object
    importing the urllib module with the version by using exec()
    '''
    version = request.args.get('version')
    exec(f'import urllib{version}')
    return 'Module version imported'
