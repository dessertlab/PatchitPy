import tempfile


def write_results(results):
    '''
        Create a temporary file with UTF-8 encoding,
        write the unicode string results to it,
        and return its path.
    '''
    filename = tempfile.mktemp()
    with open (filename, 'w', encoding='utf-8') as file:
        file.write(results)
    return filename
