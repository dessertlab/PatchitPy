import socket

def parseUDPpacket(data):
    pass


def resolveName(nameToResolve):
    pass


def sendResponse(requestIP, record):
    pass


def UDPMessaging(udp_ip, udp_port):
    '''
    Create a UDP socket that listens on the IP and port provided for DNS requests.
    Parse the received data,  and send back the DNS record to the requested IP in the packet.
    '''
    s = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)
    s.bind((udp_ip, udp_port))
    while True:
        data, addr = s.recvfrom(1024)
        parsedData = parseUDPpacket(data)
        record = resolveName(parsedData)
        sendResponse(addr[0], record)
    s.close()
    return True