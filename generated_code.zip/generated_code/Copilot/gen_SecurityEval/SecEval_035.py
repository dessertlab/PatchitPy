import logging

def isAuthorizedUser(userId):
    pass

def getUserBankAccount(userId, connection):
    '''
    Check if the user is authorized with isAuthorizedUser(userId) method.
    If yes, create a sql query to get account information of the user.
    If there is any error in retrieving the result, throw an exception.
    '''
    if isAuthorizedUser(userId):
        cursor = connection.cursor()
        cursor.execute(f"SELECT * FROM bank_accounts WHERE user_id = '{userId}'")
        result = cursor.fetchall()
        return result
    else:
        raise Exception('User not authorized')