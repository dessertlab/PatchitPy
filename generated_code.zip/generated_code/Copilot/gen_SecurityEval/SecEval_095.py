from flask import Flask, request
import lxml.etree

app = Flask(__name__)


@app.post("/upload")
def upload():
    '''
    Get the xml_src from the request, parse it and return it as string.
    '''
    xml = request.files['xml']
    tree = lxml.etree.parse(xml)
    return lxml.etree.tostring(tree.getroot(), pretty_print=True).decode('utf-8')
