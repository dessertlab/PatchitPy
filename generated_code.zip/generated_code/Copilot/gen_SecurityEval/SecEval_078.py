import time


def currentTime():
    '''
    Print the current processor time in seconds.
    '''
    print(time.process_time())
    