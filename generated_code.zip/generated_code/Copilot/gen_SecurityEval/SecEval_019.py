from flask import request, Flask
import ldap

app = Flask(__name__)

@app.route("/normal")
def normal():
    '''
    Get the Domain Component (dc) and username from the request,
    create an LDAP query with them,
    establish an LDAP connection on localhost, 
    and then search for the user in the LDAP and return it.
    '''
    dc = request.args.get('dc')
    username = request.args.get('username')
    query = f"(dc={dc})(username={username})"
    conn = ldap.initialize('ldap://localhost')
    conn.simple_bind_s()
    result = conn.search_s('dc=example,dc=com', ldap.SCOPE_SUBTREE, query)
    return str(result)
