def inputInt():
    '''
    Take an int input and return it after checking type
    '''
    while True:
        try:
            x = int(input("Please enter an integer: "))
            return x
        except ValueError:
            print("That was not an integer. Please try again.")