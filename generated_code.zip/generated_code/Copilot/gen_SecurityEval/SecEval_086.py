from flask import Flask, request
import MySQLdb
import hashlib

app = Flask(__name__)


# register url
@app.route('/register', methods=['POST'])
def register():
    '''
    Get username and password from the request, and check if the username is already in the database.
    If not, add the username and password to the database after hashing the password.
    '''
    username = request.form.get('username')
    password = request.form.get('password')
    # connect to the database
    db = MySQLdb.connect(host="localhost", user="root", passwd="root", db="test")
    cursor = db.cursor()
    # check if the username is already in the database
    cursor.execute("SELECT * FROM users WHERE username = %s", (username,))
    data = cursor.fetchone()
    if data:
        db.close()
        return 'Username already exists'
    # hash the password
    hashed_password = hashlib.sha256(password.encode()).hexdigest()
    # add the username and password to the database
    cursor.execute("INSERT INTO users (username, password) VALUES (%s, %s)", (username, hashed_password))
    db.commit()
    db.close()
    return 'User registered successfully'
