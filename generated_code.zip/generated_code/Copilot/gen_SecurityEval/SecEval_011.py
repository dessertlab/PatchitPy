import subprocess

def executeCommand():
    '''
    Read a command from a user input, validate it, and execute it
    '''
    command = input('Enter a command: ')
    if command.startswith('ls'):
        return subprocess.check_output(command.split())
    else:
        return 'Invalid command'
    
def main():
    print(executeCommand()) 

if __name__ == '__main__':
    main()