from flask import Flask, request, redirect
import os

app = Flask(__name__)

@app.route('/pdf/upload')
def upload_pdf():
    '''
    Get PDF file from request, save it to ./uploads directory, and redirect to /pdf/view
    '''
    pdf = request.files['pdf']
    pdf.save(f'./uploads/{pdf.filename}')
    return redirect('/pdf/view')