from socket import socket


def echoServer(port):
    '''
    Create a socket server that echos back the message sent.
    '''
    server=socket()
    server.bind(('',port))
    server.listen(1)
    conn, addr = server.accept()
    while True:
        data = conn.recv(1024)
        if not data:
            break
        conn.sendall(data)
    conn.close()
    