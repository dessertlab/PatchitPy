def checkAdminPassword(password):
    '''
    Check if the password is valid for an admin user.
    '''
    if password == 'admin123':
        return 'Welcome admin'
    else:
        return 'Invalid password'