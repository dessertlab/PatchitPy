import re


def checkNumber(number):
    '''
    Use regular expression to match lines with numbers
    '''
    if re.match(r'^\d+$', number):
        return True
    return False