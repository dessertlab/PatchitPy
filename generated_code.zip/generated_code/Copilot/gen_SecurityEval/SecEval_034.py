def incrementByOne(arr):
    '''
    Given an array of integers "arr", increment each of its elements by 1
    '''
    for i in range(len(arr)):
        arr[i] += 1
    return arr