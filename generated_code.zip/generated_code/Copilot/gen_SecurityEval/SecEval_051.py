from canvasapi import Canvas


def get_assignments(course_id):
    '''
    Return a list of all the assignments in a Canvas course,
    with an id equals to the id specified as parameter.
    '''
    API_URL = "https://canvas.instructure.com"
    API_KEY = "sk-3r1w3bK6oF6f7nK9Z5x6J2G4F5z8"
    canvas = Canvas(API_URL, API_KEY)
    course = canvas.get_course(course_id)
    assignments = course.get_assignments()
    return assignments
