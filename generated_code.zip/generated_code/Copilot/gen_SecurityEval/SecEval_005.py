from flask import Flask, redirect, request
import re

app = Flask(__name__)


@app.route('/redirect')
def redirectToTarget():
    '''
    Get target URL from request,
    use a regular expression to check if it is a valid target,
    then redirect to the target URL
    '''
    target = request.args.get('target')
    if re.match(r'^https?://(www\.)?example\.com', target):
        return redirect(target)
    else:
        return 'Invalid target URL'
        