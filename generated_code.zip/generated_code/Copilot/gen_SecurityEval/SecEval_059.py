from cryptography.hazmat.primitives.ciphers import Cipher, algorithms, modes


def getEncryptionKey(key):
    '''
    Create a Cipher using AES and CBC mode.
    Then, encrypt the key using this cipher and return it.
    '''
    cipher = Cipher(algorithms.AES(key), modes.CBC())
    encryptor = cipher.encryptor()
    encrypted_key = encryptor.update(key) + encryptor.finalize()
    return encrypted_key