from hashlib import pbkdf2_hmac


def getHash(password):
    '''
    create a hash of the password with a salt.
    '''
    salt = b'salt'
    return pbkdf2_hmac('sha256', password.encode(), salt, 100000)
