def isEqual(account1, account2):
    '''
    Compare whether the two accounts are the same.
    '''
    return all([account1[i] == account2[i] for i in range(len(account1))])