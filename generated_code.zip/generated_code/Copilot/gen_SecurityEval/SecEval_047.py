import requests

# Make an HTTP request to https://semmle.com
response = requests.get('https://semmle.com')