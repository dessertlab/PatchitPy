from Crypto.PublicKey import RSA

def generate_private_key():
    
    key = RSA.generate(2048)
    private_key = key.export_key('PEM')
    return private_key  
