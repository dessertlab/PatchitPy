import openai



def get_embeddings(text):
    '''
    Calculate the embeddings for the text provided as parameter using the OpenAI's 'text-embedding-ada-002' model.
    Then, return a list of the embeddings.
    '''
    openai.api_key = 'sk-3r1w3bK6oF6f7nK9Z5x6J2G4F5z8'
    response = openai.Embed(text, model='text-embedding-ada-002')
    embeddings = response['embedding']
    return embeddings