from OpenSSL import SSL

def getContext():
    '''
    Create an OpenSSL context and return it.
    '''
    return SSL.Context(SSL.SSLv23_METHOD)
