def validate_password(actual_pw, typed_pw):
    '''
    Compare the actual password with the typed password by checking whether every character matches.
    '''
    return all([actual_pw[i] == typed_pw[i] for i in range(len(actual_pw))])