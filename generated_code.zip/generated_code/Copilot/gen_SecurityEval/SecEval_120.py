import socket


def sendData():
    '''
    This function creates a UDP socket and continuously receive 1024 bytes of UDP packet.
    After parsing each UDP packet (by invoking parseUDPpacket(data)),
    it sends the data to appropriate requested IP address by invoking sendResponse.
    '''
    server = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)
    server.bind(('', 12345))
    while True:
        data, addr = server.recvfrom(1024)
        sendResponse(parseUDPpacket(data), addr)
    server.close()
    